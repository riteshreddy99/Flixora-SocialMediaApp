import React from "react";
import HorizontalTimeline from "react-horizontal-timeline";



const EXAMPLE = [
   
  {
    data: "2020-10-06",
    status: "status",
    statusB: "Project Plan",
    statusE: "Done"
  },
  {
    data: "2020-11-09",
    status: "status",
    statusB: "Project Overview",
    statusE: "Done"
  }
  ,
  {
    data: "2021-01-10",
    status: "status",
    statusB: "Flixora Website",
    statusE: "Done"
  }
  ,
  {
    data: "2021-01-17",
    status: "status",
    statusB: "App Design",
    statusE: "Done"
  }
  ,
  {
    data: "2021-01-21",
    status: "status",
    statusB: "App Development",
    statusE: "Done"
  }
,
  {
    data: "2021-02-03",
    status: "status",
    statusB: "App Demo",
    statusE: "Done"
  }

  ,
  {
    data: "2021-02-19",
    status: "status",
    statusB: "App Functionality",
    statusE: "Done"
  }



  ,
  {
    data: "2021-03-14",
    status: "status",
    statusB: "Beta-Testing",
    statusE: "Done"
  }


  ,
  {
    data: "2021-03-24",
    status: "status",
    statusB: "App Deployment",
    statusE: "Done"
  }





];

export default class Timeline extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      curIdx: 0,      
    
    };
  }

  //state = { value: 0, previous: 0 };

  render() {    
    const {curIdx, prevIdx} = this.state;
    const curStatus = EXAMPLE[curIdx].statusB;
    

    return (
      <div>
        {/* Bounding box for the Timeline */}
        <div
          style={{
            width: "60%",
            height: "100px",
            margin: "0 auto",
            marginTop: "20px",
            fontSize: "12px"
          }}
        >
          <HorizontalTimeline
            styles={{
                
              background: "#f8f8f8",
              foreground: "#66fcf1",
              outline: "#dfdfdf",
              
            }}
            index={this.state.curIdx}
            indexClick={index => {
              const curIdx = this.state.curIdx;
              this.setState({ curIdx: index, prevIdx: curIdx });
            }}            
            values={EXAMPLE.map(x => x.data)}
          />
        </div>
        <div className="text-center">
          {/* any arbitrary component can go here */}
          {curStatus} 
        </div>
      </div>
    );
  }
}
