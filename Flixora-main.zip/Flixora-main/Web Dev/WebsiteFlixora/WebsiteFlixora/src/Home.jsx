import React from 'react';
import { NavLink } from 'react-router-dom';
import './index.css';



const home = () => {
    return (
        <>
        <section id=
        "header" className="d-flex align-items-center ">
        <div className="container-fluid">
            <div className="peach-gradient color-block mb-3 mx-auto rounded-circle z-depth-1">

         <div className='row' >
           <div className="col-10 mx-auto">
               <div className="row">
               <div className="col-md-6 pt-5 pt-lg-0 order-lg-1 d-flex justify-content-center flex-column">
                   <h1 > 
                       Show your skills with <strong className="brand-name"><hh>Flixora</hh></strong>
                   </h1>
                   <h2 className="my-3">
                    A Perfect Application Made For Photography Enthusiasts and Competitors
                    </h2>
                   <div activeclassName="mt-3">
                       <NavLink to="/service" >
                       <button type="button" class="btn btn-outline-info"><strong><hl>COMING SOON</hl></strong></button>
                           </NavLink> 
                           </div>
                   </div>
                   <div className="col-lg-6 order-1 order-lg-2 col-md-6 header-img">
                     <img src="https://i.pinimg.com/originals/d7/7e/2c/d77e2cc708655672d9313f87689c9cb2.gif"/>

                 

               </div>
               
            
               </div>

           </div>
         </div>
         </div>
       </div>
        </section>
        
         <div className="colorcode container-fluid ">
         <div className='row' >
           <div className="col-10 mx-auto">
               <div className="row">
                   <p cl>
                       <strong>On a scale of 1-10, Majority of users rated between “8-10”</strong>
                   </p>
               </div> 
               </div>
               </div>
               </div>
        
         <div className="colorcode2 container-fluid pt-4">
         <div className='row' >
           <div className="col-10 mx-auto">
               <div className="row">
               <div class="container">
    <div class="mgb-40 padb-30 auto-invert line-b-4 align-center">
        <h1 class="font-cond-b fg-text-d lts-md fs-300 fs-300-xs no-mg" contenteditable="false"><strong>Prototype reviews</strong></h1>
    </div>
    <ul class="hash-list cols-3 cols-1-xs pt-3 pad-30-all align-center text-sm">
    <li>
          
          <p class="fs-110 font-cond-l" contenteditable="false">“Looks aesthetically pleasing to the eyes”</p>
          
        </li>
        <li>
          
          <p class="fs-110 font-cond-l" contenteditable="false"> "Overall layout is clear and concise. All the necessities have been asked straightforwardly and do not seem confusing."</p>
        
         
        </li>
        
        <li>
          
          <p class="fs-110 font-cond-l" contenteditable="false">"It’s a really modern, user friendly layout"</p>
         
        </li>
      </ul>
</div>

               </div>
               </div>
               </div>
               </div>
               
               </>
    );
};
export default home;