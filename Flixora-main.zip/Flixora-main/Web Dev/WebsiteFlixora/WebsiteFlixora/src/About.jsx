import React from 'react';
import Timeline from './Timeline';

const About = () => {
    return (
        <>
        <section id=
        "header" >
        <div className="color2" >
        
        <div className="container-fluid h-100">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css" integrity="sha256-2XFplPlrFClt0bIdPgpz8H7ojnk10H69xRqd9+uTShA=" crossorigin="anonymous" />
        <div class="container">
        <div class="row align-items-center">
        <div class=" col-md-6 order-2   mt-sm-0 opt-sm-0">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-6 col-6">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 mt-4 pt-2">
                            <div class="card work-desk rounded border-0 shadow-lg overflow-hidden">
                                <img src="https://i.pinimg.com/564x/00/10/dd/0010ddc3707cdd2030e49a9cc97d7365.jpg" class="img-fluid" alt="Image" />
                                <div class="img-overlay bg-dark"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-6">
                    <div class="row">
                        <div class="col-lg-12 col-md-12">
                            <div class="card work-desk rounded border-0 shadow-lg overflow-hidden">
                                <img src="https://i.pinimg.com/564x/65/b7/43/65b743cb3fcf0e32690826bfefc6a63c.jpg" class="img-fluid" alt="Image" />
                                <div class="img-overlay bg-dark"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div className="col-lg-6 col-md-6 col-12 order-1 order-md-2">
            <div className="header2 ml-lg-5">
                <h5 className=" font-weight-normal mb-3"></h5>
                <h4 className="color7 title mb-4">
               <strong className="fs">About Us </strong>  <br/>
                </h4>
                <p className=" text-light pt-2">
                  We are a group of students based in the United Arab Emirates who attend Heriot-Watt University. We are in our third year of our Bachelor’s in computer science.
                </p> 
                <p className="text-light pt-2">
                  Our idea is based both on a web application, as well as, on a mobile application. It is a photography application that enables users to be able to interact with a community of photographers and hobbyists alike.
                </p>
                <p className="text-light pt-2">
                  Our main goal is to create a safe haven for like-minded individuals who love to photograph and love to explore. Unlike our competitors, our idea is solely based for users to be able to upload pictures of objects and animals they spot and love.
                </p>
                <p className="text-light pt-2">
                  Our group of dedicated students are aiming to allow individuals to access the platform both on iOS and Android, as well as, from the comfort of their browser, any time, any place.{"\n\n\n"}
                </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
         </section>

         <div className="container-fluid pt-5 color4">
         <div className="container-fluid pt-2">
         <div className='row' >
           <div className="col-10 mx-auto">
               <div className="row">
               <div class="container bootstrap snippets bootdey">
    <div class="panel panel-info panel-shadow">
        
        <div class="panel-body"> 
        <div class="team padd">
        <div class="container bootstrap snippets bootdey">
          <div class="heading pt-4">
            <h2> <strong>Our Team</strong></h2>
            <div class="divider"></div>
            <p> </p>
            <div class="divider"></div>
          </div>
          <div class="row">
            <div class="col-md-3 col-sm-6">
              <div class="team-member">


              <div class="member-details">
                  <h4><a href="https://github.com/brendenmonteiro">Brenden Monteiro</a></h4>
                  <span> Frontend App Developer</span>
                </div>
                <div class="clearfix"></div>
              </div>
            </div>
            <div class="col-md-3 col-sm-6">
              <div class="team-member">
                
                <div class="member-details">
                  <h4><a href="https://github.com/HariniBalamurugan">Harini Balamurugan</a></h4>
                  <span>Backend App Developer</span>
                </div>
                <div class="clearfix"></div>
              </div>
            </div>
            <div class="col-md-3 col-sm-6">
              <div class="team-member">
                
                <div class="member-details">
                  <h4><a href="https://github.com/Harshal12355">Harshal Thachapully</a></h4>
                  <span>Database Admin</span>
                </div>
                <div class="clearfix"></div>
              </div>
            </div>
            <div class="col-md-3 col-sm-6">
              <div class="team-member">
                
                <div class="member-details">
                  <h4><a href="https://github.com/marwansolanki">Marwan Solanki</a></h4>
                  <span>Technical Writer</span>
                </div>
                <div class="clearfix"></div>
              </div>
            </div>
          </div>

          <div class="row">
            <div class="col-md-3 col-sm-6">
              <div class="team-member">
                
                <div class="member-details">
                  <h4><a href="https://github.com/PC-02">Pranav Chachara</a></h4>
                  <span>Backend App Developer</span>
                </div>
                <div class="clearfix"></div>
              </div>
            </div>
            <div class="col-md-3 col-sm-6">
              <div class="team-member">
                
                <div class="member-details">
                  <h4><a href="https://github.com/riteshreddy99"> Ritesh Reddy </a></h4>

                  <span>Frontend Web Developer</span>
                </div>
                <div class="clearfix"></div>
              </div>
            </div>
            <div class="col-md-3 col-sm-6">
              <div class="team-member">
                
              <div class="member-details">
                  <h4><a href="https://github.com/sfa29"> Sumaiya Arshad </a></h4>

                  <span>UI/UX Developer</span>
                </div>
                <div class="clearfix"></div>
              </div>
            </div>
            <div class="col-md-3 col-sm-6">
              <div class="team-member">



                <div class="member-details">
                  <h4><a href="https://github.com/Aymr07">Yousuf El-Baesy</a></h4>
                  <span>UI/UX Developer|Frontend</span>
                </div>
                <div class="clearfix"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
        </div>
        </div>
        </div>
        </div>
</div>

  
        
        
         
    </>
    );
};
export default About;