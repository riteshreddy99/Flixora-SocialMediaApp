import React from 'react';
import './index.css';



const Timeline = () => {
    return (
        <>
        <div class="container">
        <h3 className="color7 title mb-4">
            <br></br>
               <strong className="fs">Product Roadmap</strong>  <br/>
                </h3>
        <div class="row">
            <div class="col-md-12">
                <div class="main-timeline">
                    <a href="#" class="timeline">
                        <div class="timeline-icon"><i class="fa fa-tasks"></i></div>
                        <div class="timeline-content">
                            <h3 class="title">Oct 2020</h3>
                            <p class="description">
                               Project Planning, this stage which involved group management,deciding the necessary requirements of the app along with the cost of the project.  
                            </p>
                        </div>
                    </a>
                    <a href="#" class="timeline">
                        <div class="timeline-icon"><i class="fa fa-exclamation-triangle"></i></div>
                        <div class="timeline-content">
                            <h3 class="title">Oct 2020</h3>
                            <p class="description">
                                Identifying the potential risks and qorking on the UI of the app and testing out the usability of the app, and project overview before working on the app.
                            </p>
                        </div>
                    </a>
                    <a href="#" class="timeline">
                        <div class="timeline-icon"><i class="fa fa-exclamation-triangle"></i></div>
                        <div class="timeline-content">
                            <h3 class="title">Nov 2020</h3>
                            <p class="description">
                                Identifying the potential risks and qorking on the UI of the app and testing out the usability of the app, and project overview before working on the app.
                            </p>
                        </div>
                    </a>
                    <a href="#" class="timeline">
                        <div class="timeline-icon"><i class="fa fa-bullhorn"></i></div>
                        <div class="timeline-content">
                            <h3 class="title">Jan 2020</h3>
                            <p class="description">
                               Creating a promotional website for the app along with working on the functionality of few features of the app as well as the UI/UX design of the app.
                            </p>
                        </div>
                    </a>
                    <a href="#" class="timeline">
                        <div class="timeline-icon"><i class="fa fa-database"></i></div>
                        <div class="timeline-content">
                            <h3 class="title">Jan 2020</h3>
                            <p class="description">
                                Working on the Backend App Development using firebase authentication with flutter availing users to succesfully login to the app and view their feed.
                            </p>
                        </div>
                    </a>
                    <a href="#" class="timeline">
                        <div class="timeline-icon"><i class="fa fa-mobile"></i></div>
                        <div class="timeline-content">
                            <h3 class="title">Feb 2020</h3>
                            <p class="description">
                               Working to improve on the features to make the app more User friendly  as well as the progress report , website hosting and app demo of working features.
                            </p>
                        </div>
                    </a>
                    <a href="#" class="timeline">
                        <div class="timeline-icon"><i class="fa fa-map-marker"></i></div>
                        <div class="timeline-content">
                            <h3 class="title">Feb 2020</h3>
                            <p class="description">
                                Working on the Search Functionality,GPS Funcionality, Frontend Development, Challenge Functionality, along with necessary Post Demo Modifications.
                            </p>
                        </div>
                    </a>
                    
                    <a href="#" class="timeline">
                        <div class="timeline-icon"><i class="fa fa-plane"></i></div>
                        <div class="timeline-content">
                            <h3 class="title">March 2020</h3>
                            <p class="description">
                               Beta Testing the app followed by post-beta Modifications and final deployment of the app on the way to its users, as well as final progress report.
                            </p>
                        </div>
                    </a>
                </div>
            </div>
        </div>
        </div>
    
        </>    
          )
        };

export default Timeline;