import React from 'react';
import "./Goal.css";
import video from "./codingbg.mp4";
 
const Goal = () => {

    return(

        <div className='bg'>
            <video src={video} autoPlay loop muted/>
            <h1>OUR GOAL</h1>

            <div>
                {/* <img src="https://i.pinimg.com/564x/00/10/dd/0010ddc3707cdd2030e49a9cc97d7365.jpg" class="img-fluid" alt="Image" /> */}
                
                <p class="text">
                    
                    <strong>Flixora </strong>aims to provide individuals with a passion for photography, a place of comfort.
                    By providing them with different categorical pages that may help them discover new styles of photography, make friends, and compete against others. 
                    <br></br>
                    <br></br>
                    Our main goal is to provide a safe haven for like-minded individuals who love to photograph and explore.
                    Unlike our competitors, our idea is solely based for users to be able to upload pictures of objects and animals they spot and love.
                    <br></br>
                    <br></br>
                    We aim to be different compared to other photography apps and provide a unique twist on how users interact with each other and the system. 
                    Furthermore, photography enthusiasts should be able to challenge regional players to see who can complete challenges that are local themed.
                    Flixora aims to be unique in its own format, and be a haven for photography lovers, that being beginners or even pros.
                    <br></br>
                    <br></br>
                    Our group of dedicated students are aiming to allow individuals to access the platform both on iOS and Android, as well as, from the comfort of their browser, at any time and from any place.
                    
                    

                </p>
            </div>

        </div>

    );

};

export default Goal;
