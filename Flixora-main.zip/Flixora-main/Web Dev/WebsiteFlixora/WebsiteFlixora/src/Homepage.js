import React from 'react';
import "./Homepage.css";




const Home = () => {
    return (
<>
        <div className = "bg2"> 
            <div class="container-fluid">

                <div className="mainText">
                    <h3 className="class1">Show your skills with </h3>
                    <h1 className="title">FLIXORA</h1>
                    <h5>A perfect application made for enthusiasts <br></br> and competitors</h5>
                </div>

                <div className="rowImg">
                    <img src="https://i.pinimg.com/originals/d7/7e/2c/d77e2cc708655672d9313f87689c9cb2.gif"/>
                </div>
                
            </div>
        </div>

        <div className = "background">  
            {/* <img className = "landing" src={image}/> */}
            

            <div class="container-fluid">
                    <div class="row">

                    


                        <div class="col col-lg-5">
                                <p className="reviews">
                                    <p className="review-title">Prototype Reviews</p>
                                    "Looks aethetically pleasing to the eyes"
                                    <br></br><br></br>
                                    "Overall layout is clear and concise. All the necessities have been asked straightforwardly and do not seem confusing."
                                    <br></br><br></br>
                                    "It’s a really modern, user friendly layout"
                                </p>
                        </div>

                        <div class="col col-lg-6">
                                <p className="numbers">
                                    <div className="number-val" id="num-val">80%</div> of users were satisfied with their experience
                                </p>
                        </div>

                    </div>
            </div>


            


            

        </div>





</>
    );
};


export default  Home;

var numberRun = false;          // make sure animation runs only once

window.onload = function(){

    var number_pos = document.getElementById("num-val").offsetTop;      // get height of number 
    
    window.onscroll = function() {
        var y_scroll_pos = window.pageYOffset;
        var scroll_pos_test = number_pos;

        if(y_scroll_pos > scroll_pos_test) {        // when user scrolls to number value
            
            if(!numberRun)
                makeNumber();
            
            numberRun = true;
        }
    }
}

function makeNumber(){
    const numObj = document.getElementById("num-val");

    function animateNum(numObj, start, end, duration) {
        let time = null;

        const step = (timestamp) => {

            let durationRed = duration;
            if (!time) time = timestamp;
            
            durationRed = duration + (start * 10000)        // slow down speed movement 

            const num_progress = Math.min((timestamp - time) / durationRed, 1);
            numObj.innerHTML = (Math.floor(num_progress * (end - start) + start) + "%");    // write increasing value

            if (num_progress < 1) {
                window.requestAnimationFrame(step);
            }
        };
        window.requestAnimationFrame(step);
    }
    

    animateNum(numObj, 0, 80, 3500);
}