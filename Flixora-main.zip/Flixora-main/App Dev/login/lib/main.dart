import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:login/likes.dart';
import 'package:login/revampedSignup/AuthenService.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:login/revampedSignup/regPage.dart';
import 'package:login/revampedSignup/signInGoogle.dart';
import 'package:provider/provider.dart';
import 'homePage.dart';
import 'package:login/revampedSignup//signIn.dart';
import 'package:login/revampedSignup/register.dart';
import 'package:login/revampedSignup/createaccount.dart';
import 'package:login/revampedSignup/forgotpassword1.dart';
import 'home.dart';
import 'search.dart';
import 'uploadPage.dart';
import 'widgets/chatList.dart';


Future<void> main() async {


  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}



class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();


}

class _MyAppState extends State<MyApp> {
  bool isLight = false;


  ThemeData _darkTheme = ThemeData(
    floatingActionButtonTheme:
        FloatingActionButtonThemeData(backgroundColor: Colors.yellow[600]),
    brightness: Brightness.dark,
  );

  ThemeData _lightTheme = ThemeData(
      accentColor: Colors.pink,
      brightness: Brightness.light,
      primaryColor: Colors.blue);

  @override
  Widget build(BuildContext context) {


    return MultiProvider(
      providers: [
        Provider<AuthenService>(
          create: (_) => AuthenService(FirebaseAuth.instance),
        ),
        StreamProvider(
            create: (context) => context.read<AuthenService>().authStateChanges)
      ],
      child: MaterialApp(
        theme: isLight ? _lightTheme : _darkTheme,
        darkTheme: ThemeData.dark(),
        debugShowCheckedModeBanner: false,
        routes: <String, WidgetBuilder>{
          '/register': (BuildContext context) => new RegisterPage(),
          '/regPage': (BuildContext context) => new SignUpPage(),
          '/createaccount': (BuildContext context) => new New1Page(),
          '/forgotpw': (BuildContext context) => new FPW1Page(),
          '/home': (BuildContext context) => new HomePage(),
          '/search': (BuildContext context) => new SPage(),
          '/homePage': (BuildContext context) => new HPage(),
          '/uploadPage': (BuildContext context) => new UploadPage(),
          '/likes': (BuildContext context) => new LikesPage(),
          '/chatList': (BuildContext context) => new ChatList(),
          //'/signInGoogle': (BuildContext context) => new SignInGoogle(),
        },
        home: AuthenticationWrapper(),
      ),
    );
  }
}

class AuthenticationWrapper extends StatelessWidget {
  const AuthenticationWrapper({
    Key key,
  }) : super(key: key);

  Future<bool> _isValidUser(String uid) async {
    try {
      bool exists = false;
      await FirebaseFirestore.instance
          .doc("users/$uid")
          .get()
          .then((doc) async {
        // User exists in database
        if (doc.exists) {
          exists = true;
        }
        // User does not exist. Prompt to page to enter their username and all
        else {
          exists = false;
        }
      });
      return exists;
    } catch (e) {
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {

    final fireBaseUser = context.watch<User>();
    bool isUser = false;
    if (fireBaseUser != null && fireBaseUser.emailVerified) {
      return FutureBuilder<bool>(
        initialData: true,
          future: _isValidUser(fireBaseUser.uid),
          builder: (BuildContext context, AsyncSnapshot<bool> snapshot) {
            snapshot = snapshot.inState(ConnectionState.done);
            if (snapshot.hasData) {
              print("This has data");
              isUser = snapshot.data;
            } else if (snapshot.hasError) {
              print("Error");
            } else {
              print("Something");
            }

            return isUser ? HomePage() : SignInGoogle(user: fireBaseUser,);
          });
    } else {
      return SignInPage();
    }
    //
    // if (fireBaseUser != null && fireBaseUser.emailVerified ) {
    //   return HomePage();
    // }
    // return SignInPage();
  }
}
