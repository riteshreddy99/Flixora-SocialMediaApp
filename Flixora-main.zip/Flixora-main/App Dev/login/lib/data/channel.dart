class Channel{
  String id;
  String title;
  String subtitle;
  List<dynamic> tags;
  List<dynamic> posts;

  Channel();
}