
class NotificationBox{
  String message;
  String type;
  String username;
  String uid;
  DateTime timeSent;
  String refPID;
  String refUID;

  NotificationBox();
}


