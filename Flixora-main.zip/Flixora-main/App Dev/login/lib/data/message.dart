class Message{
  String sentBy;
  String msg;
  DateTime timeSent;
}
