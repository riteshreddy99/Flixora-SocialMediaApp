import 'package:cloud_firestore/cloud_firestore.dart';

class forum{
  String title;
  String info;
  Timestamp time;
  bool status;
  String creator;

  forum(this.title, this.info, this.time, this.status, this.creator);
}