
class Post {

  String description;
  String user;
  String userid;
  String pictureLink;
  int likes;
  bool isLiked;
  bool isSaved;
  String postid;

  Post(this.user, this.userid, this.postid, this.description, this.pictureLink, this.likes, this.isLiked, this.isSaved);

}