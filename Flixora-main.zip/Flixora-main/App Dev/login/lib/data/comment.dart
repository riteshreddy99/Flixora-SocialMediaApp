
class Comment{
  int likes;
  String text;
  String user;
  String uid;
  DateTime time;
  bool isLiked;
  String cid;

  Comment();
}
