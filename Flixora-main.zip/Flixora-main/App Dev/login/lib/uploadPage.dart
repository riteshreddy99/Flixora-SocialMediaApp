import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:line_icons/line_icons.dart';
import 'package:login/helper/profile-image.dart';
import 'package:path_provider/path_provider.dart';
import 'package:image/image.dart' as Img;
import 'package:photofilters/filters/preset_filters.dart';
import 'package:photofilters/widgets/photo_filter.dart';
import 'package:uuid/uuid.dart';
import 'package:login/homePage.dart';
import 'package:firebase_storage/firebase_storage.dart' as FBS;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:image_picker/image_picker.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart' as gc;
import 'package:image_cropper/image_cropper.dart';
import 'package:firebase_ml_vision/firebase_ml_vision.dart';
import 'package:path/path.dart' as p;

class UploadPage extends StatefulWidget {
  @override
  _UploadPageState createState() => _UploadPageState();
}

class _UploadPageState extends State<UploadPage> {
  TextEditingController locationController = TextEditingController();
  TextEditingController captionController = TextEditingController();

  File imgFile;
  final picker = ImagePicker();
  bool isHuman = false;
  bool isUploading = false;
  String postID = Uuid().v4();
  // final Geolocator geolocator = Geolocator();
  String address;
  List<Face> _faces;
  bool isLoading = false;

  _getImage(ImageSource src) async {
    final pickedFile = await picker.getImage(source: src);
    if (pickedFile != null) {
      File cropped = await ImageCropper.cropImage(
          sourcePath: pickedFile.path,
          aspectRatio: CropAspectRatio(ratioX: 1, ratioY: 1),
          compressFormat: ImageCompressFormat.jpg,
          androidUiSettings: AndroidUiSettings(
            toolbarTitle: "Crop Image",
          ));
      String tempPath = p.basename(cropped.path);
      var myImage = Img.decodeImage(cropped.readAsBytesSync());
      myImage = Img.copyResize(myImage, width: myImage.width);
      Map imagefile = await Navigator.push(
        context,
        new MaterialPageRoute(
          builder: (context) => new PhotoFilterSelector(
            appBarColor: Colors.grey[900],
            title: Text("Filter Photo"),
            image: myImage,
            filters: presetFiltersList,
            filename: tempPath,
            loader: Center(
                child: SpinKitFadingCube(
              color: Colors.yellow[600],
              size: 60,
            )),
            fit: BoxFit.contain,
          ),
        ),
      );
      File croppedFiltered;
      if (imagefile != null && imagefile.containsKey('image_filtered')) {
        croppedFiltered = imagefile['image_filtered'];
      }

      final image = FirebaseVisionImage.fromFile(croppedFiltered);
      final faceDetector = FirebaseVision.instance.faceDetector(
        FaceDetectorOptions(
          mode: FaceDetectorMode.accurate,
          enableLandmarks: true,
        ),
      );

      List<Face> faces = await faceDetector.processImage(image);
      Navigator.pop(context);
      if (faces.isEmpty) {
        setState(() {
          imgFile = File(croppedFiltered.path);
          _faces = faces;
        });
      } else {
        setState(() {
          isHuman = true;
        });
      }
    }
  }

  Future<void> _showChoiceDialogue(BuildContext context) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text("Choose Option"),
            content: SingleChildScrollView(
                child: ListBody(
              children: <Widget>[
                GestureDetector(
                  child: Text("Open Gallery"),
                  onTap: () {
                    _getImage(ImageSource.gallery);
                  },
                ),
                Padding(padding: EdgeInsets.all(8.0)),
                GestureDetector(
                  child: Text("Open Camera"),
                  onTap: () {
                    _getImage(ImageSource.camera);
                  },
                ),
              ],
            )),
          );
        });
  }

  // Uploads a picture, and gets its URL
  Future<String> uploadImage(imageFile) async {
    FBS.UploadTask upTask =
        storageRef.child("post_$postID.jpg").putFile(imgFile);
    String imgURL = await (await upTask).ref.getDownloadURL();
    return imgURL;
  }

  _addPostToChannel(caption, postRef) async {
    CollectionReference channelRef = fbFirestore.collection("channels");

    await channelRef.get().then((snapshot) {
      for (int i = 0; i < snapshot.docs.length; i++) {
        List tags = snapshot.docs[i].get("tags");

        for (String tag in tags) {
          caption = caption.toString().toLowerCase();
          tag = tag.toLowerCase();

          if (caption.contains(tag)) {
            List posts = snapshot.docs[i].get("posts");
            posts.add(postRef);
            snapshot.docs[i].reference.update({"posts": posts});
            return;
          }
        }
      }
    });
  }

  bool usedCurLoc = false;
  // Submit the post onto the posts collection
  makePostInFirestore(
      {String mediaURL, String location, String caption}) async {
    // TODO
    String uid = currentUser.uid;
    print("location is = "+location);
    await userRef.doc(uid).collection("posts").doc(postID).set({
      "postId": postID,
      "image-desc": caption,
      "image-link": mediaURL,
      "likes": [],
      "location": location,
      "timestamp": Timestamp.now(),
    });

    if (usedCurLoc == true) {
      fbFirestore.collection("globalmarkers").doc(postID).set({
        "postid": postID,
        "image-link": mediaURL,
        "location": location,
        "geolocation":
            GeoPoint(_currentPosition.latitude, _currentPosition.longitude),
        "userid": uid,
      });
    }

    String postRef = "/users/" + uid + "/posts/" + postID;

    _addPostToChannel(caption, postRef);

    setState(() {
      imgFile = null;
      isUploading = false;
      postID = Uuid().v4();
      captionController.clear();
      locationController.clear();
    });

    Navigator.pop(context);
  }


  submit() async {
    setState(() {
      isUploading = true;
    });
    //await imageCompress();
    String mediaURL = await uploadImage(imgFile);

    print("location controller.text in submit is : "+ locationController.text);

    await makePostInFirestore(
      mediaURL: mediaURL,
      location: locationController.text,
      caption: captionController.text,
    );
  }

  imageCompress() async {
    final temporaryDir = await getTemporaryDirectory();
    final path = temporaryDir.path;
    Img.Image imageFile = Img.decodeImage(imgFile.readAsBytesSync());
    final compImgFile = File('$path/img_$postID,jpg')..writeAsBytes(Img.encodeJpg(imageFile, quality: 70));

    setState(() {
      imgFile = compImgFile;

    });
  }

  Future<void> showAlertDialog(BuildContext context) async {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Center(child: Text("Error : Human Detected")),
            content: SingleChildScrollView(
                child: ListBody(
              children: <Widget>[
                Center(
                    child: Text(
                        "Our application does not allow any photos of humans. Please try again.")),
                Padding(padding: EdgeInsets.only(top: 20)),
                GestureDetector(
                  child: Center(child: Text("OK")),
                  onTap: () {
                    Navigator.pop(context);
                  },
                ),
              ],
            )),
          );
        });
  }

  String curLoc; String usersLocation = "";
  final Geolocator geolocator = Geolocator();
  Position _currentPosition;
  Future<String> _getCurrentLocation() async {
    String location = "No Location";
    GeolocationStatus geolocationStatus =
        await Geolocator().checkGeolocationPermissionStatus();
    if (geolocationStatus == GeolocationStatus.denied) {
      print("Location permission denied");
    }
    Position position = await Geolocator()
        .getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    geolocator
        .getCurrentPosition(desiredAccuracy: LocationAccuracy.best)
        .then((Position position) async {
      setState(() {
        _currentPosition = position;
        print(_currentPosition);
      });

      location =
          await _getAddressFromLatLng(); // This function is for Geocoding.
    }).catchError((e) {
      print(e);
    });

    return location;
  }

  Future<String> _getAddressFromLatLng() async {
    try {
      List<gc.Placemark> p = await gc.placemarkFromCoordinates(
          _currentPosition.latitude, _currentPosition.longitude);
      gc.Placemark place = p[0];
      setState(() {
        usersLocation = place.administrativeArea + ", " + place.country;
        print(usersLocation);
      });
    } catch (e) {
      print(e);
    }

    return usersLocation;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: new AppBar(
          title: Text("Upload Post"),
          centerTitle: true,
          actions: [
            FlatButton(
                onPressed: isUploading ? null : () => submit(),
                child: Text(
                  "Post",
                  style: TextStyle(
                      color: Colors.blueAccent,
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ))
          ],
        ),
        body: ListView(
          children: <Widget>[
            isUploading ? LinearProgressIndicator() : Text(""),
            Container(
              height: 270,
              width: MediaQuery.of(context).size.width * 0.8,
              child: Center(
                child: AspectRatio(
                    aspectRatio: 1 / 1,
                    child: InkWell(
                      onTap: () async {
                        await _showChoiceDialogue(context);
                        if (isHuman) {
                          await showAlertDialog(context);
                          setState(() {
                            isHuman = false;
                          });
                        }
                      },
                      child: imgFile == null
                          ? Center(
                              child: Text(
                              "Tap to pick an image!",
                              style: TextStyle(fontSize: 20),
                            ))
                          : Container(
                              decoration: BoxDecoration(
                                  image: DecorationImage(
                                      fit: BoxFit.cover,
                                      image: FileImage(imgFile))),
                            ),
                    )),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 10.0),
            ),
            ListTile(
              leading: CircleAvatar(
                child: buildProfilePic(currentUser.uid),
              ),
              title: Container(
                width: 250,
                child: TextField(
                  controller: captionController,
                  maxLines: null,
                  decoration: InputDecoration(
                      hintText: "Write your caption...",
                      border: InputBorder.none),
                ),
              ),
            ),
            Divider(),
            ListTile(
              leading: Icon(
                LineIcons.mapPin,
                color: Colors.yellow[600],
                size: 35.0,
              ),
              title: Container(
                width: 250,
                child: TextField(
                  enabled: false,
                  controller: locationController,
                  decoration: InputDecoration(
                      hintText: "Where was this photo taken?",
                      border: InputBorder.none),
                ),
              ),
            ),
            Container(
              width: 200.0,
              height: 100.0,
              alignment: Alignment.center,
              child: RaisedButton.icon(
                label: Text(
                  "Use Current Location",
                  style: TextStyle(color: Colors.white),
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30.0),
                ),
                color: Colors.grey[900],
                onPressed: () async {
                  await _getCurrentLocation();
                  print("done getting loc");
                  setState(() {
                    usedCurLoc = true;
                    locationController.text = usersLocation;
                  });


                  print("loc controller text="+ locationController.text);
                },
                icon: Icon(
                  LineIcons.locationArrow,
                  color: Colors.white,
                ),
              ),
            )
          ],
        ));
  }
}
