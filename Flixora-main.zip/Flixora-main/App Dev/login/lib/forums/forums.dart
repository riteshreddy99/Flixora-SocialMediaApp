import 'package:flutter/material.dart';
import 'package:login/forums/forumsSearch.dart';


class forums extends StatefulWidget {

  @override
  _forumsState createState() => _forumsState();
}

class _forumsState extends State<forums> {

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        leading:(
            IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.pop(context);
              },
            )

        ),

        title: Text("Forums",style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),),
        toolbarHeight: 65,
        backgroundColor: Colors.black87,
        actions: <Widget>[
        ],
      ),
      body: Column(
        // mainAxisAlignment: MainAxisAlignment.center,
        // crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[

          Padding(
              padding: EdgeInsets.only(top: screenSize.height/10, left: screenSize.width/15),
              child: RaisedButton.icon(
                padding: EdgeInsets.all(25),
                shape: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide(
                        color: Colors.grey.shade100
                    )
                ),
                icon: Icon(Icons.search,color: Colors.white, size: 30,),
                label: Text("Search Forums",
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 22
                  ),
                ),
                onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (context) => forumsSearch()),);
                },
                color: Colors.black87,
              )
          ),
          Padding(
              padding: EdgeInsets.only(top: screenSize.height/10, left: screenSize.width/12),
              child: RaisedButton.icon(
                padding: EdgeInsets.all(25),
                shape: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide(
                        color: Colors.grey.shade100
                    )
                ),
                icon: Icon(Icons.add,color: Colors.white, size: 30,),
                label: Text("Start a new forum",
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 22
                  ),
                ),
                onPressed: (){
                //  Navigator.push(context, MaterialPageRoute(builder: (context) =>forumsCreate()),);
                },
                color: Colors.black87,
              )
          ),
          Padding(
              padding: EdgeInsets.only(top: screenSize.height/10, left: screenSize.width/13),
              child: RaisedButton.icon(
                padding: EdgeInsets.all(25),
                shape: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide(
                        color: Colors.grey.shade100
                    )
                ),
                icon: Icon(Icons.upgrade,color: Colors.white, size: 30,),
                label: Text("Role Change Forums",
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 22
                  ),
                ),
                onPressed: (){
                  //  Navigator.push(context, MaterialPageRoute(builder: (context) => forumsSearch()),);
                },
                color: Colors.black87,
              )
          ),
        ],
      ),
      // body: buildAnimSearchBar(),
      // bottomNavigationBar: BottomNavBar(),
    );
  }
}
