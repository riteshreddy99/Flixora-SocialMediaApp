import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:line_icons/line_icons.dart';
import 'package:login/forums/createForum.dart';
import 'package:login/data/forum.dart';




TextStyle defaultDarkStyle = TextStyle(color: Colors.white, fontSize: 18.0);
TextStyle hintStyle = TextStyle(color: Colors.white54, fontSize: 18.0);
Future<QuerySnapshot> searchResultsFuture;
TextEditingController searchController = TextEditingController();

class forumsSearch extends StatefulWidget {
  static of(BuildContext context, {bool root = false}) => root
      ? context.findRootAncestorStateOfType<_forumsSearchState>()
      : context.findAncestorStateOfType<_forumsSearchState>();

  @override
  _forumsSearchState createState() => _forumsSearchState();
}

class _forumsSearchState extends State<forumsSearch> {
  final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
  final FirebaseAuth fbAuth = FirebaseAuth.instance;

  Widget buildSearchBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(15),
      child: Container(
        decoration: new BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(10)),
          color: Colors.grey[700],
        ),
        child: Container(
          child: Padding(
            padding: EdgeInsets.all(8.0),
            child: TextField(
              controller: searchController,
              onSubmitted: handleSearch,
              style: defaultDarkStyle,
              decoration: new InputDecoration(
                border: InputBorder.none,
                prefixIcon: Icon(Icons.search, color: Colors.grey),
                hintStyle: hintStyle,
                hintText: "Search for Forums",
              ),
            ),
          ),
        ),
      ),
    );
  }

  handleSearch(String query) async{

    if (query.isEmpty) return;
    CollectionReference forumSer = fbFirestore.collection("forums");
    Future<QuerySnapshot> titles =
    forumSer.where("title", isGreaterThanOrEqualTo: query).get();
    setState(() {
      searchResultsFuture = titles;
    });
  }

  buildSearch() {
    return FutureBuilder(
      future: searchResultsFuture,
      builder: (context, snapshot) {

        if (!snapshot.hasData || snapshot.hasError) {
          return SpinKitRipple(
            color: Colors.grey,
          );
        }
        else {
          List<DocumentSnapshot> docsUnfiltered = snapshot.data.docs;

          List<DocumentSnapshot> docs = [];
          docsUnfiltered.forEach((element) {
            String s = element.get("title");
            // s = s.toLowerCase();
            //
            // print(s);
            if (s.contains(searchController.text)) {
              docs.add(element);
            }
          });


          // if(docs.length == 0)
          //   return Text("No Forums found");

          return SizedBox(
            height: 200,
            child: new ListView.builder(
              itemCount: docs.length,
              itemBuilder: (BuildContext ctxt, int index) {
                var docInstance = docs[index];
                // forum nforums = forum(
                //     docInstance.get("title"),
                //     docInstance.get("info"),
                //     docInstance.get("time"),
                //     docInstance.get("status"),
                //     docInstance.get("creator"),
                // );


                // nforums.info = ;
                // nforums.time = ;
                // nforums.status = ;


                return Container(
                    decoration: BoxDecoration(
                    ),
                    child: new Card(
                      elevation: 20,

                      child: ListTile(
                        onTap: () {
                          // Navigator.push(
                          //     context,
                          //     MaterialPageRoute(
                          //         builder: (context) =>
                          //             UserProfilePage(userid: docInstance.id)));
                        },
                        // leading: CircleAvatar(
                        //   backgroundImage:
                        //   NetworkImage(docInstance.get("photoUrl")),
                        //   radius: 25,
                        // ),
                        title: Text(docInstance.get("title") ),
                        subtitle: Text(docInstance.get("info")),
                      ),
                    )
                );
              },
            ),
          );
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        leading:(
            IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.pop(context);
              },
            )
        ),
        title: Text("Forums Search",style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),),
        toolbarHeight: 65,
        backgroundColor: Colors.black87,
        actions: <Widget>[
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.yellow[700],
        child: Icon(LineIcons.pen),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => createForum()),
          );
        },
      ),
      body: Column(
        children: <Widget>[
          buildSearchBar(context),
          Expanded(
            child: searchResultsFuture == null
                ? Text("No results")
                : buildSearch(),
          ),
        ],
      ),
    );
  }
}
