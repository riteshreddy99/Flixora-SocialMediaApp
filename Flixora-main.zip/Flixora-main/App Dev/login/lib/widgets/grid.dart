import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:login/widgets/individualPost.dart';

Widget buildGridView(Size screenSize, uid) {
  final FirebaseFirestore fb = FirebaseFirestore.instance;

  Future<QuerySnapshot> getImages() {
    return fb.collection("users/" + uid + "/posts").get();
  }


  String postid;

 Future<String> getPostID(qdsnapshot) async {
   return qdsnapshot.id;
  }

  return Container(
      child: FutureBuilder(
          future: getImages(),
          builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (snapshot.connectionState == ConnectionState.done) {
              return GridView.builder(
                primary: false,
                shrinkWrap: true,
                gridDelegate:
                SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3, mainAxisSpacing: 2, crossAxisSpacing: 2
                ),
                itemCount: snapshot.data.docs.length,
                itemBuilder: (BuildContext context, int index) {
                  return FutureBuilder(
                    future: getPostID(snapshot.data.docs[index]),
                      builder: (context, AsyncSnapshot<String> pid) {
                        return Container(

                          child: GestureDetector(
                            child: Image.network(
                                snapshot.data.docs[index].data()["image-link"],
                                fit: BoxFit.fill),
                            onTap: () =>
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (context) => IndividualPost(uid: uid,pid: pid.data)),
                                ),

                          ),

                        );


                      });
                },
              );
            }
            else if (snapshot.connectionState == ConnectionState.none) {
              return Text("No data");
            }
            return SpinKitPulse(
              color: Colors.grey,
              size: 50,
            );


          }
      ),
      height: 300
  );

}
