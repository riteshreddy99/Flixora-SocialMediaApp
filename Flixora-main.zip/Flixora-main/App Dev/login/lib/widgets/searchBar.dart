// import 'package:flutter/material.dart';
//
// Widget buildSearchBar(BuildContext context) {
//   TextStyle defaultDarkStyle = TextStyle(color: Colors.white, fontSize: 18.0);
//   TextStyle hintStyle = TextStyle(color: Colors.white54, fontSize: 18.0);
//   TextEditingController searchController = TextEditingController();
//   return Padding(
//     padding: const EdgeInsets.all(15),
//     child: Container(
//       decoration: new BoxDecoration(
//         // border: Border.all(
//         //   color: Colors.grey,
//         // ),
//         borderRadius: BorderRadius.all(Radius.circular(10)),
//         color: Colors.grey[700],
//
//       ),
//       child: Container(
//         child: Padding(
//           padding: EdgeInsets.all(8.0),
//           child: TextField(
//             controller: searchController,
//             //onSubmitted: handleSearch,
//             style: defaultDarkStyle,
//             decoration: new InputDecoration(
//               border: InputBorder.none,
//               prefixIcon: Icon(Icons.search, color: Colors.grey),
//               hintStyle: hintStyle,
//               // enabledBorder: const UnderlineInputBorder(
//               //   borderSide: const BorderSide(color: Colors.white),
//               // ),
//               hintText: "Search",
//             ),
//           ),
//         ),
//       ),
//     ),
//   );
// }