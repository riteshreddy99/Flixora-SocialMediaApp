import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'dart:typed_data';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import "package:image/image.dart" as img;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:login/widgets/individualPost.dart';

void main()
{
  runApp(globalMap());
}

class globalMap extends StatefulWidget {
  @override
  globalMap({Key key}) : super(key: key);


  globalMapState createState() => globalMapState();
}

class globalMapState extends State<globalMap> {

  @override
  void initState() {
    getPhotos();
    super.initState();
  }



  Map<MarkerId, Marker> markers = <MarkerId, Marker>{};

  final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
  final FirebaseAuth fbAuth = FirebaseAuth.instance;

  ByteData imageinBytes;
  getMarkers(request, requestId) async{
    String url = request['image-link'];
    final File markerImageFile = await DefaultCacheManager().getSingleFile(url);
    final Uint8List markerImageinBytes = await markerImageFile.readAsBytes();

    Uint8List resizeImage(Uint8List bytesData) {
      Uint8List resizedImg = bytesData;
      img.Image imag = img.decodeImage(bytesData);
      img.Image resized = img.copyResize(imag, width: 75, height: 75);
      resizedImg = img.encodeJpg(resized);
      return resizedImg;
    }

    var p = request['geolocation'];
    String pid = request['postid'];
    String uid = request['userid'];
    String username;
    // String imageurl = request['image-link'];

    await fbFirestore.collection("users").doc(uid).get().then((u) => {
      username = u.get("username")
    });



    var markerIdVal = requestId;
    final MarkerId markerid = MarkerId(markerIdVal);
    final Marker marker =await  Marker(
        markerId: markerid,
        position: LatLng(p.latitude,p.longitude),
        icon:  BitmapDescriptor.fromBytes(resizeImage(markerImageinBytes)),
        onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (context) => IndividualPost(uid: uid,pid: pid,)),);
        },
        infoWindow: InfoWindow(
          title: username,
        ));
    setState(() {
      markers[markerid] = marker;

    });
  }

  getPhotos() async {
    await FirebaseFirestore.instance.collection("globalmarkers").get().then((docs){
      if(docs.docs.isNotEmpty){
        for(int i = 0; i < docs.docs.length; ++i){
           getMarkers(docs.docs[i].data(), docs.docs[i].id);
        }
      }
    });
  }

  Completer<GoogleMapController> mapController = Completer();
  static final CameraPosition initLocation = CameraPosition(target: LatLng(0, 0),);

  @override
  Widget build(BuildContext context) {
    // print("hello");
    // if (imageinBytes == null) {
    //   return Center(child: CircularProgressIndicator());
    // }
    Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        leading:(
            IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.pop(context);
              },
            )

        ),

        title: Text("Map",style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),),
        toolbarHeight: 65,
        //centerTitle: true,
        backgroundColor: Colors.black87,
        actions: <Widget>[],
      ),
      body: GoogleMap(
        myLocationEnabled: true,
        markers: Set<Marker>.of(markers.values),
        initialCameraPosition: initLocation,
        mapType: MapType.normal,
        onMapCreated: (GoogleMapController controller) {
          mapController.complete(controller);
        },
      ),

    );
  }


}