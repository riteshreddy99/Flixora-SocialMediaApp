

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:like_button/like_button.dart';
import 'package:login/data/comment.dart';
import 'package:login/profile/main-profileOther.dart';
import 'package:login/data/post.dart';
import 'package:login/helper/notifications.dart';


class PostCommentSection extends StatefulWidget {
  PostCommentSection({Key key, this.post}) : super(key: key);

  final Post post;
  PostCommentSecState createState() => PostCommentSecState();
}


class PostCommentSecState extends State<PostCommentSection> {
  final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
  final FirebaseAuth fbAuth = FirebaseAuth.instance;

  final messageController = TextEditingController();


  Future<bool> _likeComment(Comment comment) async{

    print(comment.uid);
    DocumentReference commentRef =
    fbFirestore.collection("users")
        .doc(widget.post.userid)
        .collection("posts")
        .doc(widget.post.postid)
        .collection("comments")
        .doc(comment.cid);

    await commentRef.get().then((snapshot){

          List<dynamic> likes = snapshot.get("likes");
          String currentUID = fbAuth.currentUser.uid;

          if (comment.isLiked) {
            likes.remove(currentUID);
            commentRef.update({"likes": likes});

            comment.isLiked = false;
            return comment.isLiked;
          }

          likes.add(currentUID);
          commentRef.update({"likes": likes});
          comment.isLiked = true;

    });

    if(fbAuth.currentUser.uid != comment.uid){

      DocumentReference user =
      fbFirestore.collection("users")
          .doc(fbAuth.currentUser.uid);

      String username;

      await user.get().then((snapshot) {
        username = snapshot.get("username");
      });


      if(comment.isLiked) {
        DocumentReference posterRef =
        fbFirestore.collection("users")
            .doc(comment.uid)
            .collection("notifications").doc();

        Map<String, dynamic> notifData = {
          "message": "liked your comment: " + comment.text,
          "time-sent": DateTime.now(),
          "type": "comment-like",
          "userID": fbAuth.currentUser.uid,
          "username": username,
          "refPID": widget.post.postid,
          "refUID": widget.post.userid
        };


        posterRef.set(notifData);
        sendNotif(comment.uid, "liked your comment! '" + comment.text + "'");
        }
    }
    return comment.isLiked;
  }

  Future<DocumentSnapshot> _getProfileDetails(userid) {
    return fbFirestore.doc("users/" + userid).get();
  }

  Widget buildProfilePic(userid) {
    return FutureBuilder(
        future: _getProfileDetails(userid),
        builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return CircleAvatar(
              backgroundImage: NetworkImage(snapshot.data.get("photoUrl")),
            );
          } else if (snapshot.connectionState == ConnectionState.none) {
            print("No data");
          }
          return SpinKitPulse(
            size: 30,
            color: Colors.grey,
          );
        });
  }

  Widget _buildPostDesc() {
    return ListTile(
      contentPadding:
      EdgeInsets.only(left: 20.0, top: 20.0, bottom: 20, right: 10),
      leading: CircleAvatar(
        child: buildProfilePic(widget.post.userid),
      ),
      title: Text(widget.post.user),
      subtitle: Text(widget.post.description),
    );
  }


  _deleteComment(Comment comment) async {

    DocumentReference commentRef =
    fbFirestore
        .collection("users")
        .doc(widget.post.userid)
        .collection("posts")
        .doc(widget.post.postid)
        .collection("comments")
        .doc(comment.cid);

    await commentRef.delete();
    Navigator.pop(context);

  }

  Widget _buildComments() {
    return Container(
      margin:
      const EdgeInsets.only(left: 15.0, top: 10.0, bottom: 20, right: 10),
      child: StreamBuilder(
          stream: fbFirestore
              .collection("users")
              .doc(widget.post.userid)
              .collection("posts")
              .doc(widget.post.postid)
              .collection("comments")
              .orderBy("timePosted", descending: true)
              .snapshots(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) {
              return SpinKitRipple(
                color: Colors.grey[800],
                size: 60.0,
              );
            }

            List<Comment> comments = [];

            for (DocumentSnapshot doc in snapshot.data.docs) {
              var comment = new Comment();

              bool likedBefore = false;

              for (int i = 0; i < doc.get("likes").length; i++) {
                if (fbAuth.currentUser.uid == doc.get("likes")[i])
                  likedBefore = true;
              }

              comment.user = doc.get("username");
              comment.uid = doc.get("user-id");
              comment.likes = doc.get("likes").length;
              comment.text = doc.get("text");
              comment.time = DateTime.parse(doc.get("timePosted").toDate().toString());
              comment.isLiked = likedBefore;
              comment.cid = doc.get("comment-id");

              comments.add(comment);
            }

            if (!snapshot.hasData)
              return Padding(
                padding: EdgeInsets.fromLTRB(10, 10, 5, 0),
                child: LikeButton(
                  size: 26,
                  isLiked: widget.post.isLiked,
                ),
              );
            else {
              return Container(
                  child:Expanded(
                      child: ListView.builder(
                          shrinkWrap: true,
                          physics: NeverScrollableScrollPhysics(),
                          reverse: true,
                          itemCount: comments.length,
                          itemBuilder: (context, index) {
                            final comment = comments[index];
                            return Padding(

                                padding: EdgeInsets.only(top: 10, bottom: 10),
                                child: Column(
                                  children: <Widget>[
                                    GestureDetector(
                                      child:ListTile(
                                        onTap: () {
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      UserProfilePage(
                                                          userid: comment.uid)));
                                        },
                                        leading: buildProfilePic(comment.uid),
                                        title: Text(comment.user),
                                        subtitle: Text(comment.text),
                                        trailing: IconButton(
                                          icon: LikeButton(
                                            size: 16,
                                            animationDuration:
                                            Duration(milliseconds: 1000),
                                            likeCountAnimationDuration:
                                            Duration(milliseconds: 300),
                                            likeCount: comment.likes,
                                            isLiked: comment.isLiked,
                                            onTap: (x) => _likeComment(comment),
                                          ),
                                        ),
                                      ),
                                      onTapDown: ( TapDownDetails details){
                                        if(fbAuth.currentUser.uid == widget.post.userid || fbAuth.currentUser.uid == comment.uid){
                                          showMenu(
                                            position: RelativeRect.fromLTRB(details.globalPosition.dx,details.globalPosition.dy,0,0),
                                            items: <PopupMenuEntry>[
                                              PopupMenuItem(
                                                  child: GestureDetector(
                                                      child:Row(
                                                        children: <Widget>[
                                                          Icon(Icons.delete),
                                                          Text("Delete"),
                                                        ],
                                                      ),
                                                      onTap: () async {
                                                        await _deleteComment(comment);
                                                      }
                                                  )
                                              )
                                            ],
                                            context: context,
                                          );
                                        }
                                      },
                                    )
                                  ],
                                ));
                          })));
            }
          }),
    );
  }

  _sendComment(msg) async {
    String uid = fbAuth.currentUser.uid;
    String username;

    DocumentReference userRef = fbFirestore.doc("users/" + uid);

    await userRef.get().then((snapshot) {
      username = snapshot.get("username");
    });


    DocumentReference posterRef =
    fbFirestore.collection("users")
        .doc(widget.post.userid)
        .collection("notifications").doc();



    var now = DateTime.now();


    final DocumentReference commentRef = fbFirestore
        .collection("users")
        .doc(widget.post.userid)
        .collection("posts")
        .doc(widget.post.postid)
        .collection("comments").doc();

    Map<String, dynamic> commentData = {
      "user-id": uid,
      "text": msg,
      "timePosted": now,
      "likes": [],
      "username": username,
      "comment-id":commentRef.id
    };

    commentRef.set(commentData);

    if(fbAuth.currentUser.uid != widget.post.userid) {
      sendNotif(widget.post.userid, "commented on your post '" + msg + "'");

      Map<String, dynamic> notifData = {
        "message": "commented on your post: " + msg,
        "time-sent": DateTime.now(),
        "type": "comment",
        "userID": fbAuth.currentUser.uid,
        "username": username,
        "refPID": widget.post.postid,
        "refUID": fbAuth.currentUser.uid,
      };


      posterRef.set(notifData);
    }
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          leading: (IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          )),
          title: Text("Comments"),
          toolbarHeight: 65,
          centerTitle: true,
          //backgroundColor: Colors.black87,
        ),
        body: Container(
            height: 1000,
            child: Column(children: [
              Expanded(
                  child: Expanded(
                    child: ListView(children: [
                      _buildPostDesc(),
                      new Divider(color: Colors.black),
                      _buildComments(),
                      new Divider(color: Colors.black),
                    ]),
                  )
              ),
              Align(
                alignment: Alignment.bottomLeft,
                child: Container(
                  padding: EdgeInsets.only(left: 10, bottom: 10, top: 10),
                  height: 70,
                  width: double.infinity,
                  color: Colors.grey[800],
                  child: Row(
                    children: <Widget>[
                      Divider(color: Colors.black),
                      // CircleAvatar(
                      //   backgroundImage: AssetImage('Image/profilepic.png'),
                      // ),
                      SizedBox(
                        width: 15,
                      ),
                      Expanded(
                        flex: 1,
                        child: TextField(
                          maxLines: null,
                          decoration: InputDecoration(
                              hintText: "Write message...",
                              hintStyle: TextStyle(color: Colors.white),
                              border: InputBorder.none),
                          controller: messageController,
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                      SizedBox(
                        width: 15,
                      ),
                      FloatingActionButton(
                        onPressed: () {
                          _sendComment(messageController.text);
                          messageController.clear();
                        },
                        child: Icon(
                          Icons.send,
                          color: Colors.yellow[600],
                          size: 20,
                        ),
                        backgroundColor: Colors.black,
                        elevation: 0,
                      ),
                    ],
                  ),
                ),
              ),
            ])));
  }
}
