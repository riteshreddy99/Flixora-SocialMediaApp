import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:login/data/post.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:like_button/like_button.dart';
import 'package:login/profile/main-profileOther.dart';
import 'package:login/widgets/commentsPage.dart';

class IndividualPost extends StatefulWidget {
  IndividualPost({Key key,this.uid, this.pid}) : super(key: key);

  final String uid;
  final String pid;
  IndividualPostState createState() => IndividualPostState();
}

class IndividualPostState extends State<IndividualPost> {

  void initState() {
    super.initState();
  }

  final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
  final FirebaseAuth fbAuth = FirebaseAuth.instance;


  String username = "";

  String postlocation;
  Future<Post> getUserPost() async {
    Post userPost;
    postlocation = "";

    DocumentReference postRef = fbFirestore.collection("users").doc(widget.uid).collection("posts").doc(widget.pid);
    DocumentReference userRef = fbFirestore.collection("users").doc(widget.uid);

    print(widget.uid+ "is the uid");
    print(widget.pid+ "is the pid");


    int numOfposts=0;
    bool likedBefore = false;

    await postRef.get().then((p) {

      for(int k = 0; k <  p.get("likes").length; k++){
        if (fbAuth.currentUser.uid ==  p.get("likes")[k])
          likedBefore = true;
      }

      // print(p.get("user"));

      String username = "", userid = "";
      postlocation = p.get("location");

      userPost = new Post(
          username,
          userid,
          p.id,
          p.get("image-desc"),
          p.get("image-link"),
          p.get("likes").length,
          likedBefore,
          false);


    });

    await userRef.get().then((u) {

      userPost.user =  u.get("username");
      userPost.userid = u.id;

    });

    print(userPost.userid);

    return userPost;
  }

  Future<List<Widget>> getPosts() async {

    print("getPosts");
    // Stores our posts in an array
    List<Widget> widgetPost = [];
    Post post =
    await getUserPost(); // get all the posts of users being followed by current user

    widgetPost.add(getPost(post, postlocation));

    return widgetPost;

  }

  Widget feedBody() {

    print("feedBody");
    // generate the feed of a user
    return Container(
      // color: Theme.of(context).accentColor,
      child: FutureBuilder(
          future: getPosts(),
          builder: (context, AsyncSnapshot<List<Widget>> snapshot) {
            if (snapshot.connectionState == ConnectionState.done) {
              return ListView(
                children: <Widget>[
                  Column(children: snapshot.data),
                ],
              );
            } else if (snapshot.connectionState == ConnectionState.none) {
              return Text("No data");
            }
            return SpinKitRipple(
              color: Colors.grey[800],
              size: 60.0,
            );
          }),
    );
  }


  Future<bool> _likePost(Post post) async{
    DocumentReference postRef =
    fbFirestore.collection("users")
        .doc(widget.uid)
        .collection("posts")
        .doc(post.postid);


    // String userid = post.userid;
    // DocumentReference userRef = FirebaseFirestore.instance.doc("users/" + userid);
    int points;
    int numLikes;
    // await userRef.get().then((snapshot){
    //   points = snapshot.get("points");
    // });



    await postRef.get().then((snapshot){

      List<dynamic> likes = snapshot.get("likes");
      String currentUID = fbAuth.currentUser.uid;

      // numLikes = snapshot.get("numLikes");

      if(post.isLiked) {
        likes.remove(currentUID);
        postRef.update({"likes":likes});
        // postRef.update({"numLikes":numLikes-1});

        post.isLiked = false;


        // userRef.update({"points":points-1});


        return post.isLiked;


      }

      likes.add(currentUID);
      postRef.update({"likes":likes});
      // postRef.update({"numLikes":numLikes+1});
      post.isLiked = true;

      // userRef.update({"points":points+1});

    });

    return post.isLiked;
  }

  Future<DocumentSnapshot> _getProfileDetails(userid){
    return  fbFirestore.doc("users/" + userid).get();
  }

  Widget buildProfilePic(userid) {
    return FutureBuilder(
        future: _getProfileDetails(userid),
        builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return Container(
              margin: EdgeInsets.all(5),
              width: 40.0,
              height: 40.0,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: NetworkImage(snapshot.data.get("photoUrl")),
                  fit: BoxFit.cover,
                ),
                borderRadius: BorderRadius.circular(80.0),
                border: Border.all(
                  color: Colors.grey[800],
                  width: 1.0,
                ),
              ),
            );
          }

          else if (snapshot.connectionState == ConnectionState.none) {
            print("No data");
          }
          return SpinKitPulse(
            size: 30,
            color: Colors.grey,
          );
        }
    );
  }

  _deletePost(Post post) async {
    print("starting process");



    DocumentReference postRef =
    fbFirestore
        .collection("users")
        .doc(post.userid)
        .collection("posts")
        .doc(post.postid);

    await Navigator.pop(context);
    await Navigator.pop(context);


    CollectionReference mapRef =      // delete from map
    fbFirestore
    .collection("globalmarkers");

    await mapRef.get().then((snapshot) => snapshot.docs.forEach((p) {
      if (p.id==post.postid) {
        fbFirestore
            .collection("globalmarkers")
            .doc(post.postid)
            .delete()
            .then((value) =>
            {print("post deleted from map")});
      }
    }));


    
    CollectionReference channelRef =      // del from channels
    fbFirestore
    .collection("channels");

    String postLink = "/users/" + post.userid + "/posts/" + post.postid;

    await channelRef.get().then((snapshot){
      for(int i =0; i < snapshot.docs.length; i++){

        List<dynamic> listPosts = snapshot.docs[i].get("posts");

        String postToRemove;
        
        for (String post in listPosts){
          if(postLink == post){
            postToRemove = post;
            break;
          }
        }

        listPosts.remove(postToRemove);

        snapshot.docs[i].reference.update({"posts":listPosts});
      }
    });

    CollectionReference commentsRef =
      postRef.collection("comments");     // delete all comments in post

    await commentsRef.get().then((snapshot){
      for(int i = 0; i < snapshot.docs.length; i++){
        snapshot.docs[i].reference.delete();
      }
    });

    await postRef.delete();

    Navigator.pop(context);
    Navigator.popAndPushNamed(context,'/home');

    print("deleted post");


  }

  Widget getPost(Post post, String location) {
    // Function to create the post widgets

    return Padding(
      padding: const EdgeInsets.only(top: 25, left: 20, right: 20),
      child: Card(
        elevation: 20,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0),
        ),
        child: Column(
          children: [

            GestureDetector(
              onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) =>
                              UserProfilePage(
                                  userid: post.userid)));

              },
              child: ListTile(
                minLeadingWidth: 50,
                leading: buildProfilePic(post.userid),
                title: Text(post.user),
                subtitle: Text(location),
                trailing:
                GestureDetector(
                  child:Icon(Icons.more_vert),
                  onTapDown: (TapDownDetails details){
                    if(fbAuth.currentUser.uid == post.userid){
                      showMenu(
                        position: RelativeRect.fromLTRB(details.globalPosition.dx,details.globalPosition.dy,0,0),
                        items: <PopupMenuEntry>[
                          PopupMenuItem(
                            child: GestureDetector(
                              child:Row(
                                children: <Widget>[
                                  Icon(Icons.delete),
                                  Text("Delete"),
                                ],
                              ),
                              onTap: () async {
                                await _deletePost(post);
                              }
                            )
                          )
                        ],
                        context: context,
                      );
                    }
                  },
                ),
              ),
            ),
            Container(
              child: Image.network(post.pictureLink),
            ),

            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  StreamBuilder(
                      stream:  fbFirestore.collection("users")
                          .doc(widget.uid)
                          .collection("posts")
                          .doc(post.postid).snapshots(),
                      builder: (context,snapshot) {
                        if(!snapshot.hasData)
                          return Padding(
                            padding: EdgeInsets.fromLTRB(10, 10, 5, 0),
                            child: LikeButton(
                              size: 26,
                              isLiked: post.isLiked,
                            ),
                          );
                        else {
                          return Padding(
                            padding: EdgeInsets.fromLTRB(10, 10, 5, 0),
                            child: LikeButton(
                              size: 26,
                              animationDuration: Duration(milliseconds: 1000),
                              likeCountAnimationDuration: Duration(
                                  milliseconds: 300),
                              likeCount: snapshot.data["likes"].length,
                              isLiked: post.isLiked,
                              onTap: (x) => _likePost(post),
                            ),
                          );
                        }
                      }
                  ),
                  Padding(
                    padding: EdgeInsets.fromLTRB(10, 10, 5, 0),
                    child: LikeButton(
                      bubblesColor: BubblesColor(
                        dotPrimaryColor: Colors.purple,
                        dotSecondaryColor: Colors.green,
                      ),
                      likeBuilder: (bool isCommented) {
                        return Icon(Icons.messenger_outline_rounded);
                      },
                      onTap: (x) {
                        return Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => PostCommentSection(
                                    post: post
                                )
                            )
                        );
                      },
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.fromLTRB(10, 10, 5, 0),
                    child: LikeButton(
                      size: 26,
                      bubblesColor: BubblesColor(
                        dotPrimaryColor: Colors.blue,
                        dotSecondaryColor: Colors.green,
                      ),
                      likeBuilder: (bool isShared) {
                        return Icon(Icons.share_outlined);
                      },
                    ),
                  ),
                ],
              ),
            ),
            Column(
              children: [
                SizedBox(
                  height: 5,
                ),
                Padding(
                  padding: EdgeInsets.all(10),
                  child: Container(child: Text(post.description)),
                ),
                SizedBox(
                  height: 10,
                )
              ],
            ),
          ],
        ),
      ),
    );
  }







  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading:(
            IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.pop(context);
              },
            )

        ),

        title: Text("Post",style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),),
        toolbarHeight: 65,
        //centerTitle: true,
        backgroundColor: Colors.black87,
      ),
      body: feedBody(),

    );
  }


}