import 'package:flutter/material.dart';
import 'package:line_icons/line_icon.dart';
import 'package:line_icons/line_icons.dart';
import 'package:login/challenges/challengeList.dart';
import 'package:login/helper/profile-image.dart';
import 'package:login/leaderboard/main-leaderboard.dart';
import 'package:login/challenges/challenge.dart';
import 'package:login/main.dart';
import 'package:login/revampedSignup/signIn.dart';
import 'package:provider/provider.dart';
import 'package:login/revampedSignup/AuthenService.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:login/channels/channels.dart';
import 'package:login/widgets/globalmap.dart';
import 'package:login/settings/settingsPage.dart';
import 'package:login/forums/forumsSearch.dart';

TextStyle defaultDarkStyle =  TextStyle(color: Colors.white, fontSize: 20.0);
TextStyle optionalDarkStyle = TextStyle(color: Colors.grey, fontSize: 18.0);

final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
final FirebaseAuth fbAuth = FirebaseAuth.instance;

Future<DocumentSnapshot> _getProfileDetails(){
  String uid = fbAuth.currentUser.uid;
  return  fbFirestore.doc("users/" + uid).get();
}


Widget _buildProfileDetails() {
  return Container(
    child: new DrawerHeader(
        child:Column(
            children: [
              new Container(
                  child: Row(
                    children: [
                      buildProfilePic(fbAuth.currentUser.uid),
                      new SizedBox(width: 10),
                      FutureBuilder(
                          future: _getProfileDetails(),
                          builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
                            if (snapshot.connectionState == ConnectionState.done) {

                              String username = snapshot.data.get("username");
                              return Text(username,style:defaultDarkStyle);
                            }

                            else if (snapshot.connectionState == ConnectionState.none) {
                              print("No data");
                            }
                            return CircularProgressIndicator();
                          }
                      ),
                    ],
                  )
              ),
              new SizedBox(height: 15),
              new Container(
                  child: Row(
                    children: [
                      new SizedBox(width:5),
                      FutureBuilder(
                          future: _getProfileDetails(),
                          builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
                            if (snapshot.connectionState == ConnectionState.done) {

                              int followers = snapshot.data.get("followers").length;
                              return Text(followers.toString(),style:defaultDarkStyle);
                            }

                            else if (snapshot.connectionState == ConnectionState.none) {
                              print("No data");
                            }
                            return CircularProgressIndicator();
                          }
                      ),
                      new SizedBox(width:5),

                      new Text("Followers",style: optionalDarkStyle),
                      new SizedBox(width:15),
                      FutureBuilder(
                          future: _getProfileDetails(),
                          builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
                            if (snapshot.connectionState == ConnectionState.done) {

                              int followers = snapshot.data.get("following").length;
                              return Text(followers.toString(),style:defaultDarkStyle);
                            }

                            else if (snapshot.connectionState == ConnectionState.none) {
                              print("No data");
                            }
                            return CircularProgressIndicator();
                          }
                      ),
                      new SizedBox(width:5),
                      new Text("Following",style: optionalDarkStyle),
                    ],
                  )
              )
            ]
        )
    ),
    //  color: Colors.black87,
  );

}

Widget _buildButtons(){
  return Container(
    child: Column(
      children: [],
    ),
    //color: Colors.black,
  );

}


Widget buildDrawer(BuildContext context){
  return Drawer(
      child: Container(
        child: ListView(
            children: [
              _buildProfileDetails(),
              new Divider(color: Colors.white),

              new ListTile(
                title: Text("Challenges", style: defaultDarkStyle, ),
                leading: new IconButton(
                  iconSize: 30,
                  icon: Icon(
                    LineIcons.flag,
                    color: Colors.yellow[700],
                  ),
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context) => ChallengeList()),);
                  },
                ),
                hoverColor: Colors.black87,
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => ChallengeList()),);
                },
              ),
              new ListTile(
                title: Text("Map", style: defaultDarkStyle, ),
                leading: new IconButton(
                  iconSize: 30,
                  icon: Icon(
                    Icons.map,
                    color: Colors.yellow[700],
                  ),
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context) => globalMap()),);
                  },
                ),
                hoverColor: Colors.black87,
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => globalMap()),);
                },
              ),
              new ListTile(
                title: Text("Channels", style: defaultDarkStyle, ),
                leading: new IconButton(
                  iconSize: 30,
                  icon: Icon(
                    Icons.collections_outlined ,
                    color: Colors.yellow[700],
                  ),
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context) => ChannelsPage()),);
                  },
                ),
                hoverColor: Colors.black87,
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => ChannelsPage()),);
                },
              ),
              new ListTile(
                title: Text("Settings", style: defaultDarkStyle),
                leading: new IconButton(
                  iconSize: 30,
                  icon: Icon(
                    LineIcons.cog,
                    color: Colors.yellow[700],
                  ),
                  onPressed: (){
                    Navigator.push(context, MaterialPageRoute(builder: (context) => SettingsPage()),);
                  },
                ),
                hoverColor: Colors.black87,
                onTap: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context) => SettingsPage()),);
                },
              ),
              new ListTile(
                  title: Text("Sign Out", style: defaultDarkStyle),
                  leading: new IconButton(
                    iconSize: 30,
                    icon: Icon(
                      LineIcons.alternateSignOut,
                      color: Colors.yellow[700],
                    ),
                    onPressed: (){
                      context.read<AuthenService>().signOut();
                      Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context) => MyApp()), (route) => false);
                    },
                  ),
                  hoverColor: Colors.black87,
                  onTap: () {
                    context.read<AuthenService>().signOut();
                    Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context) => MyApp()), (route) => false);

                  }
              ),
              new Divider(color: Colors.white),

            ]
        ),
      )
  );
}
