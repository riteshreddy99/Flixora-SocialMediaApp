import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:bubble/bubble.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:login/helper/notifications.dart';

void main() => runApp(ChatScreen());

class ChatScreen extends StatefulWidget {
  ChatScreen({Key key, this.userProfileId, this.userName}) : super(key: key);

  final String userProfileId;
  final String userName;
  ChatScreenState createState() => ChatScreenState();
}

class Message{
  String sentBy;
  String msg;
  Timestamp timeSent;
}


class ChatScreenState extends State<ChatScreen> {

  final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
  final FirebaseAuth fbAuth = FirebaseAuth.instance;

  final messageController = TextEditingController();


  static const styleSomebody = BubbleStyle(
    color: Color(0xfffdd835),
    elevation: 4,
    margin: BubbleEdges.only(top: 8, right: 50),

    alignment: Alignment.bottomLeft,
  );

  static const styleMe = BubbleStyle(
    color:Color(0xfffff8e1) ,
    elevation: 4,
    margin: BubbleEdges.only(top: 8, left: 50),
    alignment: Alignment.bottomRight,
  );


  _sendText(msg) async{
    String uid = fbAuth.currentUser.uid;
    String chatUserID = widget.userProfileId;

    int hash = _generateHash(chatUserID, uid);
    var now = DateTime.now();

    Map<String, dynamic> msgData = {
      "sent-by": uid,
      "text-msg": msg,
      "time-sent": now,
    };

    final CollectionReference chatRef =
    FirebaseFirestore.instance
        .collection('/messages')
        .doc(hash.toString())
        .collection(hash.toString());

    chatRef.add(msgData);
    sendNotif(chatUserID, msg);

  }

  int _generateHash(chatUserID, uid) =>
      (<String>[chatUserID, uid]..sort()).join().hashCode;


  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    int hash = _generateHash(widget.userProfileId, fbAuth.currentUser.uid);
    return Scaffold(
      appBar: AppBar(


        leading:(
            IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.pop(context);
              },
            )

        ),
        flexibleSpace: SafeArea(
          child: Container(
            margin: EdgeInsets.only(left: 95),
            height: 0,
            //    color: Colors.yellow,
            child: Row(
              children: <Widget>[
                CircleAvatar(
                  backgroundImage: AssetImage('Image/profilepic.png'),
                )
              ],
            ),
          ),
        ),
        title: Text(widget.userName,style: TextStyle(color: Colors.amber[100])),
        toolbarHeight: 65,
        centerTitle: true,
        elevation: 9,
        backgroundColor: Colors.black,
        shadowColor: Colors.grey[800],
        actions: <Widget>[
          IconButton(
            icon: Icon(
              Icons.info_outline_rounded,
              color: Colors.white,
            ),
            //onPressed: (){},
          ),
        ],
      ),

      body: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.end,
          children: <Widget>[

            StreamBuilder(
                stream: fbFirestore
                    .collection("messages")
                    .doc(hash.toString()).collection(hash.toString())
                    .orderBy("time-sent", descending: true)
                    .snapshots(),
                builder: (context,snapshot){
                  if(!snapshot.hasData) {
                    return SpinKitRipple(
                      color: Colors.grey[800],
                      size: 60.0,
                    );
                  }
                  else {
                    var messages = new List<Message>();

                    for (DocumentSnapshot doc in snapshot.data.docs) {
                      Message msg = new Message();

                      msg.msg = doc.get("text-msg");
                      msg.sentBy = doc.get("sent-by");
                      msg.timeSent = doc.get("time-sent");

                      messages.add(msg);
                    }

                    TextStyle _darkTextStyle = TextStyle(
                      fontFamily: 'Roboto',
                      color: Colors.black,
                      fontSize: 20.0,
                      // fontWeight: FontWeight.w700,
                    );

                    if (messages.isEmpty) {
                      return Text("Say Hi :)");
                    }
                    else {
                      return Expanded(
                          child: ListView.builder(
                            shrinkWrap: true,
                            physics: BouncingScrollPhysics(),
                            reverse: true,

                            itemCount: messages.length,
                            itemBuilder: (context, index) {
                              final message = messages[index];
                              BubbleStyle msgStyle;

                              if (message.sentBy == fbAuth.currentUser.uid)
                                msgStyle = styleMe;
                              else
                                msgStyle = styleSomebody;

                              return Bubble(
                                child: Text(message.msg, style: _darkTextStyle),
                                style: msgStyle,
                                elevation: 5,
                                shadowColor: Colors.black,
                              );
                            },
                          )
                      );
                    }
                  }
                }
            ),
            new SizedBox(height:20),
            Align(
              alignment: Alignment.bottomLeft,

              child: Container(
                padding: EdgeInsets.only(left: 10,bottom: 10,top: 10),
                height: 60,

                width: double.infinity,
                color: Colors.grey[900],

                child: Row(
                  children: <Widget>[
                    GestureDetector(
                      onTap: (){
                      },
                      child: Container(
                        height: 30,
                        width: 30,
                        decoration: BoxDecoration(
                          color: Colors.black,
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: Icon(Icons.add, color: Colors.yellow[600], size: 18, ),
                      ),
                    ),
                    SizedBox(width: 15,),

                    Expanded(
                      child: TextField(

                        decoration: InputDecoration(
                          hintText: "Write message...",
                          hintStyle: TextStyle(color: Colors.white70),
                          border: InputBorder.none,


                        ),
                        controller: messageController,

                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                    SizedBox(width: 15,),
                    FloatingActionButton(
                      onPressed: (){
                        _sendText(messageController.text);
                        messageController.clear();
                      },
                      child: Icon(Icons.send,color: Colors.yellow[600],size: 18,),
                      backgroundColor: Colors.black,
                      elevation: 0,
                    ),
                  ],

                ),
              ),
            ),
          ]
      ),
    );
  }


}
