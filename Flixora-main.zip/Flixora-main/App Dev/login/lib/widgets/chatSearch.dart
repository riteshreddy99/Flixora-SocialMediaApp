import 'chatscreen.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'chatList.dart';

class ChatSearch extends StatefulWidget {
  ChatSearch({Key key,this.usernames, this.userIDs}) : super(key: key);
  final List<String> userIDs;
  final List<String> usernames;

  @override
  ChatSearchState createState() => ChatSearchState();
}


class ChatSearchState extends State<ChatSearch> {
  final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
  final FirebaseAuth fbAuth = FirebaseAuth.instance;
  bool _isLoading = false;
  TextStyle defaultDarkStyle = TextStyle(color: Colors.white, fontSize: 18.0);
  TextStyle hintStyle = TextStyle(color: Colors.white54, fontSize: 18.0);
  List<int> searchResults = [];
  TextEditingController searchControl = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    setState(() {
      _isLoading=false;
    });
  }

  Future<DocumentSnapshot> _getProfileDetails(userid) {
    return fbFirestore.doc("users/" + userid).get();
  }

  Widget buildProfilePic(userid) {
    return FutureBuilder(
        future: _getProfileDetails(userid),
        builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return CircleAvatar(
              backgroundImage: NetworkImage(snapshot.data.get("photoUrl")),
            );
          } else if (snapshot.connectionState == ConnectionState.none) {
            print("No data");
          }
          return SpinKitPulse(
            size: 30,
            color: Colors.grey,
          );
        });
  }


  Widget _buildChatBox(userid,username,message) {
    return ListTile(
      contentPadding:
      EdgeInsets.only(left: 10.0, top: 5.0, bottom: 5, right: 10),
      leading: CircleAvatar(
        child: buildProfilePic(userid),
      ),
      title: Text(username),
      subtitle: Text(message),
        onTap: () =>
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => ChatScreen(
                        userProfileId: userid,
                        userName: username
                    )
                )
            ) // Navigator
    );
  }


  Widget buildSearchBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(15),
      child: Container(
        decoration: new BoxDecoration(
          // border: Border.all(
          //   color: Colors.grey,
          // ),
          borderRadius: BorderRadius.all(Radius.circular(10)),
          color: Colors.grey[700],
        ),
        child: Container(
          child: Padding(
            padding: EdgeInsets.all(8.0),
            child: TextField(
              controller: searchControl,
              onSubmitted: handleSearch,
              style: defaultDarkStyle,
              decoration: new InputDecoration(
                border: InputBorder.none,
                prefixIcon: Icon(Icons.search, color: Colors.grey),
                hintStyle: hintStyle,
                // enabledBorder: const UnderlineInputBorder(
                //   borderSide: const BorderSide(color: Colors.white),
                // ),
                hintText: "Search",
              ),
            ),
          ),
        ),
      ),
    );
  }

  handleSearch(String query){
    setState(() {
      _isLoading=true;
    });
    searchResults = [];

    if (searchControl.text.isEmpty) return;
    print("Searching...");
    print(widget.usernames.toString());
    for(int i = 0; i < widget.usernames.length; i++) {

      if (widget.usernames[i].toLowerCase().contains(searchControl.text.toLowerCase())) {
        searchResults.add(i);
      }
    }
   // _buildSearchList();
    print(searchResults);
    setState(() {
      _isLoading=false;
    });

  return searchResults;
  }


  _buildSearchList() {
    return ListView.builder(
        shrinkWrap: true,
        physics: BouncingScrollPhysics(),
        itemCount: searchResults.length,
        itemBuilder: (context, index) {
          print(index);
          int num = searchResults[index];
          return _buildChatBox(widget.userIDs[num],widget.usernames[num],"Say hello!");
        }

    );
  }
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        leading:(
            IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.pop(context);
                Navigator.pop(context);
                Navigator.push(context, MaterialPageRoute(builder: (context) => ChatList()),);
              },
            )

        ),

        title: Text("Chat Search",style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),),
        toolbarHeight: 65,
        //centerTitle: true,

      ),
        body: _isLoading
        ?Center(
        child: CircularProgressIndicator())
        :
         Stack(
        children: <Widget>[

          SafeArea(
            child: SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  buildSearchBar(context),
                  _buildSearchList(),

                ],
              ),
            ),
          )
        ],
      ),

    );
  }


}