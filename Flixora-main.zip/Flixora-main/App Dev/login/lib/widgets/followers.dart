import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:login/profile/main-profileOther.dart';



class FollowersPage extends StatefulWidget {
  FollowersPage({Key key, this.userid}) : super(key: key);

  final String userid;

  FollowersPageState createState() => FollowersPageState();
}

class FollowersPageState extends State<FollowersPage> {
  @override
  void initState() {
    super.initState();
  }



  final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
  final FirebaseAuth fbAuth = FirebaseAuth.instance;


  int numFollowers= 0;
  List<String> followers = new List<String>();
  List<String> usernames = new List<String>();
  List<String> profilepics = new List<String>();



  Future<List<String>> _getFollowers() async {
    numFollowers = 0;
    followers.clear();
    usernames.clear();
    profilepics.clear();
    // print("getfollowing");

    DocumentReference userRef = FirebaseFirestore.instance.doc("users/" + widget.userid);

    await userRef.get().then((snapshot) {

      numFollowers = snapshot.get("followers").length;

      for (int i = 0; i < numFollowers; i++) {

        followers.add(snapshot.get("followers")[i]);

      }
    });

    // print("following length = "+ following.length.toString());
    for (int i = 0; i < followers.length; i++) {

      DocumentReference followersRef = fbFirestore.doc("users/" + followers[i]);

      await followersRef.get().then((userData) {
        // print(userData.get("username"));
        usernames.add(userData.get("username"));
        profilepics.add(userData.get("photoUrl"));

      });
    }


    return followers;
  }

  Widget _buildFollowersTile(screenSize) {
    // print("here");
    return Container(
      // height: screenSize.height,
      child: Row(
        children: <Widget>[
          FutureBuilder(
            future: _makeFollowingList(screenSize),
            builder: (context, AsyncSnapshot<List<Widget>> snapshot) {
              if (snapshot.connectionState == ConnectionState.done) {

                return Expanded(child: Column(children: snapshot.data));

              }
              else if (snapshot.connectionState == ConnectionState.none) {

                return Text("No data");
              }

              return Padding(
                padding: const EdgeInsets.only(bottom: 150),
                child: Container(
                    height: MediaQuery.of(context).size.height,
                    width: MediaQuery.of(context).size.width,
                    child: SpinKitFadingCube(
                      color: Colors.yellow[600],
                      size: 60,
                    )),
              );
            },
          ),

          // SizedBox(height: 6,),
          //  Text("Frontend developer",style: TextStyle(fontSize: 13,color: Colors.grey.shade600, ),),
        ],
      ),
    );
  }

  Future<DocumentSnapshot> _getProfileDetails(userid) {
    return fbFirestore.doc("users/" + userid).get();
  }

  Widget buildProfilePic(userid) {
    return FutureBuilder(
        future: _getProfileDetails(userid),
        builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return Container(
              margin: EdgeInsets.all(5),
              width: 50.0,
              height: 50.0,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: NetworkImage(snapshot.data.get("photoUrl")),
                  fit: BoxFit.cover,
                ),
                borderRadius: BorderRadius.circular(80.0),
                border: Border.all(
                  color: Colors.grey[800],
                  width: 1.0,
                ),
              ),
            );
          } else if (snapshot.connectionState == ConnectionState.none) {
            print("No data");
          }
          return Text("");
        });
  }

  Widget _makeFollowers(userid, username, profilepic, screenSize) {
    return InkWell(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SizedBox(height: 20, width: 12,),
          Row(children: <Widget>[
            SizedBox(height: 20, width: 20),
            // incPosition(),
            GestureDetector(
              child: Row(
                children: [
                  // buildProfilePic(userid),
                  CircleAvatar( backgroundImage: NetworkImage(profilepic),),

                  SizedBox(height: 20, width: 20),

                  Text(
                    username,
                    style: TextStyle(
                        fontSize: 18, fontWeight: FontWeight.w900),
                  ),
                ],
              ),

              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => UserProfilePage(
                          userid: userid,

                        )));
              },
            ),

            // SizedBox(height: 20, width: 20),
            // buildProfilePic(userid),



            // buildPostPic(postid),
            Divider(
              color: Colors.grey,
            )
          ]),
          SizedBox(height: 20, width: 12),
        ],
      ),
    );
  }

  Future<List<Widget>> _makeFollowingList(screenSize) async {
    List<String> challenges = await _getFollowers();

    List<Widget> widgetChallenges = [];

    print("make following list "+numFollowers.toString());
    for (int i = 0; i < numFollowers; i++) {

      widgetChallenges.add(_makeFollowers(
          followers[i],
          usernames[i],
          profilepics[i],
          screenSize));

    }

    return widgetChallenges;
  }

  // DocumentReference challenge = fbFirestore.doc("challenges/");

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        leading: (IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        )),

        title: Text(
          "Followers",
          //style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),
        ),

        actions: <Widget>[],
      ),

      body: Stack(
        children: <Widget>[
          SafeArea(
            child: SingleChildScrollView(
              child: Column(

                children: <Widget>[

                  _buildFollowersTile(screenSize),

                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
