import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

  @override
  Widget uploadButton(BuildContext context) {

    return FloatingActionButton(
        onPressed: () {},
        child: Icon(
          Icons.add,
          color: Colors.white,
    ),
      backgroundColor: Colors.black,

    );


}

