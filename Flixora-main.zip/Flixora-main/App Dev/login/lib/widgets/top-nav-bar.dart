import 'package:flutter/material.dart';
import 'package:login/widgets/chatList.dart';
import 'package:login/likes.dart';

// Common top navigation bar, includes, hamburger icon, messages icon & notifications icon.

Widget buildTopNavBar(BuildContext context) {
  return AppBar(
    title: Text("Flixora",style: TextStyle(color: Color(0xfffdd835))),
    toolbarHeight: 65,
    centerTitle: true,
    backgroundColor: Colors.black,
    actions: <Widget>[
      IconButton(
        icon: Icon(
          Icons.favorite_outline_rounded,
          color: Colors.white,
        ),
        onPressed: (){
          Navigator.push(context, MaterialPageRoute(builder: (context) => LikesPage()),);
        },
      ),
      IconButton(
        icon: Icon(
          Icons.messenger_outline_rounded,
          color: Colors.white,
        ),
        onPressed: (){
          Navigator.push(context, MaterialPageRoute(builder: (context) => ChatList()),);
        },
      )
    ],
  );
}



