import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'chatSearch.dart';
import 'package:login/widgets/chatscreen.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';

class ChatList extends StatefulWidget {
  ChatListState createState() => ChatListState();
}


class ChatListState extends State<ChatList> {

  @override
  void initState() {
    print("init");
    super.initState();
    initializeDateFormatting();
  }

  final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
  final FirebaseAuth fbAuth = FirebaseAuth.instance;
  TextStyle defaultDarkStyle = TextStyle(color: Colors.white, fontSize: 18.0);
  TextStyle hintStyle = TextStyle(color: Colors.white54, fontSize: 18.0);
  TextEditingController searchControl = TextEditingController();
  List<String> users;
  List<String> usernames;

  Future<DocumentSnapshot> _getProfileDetails(userid) {
    return fbFirestore.doc("users/" + userid).get();
  }

  Widget buildProfilePic(userid) {
    return FutureBuilder(
        future: _getProfileDetails(userid),
        builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return CircleAvatar(
              backgroundImage: NetworkImage(snapshot.data.get("photoUrl")),
            );
          } else if (snapshot.connectionState == ConnectionState.none) {
            print("No data");
          }
          return SpinKitPulse(
            size: 30,
            color: Colors.grey,
          );
        });
  }


  // This function gets all the users the current user is followers
  Future<List<String>> _getUsers() async {
    String uid = fbAuth.currentUser.uid;

    DocumentReference userRef = fbFirestore.doc("users/" + uid);
    users = [];

    await userRef.get().then((snapshot) {
      int numOfFollowers = snapshot.get("followers").length;
      int numOfFollowing = snapshot.get("following").length;

      for (int i = 0; i < numOfFollowers; i++) {
        users.add(snapshot.get("followers")[i]);

      }

      for (int i = 0; i < numOfFollowing; i++) {
        if(!users.contains(snapshot.get("following")[i]))
          users.add(snapshot.get("following")[i]);
      }
    });
    return users;
  }

  Future<List<String>> _getChatData(users) async{
    usernames = [];

    for (String userID in users){

      if (userID.length != 28) {
        continue;
      }

      DocumentReference userRef = fbFirestore.doc("users/" + userID);

      await userRef.get().then((snapshot) {
        String fname = snapshot.get("first-name");
        String lname = snapshot.get("last-name");
        String username = fname +  " " + lname;
        usernames.add(username);
      });

    }
    return usernames;
  }

  int _generateHash(chatUserID, uid) =>
      (<String>[chatUserID, uid]..sort()).join().hashCode;

  Future<Map<String,dynamic>> _getLastMessage(hash) async{

    final Map<String,dynamic> lastMessage = {
      "msg" : "Say Hello!",
      "time" : "",
      "compareTime" : Timestamp(0, 0)
    };

    final doc = await fbFirestore.collection("messages")        // check if any messages have been sent
        .doc(hash.toString()).collection(hash.toString())
        .get();

      if(doc.docs.length == 0)
        return lastMessage;

    Stream<QuerySnapshot> msgRef = fbFirestore
        .collection("messages")
        .doc(hash.toString()).collection(hash.toString())
        .orderBy("time-sent", descending: true).snapshots();


    await msgRef.first.then((snapshot){

      lastMessage["msg"] = snapshot.docs[0].data()["text-msg"];

      lastMessage["compareTime"] = snapshot.docs[0].data()["time-sent"];

      var time = DateFormat.Md()
          .format(DateTime
          .parse(snapshot.docs[0].data()["time-sent"]
          .toDate().toString()));

      if(DateFormat.Md().format(DateTime.now()).toString() != time.toString()) {
        lastMessage["time"] = time;
      }
      else {
        lastMessage["time"] =
          DateFormat.jm()
          .format(DateTime
          .parse(snapshot.docs[0].data()["time-sent"]
          .toDate().toString()));
      }

    });

    return lastMessage;
  }

  Widget _buildChatBox(userid,username,message,time) {
    return ListTile(
      contentPadding:
      EdgeInsets.only(left: 10.0, top: 5.0, bottom: 5, right: 10),
      leading: CircleAvatar(
        child: buildProfilePic(userid),
      ),
      title: Text(username),
      subtitle: Text(message),
      trailing:Text(time.toString(), style: TextStyle(fontSize: 15)
    ),
    );
  }

  Widget _makeChat(followerName,followerID,screenSize,msg,time){
    return Container(
        width: screenSize.width,
        //       color: Colors.yellow,
        child:InkWell(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                _buildChatBox(followerID,followerName,msg,time),
              ],
            ),
            onTap: () =>
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ChatScreen(
                            userProfileId: followerID,
                            userName: followerName
                        )
                    )
                ) // Navigator
        )

    );
  }

  Future<List<Widget>> _makeChatList(screenSize) async{

    users = await _getUsers();
    print(users);
    usernames = await _getChatData(users);
    print("start");
    Map<Widget,dynamic> widgetChats = {};

    for (int i = 0; i < usernames.length; i++){

      int hash = _generateHash(users[i], fbAuth.currentUser.uid);

      print(usernames[i]);

      final doc = await fbFirestore.collection("messages")        // check if any messages have been sent
          .doc(hash.toString()).collection(hash.toString())
          .get();

      if(doc.docs.length == 0)
        continue;

      Map<String,dynamic> lastMsg = await _getLastMessage(hash);
      widgetChats[(_makeChat(usernames[i],users[i],screenSize,lastMsg["msg"],lastMsg["time"]))] = lastMsg["compareTime"];
    }

    var sortedKeys = widgetChats.keys.toList(growable:false)
      ..sort((k1, k2) => widgetChats[k1].compareTo(widgetChats[k2]));

    Map<Widget,dynamic> sortedMap = new Map<Widget,dynamic>
        .fromIterable(sortedKeys, key: (k) => k, value: (k) => widgetChats[k]);

    List<Widget> sortedWidgetChats = sortedMap.keys.toList().reversed.toList();
    print(sortedWidgetChats);
    return sortedWidgetChats;

  }

  Widget _buildChatTile(screenSize) {
    return Container(
      height: screenSize.height,
      child: Column(
        children: <Widget>[

          FutureBuilder(
            future: _makeChatList(screenSize),
            builder:(context, AsyncSnapshot<List<Widget>> snapshot) {
              if(snapshot.data == null){    // red screen on open if this not given
                print("null");
                return
                  Column(
                      children:[
                        SizedBox(height:150),
                        SpinKitCircle(color: Colors.yellow,)
                      ]
                  );

              }
              if(snapshot.data.isEmpty){
                return Padding(
                    padding: EdgeInsets.all(30),
                    child: Column(
                        children:[
                          SizedBox(height:150),
                          Text(
                              "No messages yet, use the search bar to say hello!",
                              style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500)
                          )
                        ]
                    )
                );
              }
              else if (snapshot.connectionState == ConnectionState.done) {
                return ListView(
                  shrinkWrap: true,
                  children:  snapshot.data
                );
              }
              else if (snapshot.connectionState == ConnectionState.none) {
                return Text("No data");
              }
              return
                Column(
                  children:[
                    SizedBox(height:150),
                    SpinKitCircle(color: Colors.yellow,)
                  ]
              );
            },
          ),
        ],
      ),
    );
  }

  Widget buildSearchBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(15),
      child: Container(
        decoration: new BoxDecoration(
          // border: Border.all(
          //   color: Colors.grey,
          // ),
          borderRadius: BorderRadius.all(Radius.circular(10)),
          color: Colors.grey[700],
        ),
        child: Container(
          child: Padding(
            padding: EdgeInsets.all(8.0),
            child: TextField(
              readOnly: true,
              onTap: () {
                return Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) =>
                            ChatSearch(usernames: usernames, userIDs: users,)));
              },
              style: defaultDarkStyle,
              decoration: new InputDecoration(
                border: InputBorder.none,
                prefixIcon: Icon(Icons.search, color: Colors.grey),
                hintStyle: hintStyle,
                // enabledBorder: const UnderlineInputBorder(
                //   borderSide: const BorderSide(color: Colors.white),
                // ),
                hintText: "Search",
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        leading:(
            IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.pop(context);
              },
            )

        ),

        title: Text("Chats",style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),),
        toolbarHeight: 65,
        //centerTitle: true,

      ),
      body: Stack(
        children: <Widget>[

          SafeArea(
            child: SingleChildScrollView(
              child: Column(
                children: <Widget>[

                  buildSearchBar(context),

                  _buildChatTile(screenSize),

                ],
              ),
            ),
          )
        ],
      ),

    );
  }


}
