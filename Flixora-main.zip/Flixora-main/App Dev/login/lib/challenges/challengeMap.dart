import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'dart:typed_data';
import 'package:flutter_cache_manager/flutter_cache_manager.dart';
import "package:image/image.dart" as img;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:login/challenges/individualPost.dart';

void main()
{
  runApp(challengeMap());
}

class challengeMap extends StatefulWidget {
  @override
  challengeMap({Key key, this.challengename, this.challengeid}) : super(key: key);
  final String challengename;
  final String challengeid;


  challengeMapState createState() => challengeMapState();
}

class challengeMapState extends State<challengeMap> {

  @override
  void initState() {
    getPhotos();
    super.initState();
  }



  Map<MarkerId, Marker> markers = <MarkerId, Marker>{};

  final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
  final FirebaseAuth fbAuth = FirebaseAuth.instance;

  // Map<String, Uint8List> userIdMarkerMap = {};
  // Future getMarkerImage() async
  // {
  //
  //   for(int j=0;j<userIdList.length;j++) {
  //     final File markerImageFile = await DefaultCacheManager().getSingleFile(imageURL);
  //     final Uint8List markerImageBytes = await markerImageFile.readAsBytes();
  //
  //
  //     ui.Codec codec = await ui.instantiateImageCodec(markerImageBytes, targetWidth: 50);
  //     ui.FrameInfo fi = await codec.getNextFrame();
  //
  //     final Uint8List markerImage = (await fi.image.toByteData(format: ui.ImageByteFormat.png)).buffer.asUint8List();
  //
  //     userIdMarkerMap[userIdList[j]] = markerImage;
  //
  //   }
  //
  //   setState(() {
  //     //call your function to build google map
  //   });
  //
  // }
  ByteData imageinBytes;
  getMarkers(request, requestId) async{
    String url = request['image-link'];
    final File markerImageFile = await DefaultCacheManager().getSingleFile(url);
    final Uint8List markerImageinBytes = await markerImageFile.readAsBytes();

    Uint8List resizeImage(Uint8List bytesData) {
      Uint8List resizedImg = bytesData;
      img.Image imag = img.decodeImage(bytesData);
      img.Image resized = img.copyResize(imag, width: 75, height: 75);
      resizedImg = img.encodeJpg(resized);
      return resizedImg;
    }

    //  Future<BitmapDescriptor> _createMarkerImageFromAsset(BuildContext context, String path) {
    //   final Size size = Size(10, 10);
    //   final ImageConfiguration imageConfiguration =
    //   createLocalImageConfiguration(context, size: size);
    //   return BitmapDescriptor.fromAssetImage(imageConfiguration, path);
    // }
    //
    //  Future<Uint8List> getBytesFromAsset(String path, int width) async {
    //    ByteData data = await rootBundle.load(path);
    //    ui.Codec codec = await ui.instantiateImageCodec(data.buffer.asUint8List(), targetWidth: width);
    //    ui.FrameInfo fi = await codec.getNextFrame();
    //    return (await fi.image.toByteData(format: ui.ImageByteFormat.png)).buffer.asUint8List();
    //  }
    //
    //  Future<BitmapDescriptor> getBitmapDescriptorFromAssetBytes(String path, int width) async {
    //    final Uint8List imageData = await getBytesFromAsset(path, width);
    //    return BitmapDescriptor.fromBytes(imageData);
    //  }

    var p = request['geolocation'];
    String pid = request['postid'];
    String uid = request['userid'];
    String username;
    // String imageurl = request['image-link'];

    await fbFirestore.collection("users").doc(uid).get().then((u) => {
      username = u.get("username")
    });

    var markerIdVal = requestId;
    final MarkerId markerid = MarkerId(markerIdVal);
    final Marker marker = Marker(
        markerId: markerid,
        position: LatLng(p.latitude,p.longitude),
        icon:  BitmapDescriptor.fromBytes(resizeImage(markerImageinBytes)),
        onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (context) =>
              IndividualPost(
                challengeid: widget.challengeid, pid: pid,)),);
        },
        infoWindow: InfoWindow(
          title: username,
        ));
    setState(() {
      markers[markerid] = marker;

    });
  }

  getPhotos(){
    FirebaseFirestore.instance.collection("challengemarkers").doc(widget.challengeid).collection("posts").get().then((docs){
      if(docs.docs.isNotEmpty){
        for(int i = 0; i < docs.docs.length; ++i){
          getMarkers(docs.docs[i].data(), docs.docs[i].id);
        }
      }
    });
  }

  Completer<GoogleMapController> mapController = Completer();
  static final CameraPosition initLocation = CameraPosition(target: LatLng(0, 0),);

  @override
  Widget build(BuildContext context) {
    // if (imageinBytes == null) {
    //   return Center(child: CircularProgressIndicator());
    // }
    Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        leading:(
            IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.pop(context);
              },
            )

        ),

        title: Text("Map: "+widget.challengename,style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),),
        toolbarHeight: 65,
        //centerTitle: true,
        backgroundColor: Colors.black87,
        actions: <Widget>[],
      ),
      body: GoogleMap(
        myLocationEnabled: true,
        markers: Set<Marker>.of(markers.values),
        initialCameraPosition: initLocation,
        mapType: MapType.normal,
        onMapCreated: (GoogleMapController controller) {
          mapController.complete(controller);
        },
      ),

    );
  }


}