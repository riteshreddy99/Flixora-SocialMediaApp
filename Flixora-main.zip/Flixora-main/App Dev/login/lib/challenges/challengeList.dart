import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:intl/intl.dart';
import 'package:line_icons/line_icons.dart';
import 'package:login/challenges/viewChallenge.dart';

import 'createChallenge.dart';

class ChallengeList extends StatefulWidget {
  ChallengeList({Key key, this.userProfileId}) : super(key: key);

  final String userProfileId;

  ChallengeListState createState() => ChallengeListState();
}

class ChallengeListState extends State<ChallengeList> {
  @override
  void initState() {
    super.initState();
  }

  final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
  final FirebaseAuth fbAuth = FirebaseAuth.instance;

  int numOfchallenges = 0;

  List<String> challengeIDs = new List<String>();
  List<String> challengedesc = new List<String>();
  List<String> challengedeadline = new List<String>();
  List<String> challengelocation = new List<String>();
  List<String> challengecreator = new List<String>();

  DocumentReference userRef = FirebaseFirestore.instance
      .doc("users/" + FirebaseAuth.instance.currentUser.uid);
  String country;

  Future<List<String>> _getChallenges() async {
    numOfchallenges = 0;
    challengeIDs.clear();
    challengedesc.clear();
    challengelocation.clear();
    challengecreator.clear();
    CollectionReference challengeRef = fbFirestore.collection("challenges");
    List<String> challenges = new List<String>();
    // List<String> challengeIDs = new List<String>();

// print("getchallenges");
    // await challengeRef.get().then((snapshot) {
    //   numOfchallenges = snapshot.size;
    //   print(numOfchallenges);
    //
    //
    //   for (int i = 0; i < numOfchallenges; i++) {
    //     challenges.add(challengeRef.get());
    //   }
    // });

    await fbFirestore
        .collection("challenges")
        .get()
        .then((snapshot) => snapshot.docs.forEach((ch) {
              if (DateTime.now()
                  .isAfter(ch.get("timestampdeadline").toDate())) {
                String name = ch.get("name");
                fbFirestore
                    .collection("challenges")
                    .doc(ch.id)
                    .delete()
                    .then((value) => {print("challenge " + name + " deleted")});
              }
            }));

    await userRef.get().then((userData) {
      // get username
      country = userData.get("country");
      country = country?.toLowerCase();
    });

    await fbFirestore
        .collection("challenges")
        .get()
        .then((snapshot) => snapshot.docs.forEach((ch) {
              challenges.add(ch.get("name"));
              challengeIDs.add(ch.id);
              challengedesc.add(ch.get("description"));
              challengedeadline.add(ch.get("deadline"));
              challengecreator.add(ch.get("creator"));

              if(ch.get("location")=="")
                {
                  challengelocation.add("Global");
                }
              else
                {
                  challengelocation.add(ch.get("location"));
                }

              numOfchallenges++;
            }));
    // print(numOfchallenges);

    return challenges;
  }

  Widget _buildChallengeTile(screenSize) {
    // print("here");
    return Container(
      // height: screenSize.height,
      child: Row(
        children: <Widget>[
          FutureBuilder(
            future: _makeChallengeList(screenSize),
            builder: (context, AsyncSnapshot<List<Widget>> snapshot) {
              if (snapshot.connectionState == ConnectionState.done) {
                return Expanded(child: Column(children: snapshot.data));
              } else if (snapshot.connectionState == ConnectionState.none) {
                return Text("No data");
              }
              return Padding(
                padding: const EdgeInsets.only(bottom: 150),
                child: Container(
                    height: MediaQuery.of(context).size.height,
                    width: MediaQuery.of(context).size.width,
                    child: SpinKitFadingCube(
                      color: Colors.yellow[600],
                      size: 60,
                    )),
              );
            },
          ),

          // SizedBox(height: 6,),
          //  Text("Frontend developer",style: TextStyle(fontSize: 13,color: Colors.grey.shade600, ),),
        ],
      ),
    );
  }

  Widget _makeChallenge(challengeName, challengeid, challengedesc,

      challengedeadline, challengelocation, challengecreator, screenSize) {
    return Padding(
      padding: const EdgeInsets.only(top: 15),
      child: ListTile(
        title: Text(
          challengeName,
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
        ),
        subtitle: Text(challengelocation),
        trailing: RaisedButton(
          child: Text(
            "View",
            style: TextStyle(color: Colors.black),

          ),
          color: Colors.yellow[700],
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => ViewChallenge(
                      name: challengeName,
                      id: challengeid,
                      desc: challengedesc,
                      deadline: challengedeadline,
                      country: challengelocation,
                      creator: challengecreator)),
            );
          },
        ),
      ),
    );
    // return Container(
    //     width: screenSize.width,
    //     padding: EdgeInsets.all(10),
    //     // color: Colors.yellow,
    //
    //     child: InkWell(
    //       child: Column(
    //         crossAxisAlignment: CrossAxisAlignment.start,
    //         children: <Widget>[
    //           SizedBox(
    //             height: 25,
    //           ),
    //           Row(children: <Widget>[
    //             SizedBox(height: 20, width: 12),
    //             Text(
    //               challengeName,
    //               style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
    //             ),
    //             Expanded(child: SizedBox()),
    //             RaisedButton(
    //               child: Text(
    //                 "View",
    //                 style: TextStyle(color: Colors.black),
    //               ),
    //               color: Colors.yellow[400],
    //               onPressed: () {
    //                 Navigator.push(
    //                   context,
    //                   MaterialPageRoute(
    //                       builder: (context) => ViewChallenge(
    //                           name: challengeName,
    //                           id: challengeid,
    //                           desc: challengedesc,
    //                           deadline: challengedeadline,
    //                           country: challengelocation)),
    //                 );
    //               },
    //             ),
    //             Divider(
    //               color: Colors.grey,
    //             )
    //           ]),
    //         ],
    //       ),
    //       // onTap: () =>
    //       //     Navigator.push(
    //       //         context,
    //       //         MaterialPageRoute(
    //       //             builder: (context) => ChatScreen(
    //       //                 userProfileId: followerID,
    //       //                 userName: followerName
    //       //             )
    //       //         )
    //       //     ) // Navigator
    //     ));
  }

  Future<List<Widget>> _makeChallengeList(screenSize) async {
    List<String> challenges = await _getChallenges();

    List<Widget> widgetChallenges = [];

    for (int i = 0; i < numOfchallenges; i++) {

      widgetChallenges.add(_makeChallenge(
          challenges[i],
          challengeIDs[i],
          challengedesc[i],
          challengedeadline[i],
          challengelocation[i],
          challengecreator[i],
          screenSize));

    }

    return widgetChallenges;
  }

  // DocumentReference challenge = fbFirestore.doc("challenges/");

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        leading: (IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        )),

        title: Text(
          "Choose a challenge",
          //style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),
        ),
        // toolbarHeight: 65,
        //centerTitle: true,
        //backgroundColor: Colors.black87,
        actions: <Widget>[],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.yellow[700],
        child: Icon(LineIcons.pen),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => createChallenge()),
          );
        },
      ),
      body: Stack(
        children: <Widget>[
          SafeArea(
            child: SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  _buildChallengeTile(screenSize),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
