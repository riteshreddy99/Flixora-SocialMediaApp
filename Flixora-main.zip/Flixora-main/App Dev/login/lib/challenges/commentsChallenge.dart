import 'dart:ffi';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:like_button/like_button.dart';
import 'package:login/data/comment.dart';
import 'package:login/profile/main-profileOther.dart';
import 'package:login/data/post.dart';


class PostCommentSection extends StatefulWidget {
  PostCommentSection({Key key, this.post, this.challengeid}) : super(key: key);

  final Post post;
  final String challengeid;
  PostCommentSecState createState() => PostCommentSecState();
}


class PostCommentSecState extends State<PostCommentSection> {
  final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
  final FirebaseAuth fbAuth = FirebaseAuth.instance;

  final messageController = TextEditingController();


  Future<bool> _likeComment(Comment comment) async{

    print(comment.uid);
    CollectionReference commentsRef =
    fbFirestore.collection("challenges")
        .doc(widget.challengeid)
        .collection("posts")
        .doc(widget.post.postid)
        .collection("comments")
    ;

    DocumentReference user =
    fbFirestore.collection("users")
        .doc(fbAuth.currentUser.uid);

    String username;

    await user.get().then((snapshot) {
      username = snapshot.get("username");
    });


    DocumentReference posterRef =
    fbFirestore.collection("users")
        .doc(widget.post.userid)
        .collection("notifications").doc();

    Map<String, dynamic> notifData = {
      "message":"liked your comment: " + comment.text,
      "time-sent": DateTime.now(),
      "type": "comment-like",
      "userID": fbAuth.currentUser.uid,
      "username": username,
    };


    posterRef.set(notifData);

    await commentsRef.get().then((snapshot){

      for(int i = 0; i < snapshot.docs.length; i++){

        if(snapshot.docs[i].get("user-id") == comment.uid) {
          List<dynamic> likes = snapshot.docs[i].get("likes");
          String currentUID = fbAuth.currentUser.uid;

          DocumentReference commentRef = snapshot.docs[i].reference;

          if (comment.isLiked) {
            likes.remove(currentUID);
            commentRef.update({"likes": likes});

            comment.isLiked = false;
            return comment.isLiked;
          }

          likes.add(currentUID);
          commentRef.update({"likes": likes});
          comment.isLiked = true;
        }
      }

    });

    return comment.isLiked;
  }

  Future<DocumentSnapshot> _getProfileDetails(userid) {
    return fbFirestore.doc("users/" + userid).get();
  }

  Widget buildProfilePic(userid) {
    return FutureBuilder(
        future: _getProfileDetails(userid),
        builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return CircleAvatar(
              backgroundImage: NetworkImage(snapshot.data.get("photoUrl")),
            );
          } else if (snapshot.connectionState == ConnectionState.none) {
            print("No data");
          }
          return SpinKitPulse(
            size: 30,
            color: Colors.grey,
          );
        });
  }

  Widget _buildPostDesc() {
    return Container(
        margin:
        const EdgeInsets.only(left: 20.0, top: 20.0, bottom: 20, right: 10),

        child: Row(
          children: <Widget>[
            CircleAvatar(
              child: buildProfilePic(widget.post.userid),
            ),

            SizedBox(width: 15),
            Text(widget.post.user + " :",
                style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(width: 10),
            Text(widget.post.description),
          ],
        ));
  }

  Widget _buildComments() {
    return Container(
      margin:
      const EdgeInsets.only(left: 20.0, top: 20.0, bottom: 20, right: 10),
      child: StreamBuilder(
          stream: fbFirestore
              .collection("challenges")
              .doc(widget.challengeid)
              .collection("posts")
              .doc(widget.post.postid)
              .collection("comments")
              .orderBy("timePosted", descending: true)
              .snapshots(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) {
              return SpinKitRipple(
                color: Colors.grey[800],
                size: 60.0,
              );
            }

            List<Comment> comments = [];

            for (DocumentSnapshot doc in snapshot.data.docs) {
              var comment = new Comment();

              bool likedBefore = false;

              for (int i = 0; i < doc.get("likes").length; i++) {
                if (fbAuth.currentUser.uid == doc.get("likes")[i])
                  likedBefore = true;
              }

              comment.user = doc.get("username");
              comment.uid = doc.get("user-id");
              comment.likes = doc.get("likes").length;
              comment.text = doc.get("text");
              comment.time = DateTime.parse(doc.get("timePosted").toDate().toString());
              comment.isLiked = likedBefore;

              comments.add(comment);
            }

            if (!snapshot.hasData)
              return Padding(
                padding: EdgeInsets.fromLTRB(10, 10, 5, 0),
                child: LikeButton(
                  size: 26,
                  isLiked: widget.post.isLiked,
                ),
              );
            else {
              return Container(
                  child: ListView.builder(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      reverse: true,
                      itemCount: comments.length,
                      itemBuilder: (context, index) {
                        final comment = comments[index];
                        return Padding(

                            padding: EdgeInsets.only(top: 10, bottom: 10),
                            child: Column(
                              children: <Widget>[
                                ListTile(
                                  onTap: () {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                UserProfilePage(
                                                    userid: comment.uid)));
                                  },
                                  leading: buildProfilePic(comment.uid),
                                  title: Text(comment.user),
                                  subtitle: Text(comment.text),
                                  trailing: IconButton(
                                    icon: LikeButton(
                                      size: 18,
                                      animationDuration:
                                      Duration(milliseconds: 1000),
                                      likeCountAnimationDuration:
                                      Duration(milliseconds: 300),
                                      likeCount: comment.likes,
                                      isLiked: comment.isLiked,
                                      onTap: (x) => _likeComment(comment),
                                    ),
                                  ),
                                ),
                                // Row(children: <Widget>[
                                //   CircleAvatar(
                                //     child: buildProfilePic(comment.uid),
                                //   ),
                                //   SizedBox(width: 15),
                                //   Text(comment.user,
                                //       style: TextStyle(
                                //           fontWeight: FontWeight.bold)),
                                //   SizedBox(width: 10),
                                //   Container(
                                //     width: MediaQuery.of(context).size.width / 1.85,
                                //     child: Text(
                                //       comment.text,
                                //     ),
                                //   ),
                                //   Spacer(),
                                //   Padding(
                                //     padding: EdgeInsets.fromLTRB(10, 10, 5, 0),
                                //     child: LikeButton(
                                //       size: 18,
                                //       animationDuration:
                                //           Duration(milliseconds: 1000),
                                //       likeCountAnimationDuration:
                                //           Duration(milliseconds: 300),
                                //       likeCount: comment.likes,
                                //       isLiked: comment.isLiked,
                                //       onTap: (x) => _likeComment(comment),
                                //     ),
                                //   )
                                // ]),
                                // Divider(
                                //   color: Colors.grey[300],
                                //   indent: 50,
                                //   endIndent: 50,
                                //   height: 40,
                                // ),
                              ],
                            ));
                      }));
            }
          }),
    );
  }

  _sendComment(msg) async {
    String uid = fbAuth.currentUser.uid;
    String username, photoUrl;
    int points;

    DocumentReference userRef = fbFirestore.doc("users/" + uid);

    DocumentReference postUserRef = fbFirestore.doc("users/" + widget.post.userid);



    await postUserRef.get().then((snapshot) {
      points = snapshot.get("points");
    });

    await userRef.get().then((snapshot) {
      username = snapshot.get("username");
      photoUrl = snapshot.get("photoUrl");

      if(uid!=widget.post.userid)
        {
          // print("updating points");
          postUserRef.update({"points":points+3});
        }
    });


    DocumentReference posterRef =
    fbFirestore.collection("users")
        .doc(widget.post.userid)
        .collection("notifications").doc();

    Map<String, dynamic> notifData = {
      "message":"commented on your post: " + msg,
      "time-sent": DateTime.now(),
      "type": "comment",
      "userID": fbAuth.currentUser.uid,
      "username": username,
    };


    posterRef.set(notifData);

    var now = DateTime.now();

    Map<String, dynamic> commentData = {
      "user-id": uid,
      "text": msg,
      "timePosted": now,
      "likes": [],
      "username": username,
    };

    // print("challengeid = "+widget.challengeid+ "  post id = "+widget.post.postid);



    final CollectionReference commentRef = fbFirestore
        .collection("challenges")
        .doc(widget.challengeid)
        .collection("posts")
        .doc(widget.post.postid)
        .collection("comments");

    commentRef.add(commentData);
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          leading: (IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          )),
          title: Text("Comments"),
          toolbarHeight: 65,
          centerTitle: true,
          //backgroundColor: Colors.black87,
        ),
        body: Container(
            height: 1000,
            child: Column(children: [
              Expanded(
                  child: SizedBox(
                    child: ListView(children: [
                      _buildPostDesc(),
                      new Divider(color: Colors.black),
                      _buildComments(),
                      new Divider(color: Colors.black),
                    ]),
                  )),
              Align(
                alignment: Alignment.bottomLeft,
                child: Container(
                  padding: EdgeInsets.only(left: 10, bottom: 10, top: 10),
                  height: 70,
                  width: double.infinity,
                  color: Colors.grey[800],
                  child: Row(
                    children: <Widget>[
                      Divider(color: Colors.black),
                      // CircleAvatar(
                      //   backgroundImage: AssetImage('Image/profilepic.png'),
                      // ),
                      SizedBox(
                        width: 15,
                      ),
                      Expanded(
                        flex: 1,
                        child: TextField(
                          maxLines: null,
                          decoration: InputDecoration(
                              hintText: "Write message...",
                              hintStyle: TextStyle(color: Colors.white),
                              border: InputBorder.none),
                          controller: messageController,
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                      SizedBox(
                        width: 15,
                      ),
                      FloatingActionButton(
                        onPressed: () {
                          _sendComment(messageController.text);
                          messageController.clear();
                        },
                        child: Icon(
                          Icons.send,
                          color: Colors.yellow[600],
                          size: 20,
                        ),
                        backgroundColor: Colors.black,
                        elevation: 0,
                      ),
                    ],
                  ),
                ),
              ),
            ])));
  }
}