import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'package:login/challenges/viewChallenge.dart';
import 'package:login/helper/notifications.dart';
import 'package:uuid/uuid.dart';
import 'package:login/challenges/challengeList.dart';

class createChallenge extends StatefulWidget {
  createChallenge({Key key, this.userProfileId}) : super(key: key);

  final String userProfileId;

  createChallengeState createState() => createChallengeState();
}

class createChallengeState extends State<createChallenge> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final nameController = TextEditingController();
  final descController = TextEditingController();
  final locController = TextEditingController();
  final timeController = TextEditingController();

  DateTime chosenDate;
  TimeOfDay chosenTime;

  // chooseDate(BuildContext context) async {
  //   DateTime newDate = await showDatePicker(
  //       context: context,
  //       initialDate: chosenDate != null ? chosenDate : DateTime.now(),
  //       firstDate: DateTime(2000),
  //       lastDate: DateTime(2040)
  //     // builder: (BuildContext context, Widget child) {
  //     //   return Theme(
  //     //     data: ThemeData.dark().copyWith(
  //     //       colorScheme: ColorScheme.dark(
  //     //         primary: Colors.deepPurple,
  //     //         onPrimary: Colors.white,
  //     //         surface: Colors.blueGrey,
  //     //         onSurface: Colors.yellow,
  //     //       ),
  //     //       dialogBackgroundColor: Colors.blue[500],
  //     //     ),
  //     //     child: child,
  //     //   );
  //     // }
  //   );
  //
  //   if (newDate != null) {
  //     chosenDate = newDate;
  //     timeController
  //       ..text = DateFormat.yMMMd().format(chosenDate)
  //       ..selection = TextSelection.fromPosition(TextPosition(
  //           offset: timeController.text.length,
  //           affinity: TextAffinity.upstream));
  //   }

    // final TimeOfDay newTime = await showTimePicker(
    //   context: context,
    //   initialTime: chosenTime,
    // );
    // if (newTime != null)
    //   {
    //     chosenTime = newTime;
    //     timeController
    //       ..text = TimeOfDayFormat.H_colon_mm.toString()
    //       ..selection = TextSelection.fromPosition(TextPosition(
    //           offset: timeController.text.length,
    //           affinity: TextAffinity.upstream));
    //
    //     timeController.text = formatDate(
    //         DateTime(2019, 08, 1, chosenTime.hour, chosenTime.minute),
    //         [hh, ':', nn, " ", am]).toString();
    //   }
    //   setState(() {
    //     selectedTime = picked;
    //     _hour = selectedTime.hour.toString();
    //     _minute = selectedTime.minute.toString();
    //     _time = _hour + ' : ' + _minute;
    //     _timeController.text = _time;
    //     _timeController.text = formatDate(
    //         DateTime(2019, 08, 1, selectedTime.hour, selectedTime.minute),
    //         [hh, ':', nn, " ", am]).toString();
    //   });
  // }

  DateTime date;

  Future<void> _selectDate(BuildContext context) async {
    final now = DateTime.now().add(Duration(days: 1));
    final DateTime selected = await showDatePicker(
        context: context,
        initialDate: date ?? now,
        firstDate: now,
        lastDate: DateTime(2100));
    if (selected != null && selected != date) {
      // print('hello $picked');
      setState(() {
        date = selected;
      });
    }
  }

  // hidekeyboard() async {
  //   FocusScopeNode currentFocus = FocusScope.of(context);
  //
  //   // if (!currentFocus.hasPrimaryFocus) {
  //     await currentFocus.unfocus();
  //   // }
  // }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery
        .of(context)
        .size;

    return Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          leading: (
              IconButton(
                icon: Icon(
                  Icons.arrow_back,
                  color: Colors.white,
                ),
                onPressed: () async {

                  await FocusScope.of(context).unfocus();
                  await Future.delayed(Duration(milliseconds: 200));

                  Navigator.pop(context);
                  Navigator.pop(context);
                  await Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ChallengeList()),
                  );
                },
              )

          ),

          title: Text("Create Challenge",
           // style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),
          )

          ,
          toolbarHeight: 65,
          //centerTitle: true,
          // backgroundColor: Colors.black87,
          actions: <Widget>[
          ],
        ),
        body: Form(
            key: _formKey,
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  // Container(
                  //   child: Stack(
                  //     children: <Widget>[
                  //       Container(
                  //         padding: EdgeInsets.only(top: screenSize.height/12, left: screenSize.width/17),
                  //         child: Text(
                  //           'Please fill in the following',
                  //           style: TextStyle(
                  //               fontSize: 20.0, fontWeight: FontWeight.bold),
                  //         ),
                  //       ),
                  //       Container(
                  //         padding: EdgeInsets.fromLTRB(15.0, 135.0, 0.0, 0.0),
                  //         child: Text(
                  //           'some basic information',
                  //           style: TextStyle(
                  //               fontSize: 30.0,
                  //               fontWeight: FontWeight.bold,
                  //               color: Colors.black),
                  //         ),
                  //       )
                  //     ],
                  //   ),
                  // ),
                  Container(
                      padding: EdgeInsets.only(top: screenSize.height / 35,
                          left: screenSize.width / 35),
                      // color: Colors.grey,
                      child: Column(
                        children: <Widget>[
                          // SizedBox(height: 0.0),
                          Container(
                            padding: EdgeInsets.only(
                                left: screenSize.width / 25),
                            alignment: Alignment.centerLeft,
                            child: Text(
                              'Challenge Name',
                              style: TextStyle(
                                  fontSize: 20.0, fontWeight: FontWeight.bold, color: Colors.yellow[700]),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 10, right: 10),
                            child: Container(
                              child: Theme(
                                data: Theme.of(context)
                                    .copyWith(splashColor: Colors.transparent),
                                child: TextFormField(
                                  controller: nameController,
                                  autofocus: false,
                                  validator: (name) {
                                    Pattern pattern =
                                        r'^\s*$';
                                    RegExp regex = new RegExp(pattern);
                                    if (regex.hasMatch(name))
                                      return 'Please enter a name';
                                    else
                                      return null;
                                  },
                                  style: TextStyle(
                                      fontSize: 15.0,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black),
                                  decoration: InputDecoration(
                                    filled: true,
                                    fillColor: Colors.white,
                                    hintText: 'Ex: Cats',
                                    hintStyle: TextStyle(color: Colors.grey),
                                    contentPadding: EdgeInsets.only(
                                        left: screenSize.width / 17),

                                    focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(color: Colors.white),
                                      borderRadius: BorderRadius.circular(25.7),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(color: Colors.black),
                                      borderRadius: BorderRadius.circular(25.7),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),


                          SizedBox(height: 30.0),
                          Container(
                            padding: EdgeInsets.only(
                                left: screenSize.width / 25),
                            alignment: Alignment.centerLeft,
                            child: Text(
                              'Description',
                              style: TextStyle(
                                  fontSize: 20.0, fontWeight: FontWeight.bold, color: Colors.yellow[700]),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 10, right: 10),
                            child: Container(
                              child: Theme(
                                data: Theme.of(context)
                                    .copyWith(splashColor: Colors.transparent),
                                child: TextFormField(
                                  maxLines: null,
                                  controller: descController,
                                  validator: (desc) {
                                    Pattern pattern =
                                        r'^\s*$';
                                    RegExp regex = new RegExp(pattern);
                                    if (regex.hasMatch(desc))
                                      return 'Please enter a description';
                                    else
                                      return null;
                                  },
                                  autofocus: false,
                                  style: TextStyle(
                                      fontSize: 15.0,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black),
                                  decoration: InputDecoration(
                                    filled: true,
                                    fillColor: Colors.white,
                                    hintText: 'Enter text...',
                                    hintStyle: TextStyle(color: Colors.grey),
                                    contentPadding: EdgeInsets.only(
                                        left: screenSize.width / 17),
                                    focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(color: Colors.white),
                                      borderRadius: BorderRadius.circular(25.7),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(color: Colors.black),
                                      borderRadius: BorderRadius.circular(25.7),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),


                          SizedBox(height: 30.0),
                          Container(
                            padding: EdgeInsets.only(
                                left: screenSize.width / 25),
                            alignment: Alignment.centerLeft,
                            child: Text(
                              'Country (optional)',
                              style: TextStyle(
                                  fontSize: 20.0, fontWeight: FontWeight.bold, color: Colors.yellow[700]),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 10, right: 10),
                            child: Container(
                              child: Theme(
                                data: Theme.of(context)
                                    .copyWith(splashColor: Colors.transparent),
                                child: TextField(
                                  controller: locController,
                                  autofocus: false,
                                  // obscureText: true,
                                  style: TextStyle(
                                      fontSize: 15.0,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black),
                                  decoration: InputDecoration(
                                    filled: true,
                                    fillColor: Colors.white,
                                    hintText: 'Challenge will be global if left empty',
                                    hintStyle: TextStyle(color: Colors.grey),
                                    contentPadding: EdgeInsets.only(
                                        left: screenSize.width / 17),
                                    focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(color: Colors.white),
                                      borderRadius: BorderRadius.circular(25.7),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(color: Colors.black),
                                      borderRadius: BorderRadius.circular(25.7),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),


                          SizedBox(height: 30.0),
                          Container(
                            padding: EdgeInsets.only(
                                left: screenSize.width / 25),
                            alignment: Alignment.centerLeft,
                            child: Text(
                              'Deadline',
                              style: TextStyle(
                                fontSize: 20.0, fontWeight: FontWeight.bold, color: Colors.yellow[700]),
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.only(top: 10, right: 10),
                            child: Container(
                              child: Theme(
                                data: Theme.of(context)
                                    .copyWith(splashColor: Colors.transparent),
                                child: TextFormField(
                                  controller: timeController,
                                  validator: (desc) {
                                    Pattern pattern =
                                        r'^\s*$';
                                    RegExp regex = new RegExp(pattern);
                                    if (regex.hasMatch(desc))
                                      return 'Please select a date';
                                    else
                                      return null;
                                  },
                                  onTap: () async {
                                    // chooseDate(context);
                                    await _selectDate(context);
                                    timeController.text = DateFormat.yMMMd().format(date);
                                  },
                                  autofocus: false,
                                  style: TextStyle(
                                      fontSize: 15.0,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black),
                                  decoration: InputDecoration(
                                    filled: true,
                                    fillColor: Colors.white,
                                    hintText: 'Click to choose date',
                                    hintStyle: TextStyle(color: Colors.grey),
                                    contentPadding: EdgeInsets.only(
                                        left: screenSize.width / 17),
                                    focusedBorder: OutlineInputBorder(
                                      borderSide: BorderSide(color: Colors.white),
                                      borderRadius: BorderRadius.circular(25.7),
                                    ),
                                    enabledBorder: OutlineInputBorder(
                                      borderSide: BorderSide(color: Colors.black),
                                      borderRadius: BorderRadius.circular(25.7),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),


                          SizedBox(height: 30.0),
                          Padding(
                            padding: const EdgeInsets.only(right: 50, left: 50),
                            child: Container(
                              height: 40.0,
                              child: Material(
                                borderRadius: BorderRadius.circular(20.0),
                                shadowColor: Colors.black,
                                color: Colors.yellow[700],
                                elevation: 7.0,
                                child: InkWell(
                                  onTap: () async {
                                    await create();
                                    // Navigator.pop(context);
                                  },
                                  child: Center(
                                    child: Text(
                                      'CREATE',
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                          fontFamily: 'Montserrat'),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      )),
                ])));

    // );
  }


  Future create() async {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();
      try {
        // await FirebaseAuth.instance.createUserWithEmailAndPassword(
        //     email: emailController.text, password: passController.text);
        // Navigator.pushReplacement(
        //     context, MaterialPageRoute(builder: (context) => HPage()));


          Navigator.pop(context);
          Navigator.pop(context);
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => ChallengeList()),
          );

        final FirebaseAuth auth = FirebaseAuth.instance;

        final String challengeID = Uuid().v4();

        // final User user = auth.currentUser;
        // final uid = user.uid;
        final DocumentReference challengeRef = FirebaseFirestore.instance
            .collection('/challenges').doc(challengeID);

        Map<String, dynamic> userData = {
          "name": nameController.text,
          "description": descController.text,
          "location": locController.text,
          "deadline": timeController.text,
          "timestampdeadline":date,
          "creator": fbAuth.currentUser.uid,
        };
        challengeRef.set(userData);
      } catch (e) {
        print(e.message);
      }
    }
  }
}