import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:path_provider/path_provider.dart';
import 'package:image/image.dart' as Img;
import 'package:photofilters/filters/preset_filters.dart';
import 'package:photofilters/widgets/photo_filter.dart';
import 'package:uuid/uuid.dart';
// import 'package:login/homePage.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart' as gc;
import 'package:firebase_storage/firebase_storage.dart' as FBS;
import 'package:firebase_storage/firebase_storage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:firebase_ml_vision/firebase_ml_vision.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:path/path.dart' as p;

import 'challengeList.dart';

class UploadChallengePage extends StatefulWidget {
  @override
  UploadChallengePage({Key key, this.challengeId, this.challengename})
      : super(key: key);

  final String challengeId;
  final String challengename;

  _UploadChallengePageState createState() => _UploadChallengePageState();
}

class _UploadChallengePageState extends State<UploadChallengePage> {
  void initState() {
    _getCurrentLocation();
    super.initState();
  }

  TextEditingController locationController = TextEditingController();
  TextEditingController captionController = TextEditingController();

  File imgFile;
  final picker = ImagePicker();
  bool isUploading = false;
  String postID = Uuid().v4();
  // final Geolocator geolocator = Geolocator();
  String address;
  List<Face> _faces;

  _getImage(ImageSource src) async {
    final pickedFile = await picker.getImage(source: src);
    if (pickedFile != null) {
      File cropped = await ImageCropper.cropImage(
          sourcePath: pickedFile.path,
          aspectRatio: CropAspectRatio(ratioX: 1, ratioY: 1),
          compressFormat: ImageCompressFormat.jpg,
          androidUiSettings: AndroidUiSettings(
            toolbarTitle: "Crop Image",
          ));

      String tempPath = p.basename(cropped.path);
      var myImage = Img.decodeImage(cropped.readAsBytesSync());
      myImage = Img.copyResize(myImage, width: myImage.width);
      Map imagefile = await Navigator.push(
        context,
        new MaterialPageRoute(
          builder: (context) => new PhotoFilterSelector(
            appBarColor: Colors.grey[900],
            title: Text("Filter Photo"),
            image: myImage,
            filters: presetFiltersList,
            filename: tempPath,
            loader: Center(
                child: SpinKitFadingCube(
              color: Colors.yellow[600],
              size: 60,
            )),
            fit: BoxFit.contain,
          ),
        ),
      );
      if (imagefile != null && imagefile.containsKey('image_filtered')) {
        cropped = imagefile['image_filtered'];
      }

      final image = FirebaseVisionImage.fromFile(cropped);
      final faceDetector = FirebaseVision.instance.faceDetector(
        FaceDetectorOptions(
          mode: FaceDetectorMode.accurate,
          enableLandmarks: true,
        ),
      );
      List<Face> faces = await faceDetector.processImage(image);

      setState(() {
        imgFile = File(cropped.path);
        _faces = faces;
      });
    }
    int faces = _faces.length;

    print("The number of human faces present is : $faces");

    Navigator.pop(context);
  }

  // _openGallery(BuildContext context) async {
  //   final pickedFile = await picker.getImage(source: ImageSource.gallery);
  //
  //   setState(() {
  //     if (pickedFile != null) {
  //       imgFile = File(pickedFile.path);
  //     } else {
  //       print('No image selected.');
  //     }
  //   });
  //   Navigator.pop(context);
  // }
  //
  // _openCamera(BuildContext context) async {
  //   final pickedFile = await picker.getImage(source: ImageSource.camera);
  //
  //   setState(() {
  //     if (pickedFile != null) {
  //       imgFile = File(pickedFile.path);
  //     } else {
  //       print('No image selected.');
  //     }
  //   });
  //   Navigator.pop(context);
  // }

  Future<void> _showChoiceDialogue(BuildContext context) {
    return showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text("Choose Option"),
            content: SingleChildScrollView(
                child: ListBody(
              children: <Widget>[
                GestureDetector(
                  child: Text("Open Gallery"),
                  onTap: () {
                    _getImage(ImageSource.gallery);
                  },
                ),
                Padding(padding: EdgeInsets.all(8.0)),
                GestureDetector(
                  child: Text("Open Camera"),
                  onTap: () {
                    _getImage(ImageSource.camera);
                  },
                ),
              ],
            )),
          );
        });
  }

  final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
  final FirebaseAuth fbAuth = FirebaseAuth.instance;

  final storageRef = FirebaseStorage.instance.ref();
  final challengeRef = FirebaseFirestore.instance.collection("challenges");
  final challengemarkersRef =
      FirebaseFirestore.instance.collection("challengemarkers");

  Future<String> uploadImage(imageFile) async {
    FBS.UploadTask upTask =
        storageRef.child("post_$postID.jpg").putFile(imgFile);
    String imgURL = await (await upTask).ref.getDownloadURL();
    return imgURL;
  }

  makePostInFirestore({String mediaURL, String location, String caption}) async {
    // TODO
    String uid = FirebaseAuth.instance.currentUser.uid;
    // print("postid is "+postID);
    // print("challengeID is "+widget.challengeId);
    challengeRef.doc(widget.challengeId).collection("posts").doc(postID).set({
      "postId": postID,
      "user": uid,
      "image-desc": caption,
      "image-link": mediaURL,
      "likes": [],
      "numLikes": 0,
      "location": location,
      "timestamp": Timestamp.now(),
      "geolocation":
          GeoPoint(_currentPosition.latitude, _currentPosition.longitude),
    });

    challengemarkersRef.doc(widget.challengeId).set({
      "name": widget.challengename,
    });

    challengemarkersRef
        .doc(widget.challengeId)
        .collection("posts")
        .doc(postID)
        .set({
      "postid": postID,
      "image-link": mediaURL,
      "location": location,
      "geolocation":
          GeoPoint(_currentPosition.latitude, _currentPosition.longitude),
      "userid": uid,
      "challengeid": widget.challengeId,
    });

    captionController.clear();
    locationController.clear();

    setState(() {
      imgFile = null;
      isUploading = false;
      postID = Uuid().v4();
    });

    Navigator.pop(context);
    Navigator.pop(context);
    Navigator.pop(context);
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ChallengeList()),
    );
  }

  String usersLocation;

  submit() async {
    setState(() {
      isUploading = true;
    });
    // await imageCompress();
    String mediaURL = await uploadImage(imgFile);

    // print("getting location...");

    // await _getCurrentLocation();

    // print("got location = "+usersLocation);

    // loc = await _getCurrentLocation();
    // print("printing loc"+ loc);
    await makePostInFirestore(
      mediaURL: mediaURL,
      // location: locationController.text,
      location: usersLocation,
      caption: captionController.text,
    );
  }

  imageCompress() async {
    final temporaryDir = await getTemporaryDirectory();
    final path = temporaryDir.path;
    Img.Image imageFile = Img.decodeImage(imgFile.readAsBytesSync());
    final compImgFile = File('$path/img_$postID,jpg')
      ..writeAsBytes(Img.encodeJpg(imageFile, quality: 80));

    setState(() {
      imgFile = compImgFile;
    });
  }

  String curLoc;
  final Geolocator geolocator = Geolocator();
  Position _currentPosition;
  _getCurrentLocation() async {
    GeolocationStatus geolocationStatus =
        await Geolocator().checkGeolocationPermissionStatus();
    if (geolocationStatus == GeolocationStatus.denied) {
      print("Location permission denied");
    }
    Position position = await Geolocator()
        .getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    geolocator
        .getCurrentPosition(desiredAccuracy: LocationAccuracy.best)
        .then((Position position) {
      setState(() {
        _currentPosition = position;
        print(_currentPosition);
      });

      String location;
      location = _getAddressFromLatLng(); // This function is for Geocoding.
      return location;
    }).catchError((e) {
      print(e);
    });
  }

  String _currentAddress;
  _getAddressFromLatLng() async {
    try {
      List<gc.Placemark> p = await gc.placemarkFromCoordinates(
          _currentPosition.latitude, _currentPosition.longitude);
      gc.Placemark place = p[0];
      setState(() {
        curLoc = place.administrativeArea + ", " + place.country;
        usersLocation = curLoc;
        locationController.text = usersLocation;
        print("usersLoc = " + usersLocation);
      });
    } catch (e) {
      print(e);
    }
  }

  // getLocation() async {
  //   Position position = await Geolocator.getCurrentPosition(
  //       desiredAccuracy: LocationAccuracy.high);
  //   Position lastPos = await Geolocator.getLastKnownPosition();
  //
  //   setState(() {
  //     address = "$position.latitude";
  //   });
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: new AppBar(
          title: Text("Upload Post"),
          centerTitle: true,
          backgroundColor: Colors.black87,
          actions: [
            FlatButton(
                onPressed: isUploading ? null : () => submit(),
                child: Text(
                  "Post",
                  style: TextStyle(
                      color: Colors.blueAccent,
                      fontWeight: FontWeight.bold,
                      fontSize: 20),
                ))
          ],
        ),
        body: ListView(
          children: <Widget>[
            isUploading ? LinearProgressIndicator() : Text(""),
            Container(
              height: 250,
              width: MediaQuery.of(context).size.width * 0.8,
              child: Center(
                child: AspectRatio(
                    aspectRatio: 1 / 1,
                    child: InkWell(
                      onTap: () async {
                        await _showChoiceDialogue(context);
                      },
                      child: imgFile == null
                          ? Center(
                              child: Text(
                              "Tap to pick an image!",
                              style: TextStyle(fontSize: 20),
                            ))
                          : Container(
                              decoration: BoxDecoration(
                                  image: DecorationImage(
                                      fit: BoxFit.cover,
                                      image: FileImage(imgFile))),
                            ),
                    )),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 10.0),
            ),
            ListTile(
              leading: CircleAvatar(
                  backgroundImage:
                      // TODO Temporary image until we have Circle Avatars for each user
                      NetworkImage("https://i.imgur.com/57KE1W4.png")),
              title: Container(
                width: 250,
                child: TextField(
                  controller: captionController,
                  decoration: InputDecoration(
                      hintText: "Write your caption...",
                      border: InputBorder.none),
                ),
              ),
            ),
            Divider(),
            ListTile(
              leading: Icon(
                Icons.pin_drop,
                color: Colors.green,
                size: 35.0,
              ),
              title: Container(
                width: 250,
                child: TextField(
                  controller: locationController,
                  decoration: InputDecoration(
                      hintText: "App will use your current location",
                      border: InputBorder.none),
                ),
              ),
            ),
            // Container(
            //   width: 200.0,
            //   height: 100.0,
            //   alignment: Alignment.center,
            //   child: RaisedButton.icon(
            //     label: Text(
            //       "Use Current Location",
            //       style: TextStyle(color: Colors.white),
            //     ),
            //     shape: RoundedRectangleBorder(
            //       borderRadius: BorderRadius.circular(30.0),
            //     ),
            //     color: Colors.blue,
            //     // onPressed: () {
            //     //   _getCurrentLocation();
            //     // },
            //     onPressed: () =>  _getCurrentLocation(),
            //     icon: Icon(
            //       Icons.my_location,
            //       color: Colors.white,
            //     ),
            //   ),
            // )
          ],
        ));
  }
}
