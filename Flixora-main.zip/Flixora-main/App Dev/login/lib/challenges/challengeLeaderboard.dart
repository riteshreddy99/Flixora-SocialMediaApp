import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:line_icons/line_icons.dart';
import 'package:login/profile/main-profileOther.dart';
import 'package:login/challenges/individualPost.dart';

class ChallengeLeaderboard extends StatefulWidget {
  ChallengeLeaderboard({Key key, this.name, this.id, this.desc, this.deadline})
      : super(key: key);

  final String name;
  final String id;
  final String desc;
  final String deadline;

  ChallengeLeaderboardState createState() => ChallengeLeaderboardState();
}

class ChallengeLeaderboardState extends State<ChallengeLeaderboard> {
  void initState() {
    super.initState();
  }

  final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
  final FirebaseAuth fbAuth = FirebaseAuth.instance;

  int numOfposts = 0;
  int position = 3;

  List<String> userIDs = new List<String>();
  List<int> numLikes = new List<int>();
  List<String> postIDs = new List<String>();
  // List<String> challengedeadline = new List<String>();
  // List<String> challengelocation = new List<String>();

  // DocumentReference userRef = FirebaseFirestore.instance.doc("users/" + FirebaseAuth.instance.currentUser.uid);
  // String country;

  Future<List<String>> _getUsers() async {
    numOfposts = 0;
    position = 3;
    userIDs.clear();
    numLikes.clear();
    postIDs.clear();
    // challengelocation.clear();
    CollectionReference postsRef =
        fbFirestore.collection("challenges").doc(widget.id).collection("posts");
    // print("getusers orderedusers "+ widget.name);
    // Query orderedUsers = postsRef.orderBy("likes".length);

    Query orderedUsers;

    // int counter=0;

    await postsRef.get().then((snapshot) => snapshot.docs.forEach((p) {
          // counter++;
          // print("getusers");
          orderedUsers = postsRef.orderBy("numLikes", descending: true);
        }));

    // await postsRef.get().then((postData) {
    //   counter++;
    //   print("getusers");
    //   orderedUsers = postsRef.orderBy("image-desc", descending: true);
    // });

    // print("counter = "+counter.toString());

    await orderedUsers.get().then((snapshot) => snapshot.docs.forEach((p) {
          // Query orderedUsers = postsRef.orderBy("likes".length);
          userIDs.add(p.get("user"));
          numLikes.add(p.get("numLikes"));
          postIDs.add(p.id);
          numOfposts++;
        }));
    // List<String> challenges = new List<String>();
    // List<String> challengeIDs = new List<String>();

    // print("getusers");
    // await challengeRef.get().then((snapshot) {
    //   numOfchallenges = snapshot.size;
    print("numposts=");
    print(numOfposts);
    //
    //
    //   for (int i = 0; i < numOfchallenges; i++) {
    //     challenges.add(challengeRef.get());
    //   }
    // });
    //
    //
    // await userRef.get().then((userData) {
    //   // get username
    //   country = userData.get("country");
    //   country = country?.toLowerCase();
    // });
    //
    // await fbFirestore.collection("challenges").doc(widget.id).collection("posts").get().then((snapshot) => snapshot.docs.forEach((p) {
    //   challenges.add(ch.get("name"));
    //   challengeIDs.add(ch.id);
    //   challengedesc.add(ch.get("description"));
    //   challengedeadline.add(ch.get("deadline"));
    //   challengelocation.add(ch.get("location"));
    //   numOfchallenges++;
    // }));
    // print(numOfchallenges);

    return userIDs;
  }

  Widget _makeLeaderboardTiles(
      QueryDocumentSnapshot user, screenSize, int position) {
    return Container(
        width: screenSize.width,
        padding: EdgeInsets.all(10),
        child: ListTile(
          onTap: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => UserProfilePage(userid: user.id)));
          },
          leading: CircleAvatar(
            backgroundImage: NetworkImage(user.get("photoUrl")),
          ),
          title: Text(user.get("username")),
          subtitle: Row(
            children: [
              Text(
                position.toString(),
                style: TextStyle(fontSize: 20, color: Colors.yellow[600]),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Text(
                  "th",
                  style: TextStyle(fontSize: 14, color: Colors.yellow[600]),
                ),
              ),
            ],
          ),
          trailing: Padding(
            padding: const EdgeInsets.only(right: 20),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                    top: 8,
                  ),
                  child: Text("Score:"),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Text(
                    user.get("points").toString(),
                    style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.w900,
                        color: Colors.yellow[700]),
                  ),
                ),
              ],
            ),
          ),
        ));
  }

  Widget _buildLeaderboardTile(screenSize) {
    print("buildleaderboardtile");
    return Container(
      height: screenSize.height,
      child: Row(
        children: <Widget>[
          FutureBuilder(
            future: _makeLeaderboardList(screenSize),
            builder: (context, AsyncSnapshot<List<Widget>> snapshot) {
              if(!snapshot.hasData)
                {
                  return Container();
                }
              if (snapshot.connectionState == ConnectionState.done) {
                return Column(children: snapshot.data);
              } else if (snapshot.connectionState == ConnectionState.none) {
                return Text("No data");
              }
              return Container(
                //alignment: Alignment.center,
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 150),
                  child: Align(
                    alignment: Alignment.topCenter,
                    child: SpinKitFadingCube(
                      size: 60,
                      color: Colors.yellow,
                    ),
                  ),
                ),
              );
            },
          ),

          // SizedBox(height: 6,),
          //  Text("Frontend developer",style: TextStyle(fontSize: 13,color: Colors.grey.shade600, ),),
        ],
      ),
    );
  }

  // void incPosition()
  // {
  //   position++;
  // }

  Future<DocumentSnapshot> _getProfileDetails(userid) {
    return fbFirestore.doc("users/" + userid).get();
  }

  Widget buildProfilePic(userid) {
    return FutureBuilder(
        future: _getProfileDetails(userid),
        builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return Container(
              margin: EdgeInsets.all(5),
              width: 50.0,
              height: 50.0,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: NetworkImage(snapshot.data.get("photoUrl")),
                  fit: BoxFit.cover,
                ),
                borderRadius: BorderRadius.circular(80.0),
                border: Border.all(
                  color: Colors.grey[800],
                  width: 1.0,
                ),
              ),
            );
          } else if (snapshot.connectionState == ConnectionState.none) {
            print("No data");
          }
          return Text("");
        });
  }

  Future<DocumentSnapshot> _getPostDetails(postid) {
    print("postid = " + postid);
    return fbFirestore
        .doc("challenges/" + widget.id)
        .collection("posts")
        .doc(postid)
        .get();
  }

  Widget buildPostPic(postid) {
    return FutureBuilder(
        future: _getPostDetails(postid),
        builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return Container(
              margin: EdgeInsets.all(5),
              width: 50.0,
              height: 50.0,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: NetworkImage(snapshot.data.get("image-link")),
                  fit: BoxFit.cover,
                ),
                borderRadius: BorderRadius.circular(0.0),
                border: Border.all(
                  color: Colors.grey[800],
                  width: 1.0,
                ),
              ),
            );
          } else if (snapshot.connectionState == ConnectionState.none) {
            print("No data");
          }
          return Text("");
        });
  }

  Widget _makeLeaderboard1(userid, noLikes, postid, screenSize, Color crownColor) {
    print("makeleaderboard");
    String username;

    Future<DocumentSnapshot> getUsername() async {
      // String uid = fbAuth.currentUser.uid;
      DocumentReference userRef = fbFirestore.collection("users").doc(userid);

      await userRef.get().then((snapshot) {
        // print("in here");
        username = snapshot.get("username");
        // print("username:"+username);

        return snapshot;
      });
    }

    return Container(
      width: screenSize.width,
      padding: EdgeInsets.all(10),
      // color: Colors.yellow,

      child: FutureBuilder(
          future: getUsername(),
          builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
            if (snapshot.connectionState == ConnectionState.done) {
              // position++;

              return InkWell(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    // SizedBox(
                    //   height: 15,
                    // ),
                    Row(children: <Widget>[
                      // SizedBox(height: 20,width:12),
                      // incPosition(),
                      IconButton(
                        icon: Icon(
                          LineIcons.crown,
                          color: crownColor,
                        ),
                      ),
                      // Expanded(child:SizedBox()),
                      buildProfilePic(userid),
                      SizedBox(height: 20, width: 12),
                      // Expanded(child:SizedBox()),
                      GestureDetector(
                        child: Text(
                          username,
                          style: TextStyle(
                              fontSize: 18, fontWeight: FontWeight.w900),
                        ),
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      UserProfilePage(userid: userid)));
                        },
                      ),
                      // Text(username,
                      //   style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),),
                      Expanded(child: SizedBox()),
                      Text(
                        "",
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.w900),
                      ),
                      // Expanded(child:SizedBox()),
                      // RaisedButton(
                      //   child: Text("View",style: TextStyle(color: Colors.white),),
                      //   color: Colors.black,
                      //   onPressed: () {
                      //     // Navigator.push(context, MaterialPageRoute(builder: (context) => ViewChallenge(name: challengeName,id: challengeid, desc: challengedesc, deadline: challengedeadline,)),);
                      //   },
                      //
                      //
                      // ),
                      // RaisedButton(
                      //   child: Text(
                      //     "Score: " + noLikes.toString(),
                      //     style: TextStyle(
                      //         fontSize: 18,
                      //         fontWeight: FontWeight.w900,
                      //         color: Colors.black),
                      //   ),
                      //   color: Colors.white,
                      //   onPressed: () {},
                      //   shape: RoundedRectangleBorder(
                      //       borderRadius: BorderRadius.circular(15.0),
                      //       side: BorderSide(color: Colors.white)),
                      // ),
                      Padding(
                        padding: const EdgeInsets.only(right: 20),
                        child: Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(
                                top: 8,
                              ),
                              child: Text("Score:"),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 2),
                              child: Text(
                                noLikes.toString(),
                                style: TextStyle(
                                    fontSize: 19,
                                    fontWeight: FontWeight.w900,
                                    color: Colors.yellow[700]),
                              ),
                            ),
                          ],
                        ),
                      ),
                      GestureDetector(
                        child: buildPostPic(postid),
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (contetx) => IndividualPost(
                                        pid: postid,
                                        challengeid: widget.id,
                                      )));
                        },
                      ),
                      // buildPostPic(postid),
                      // Text(noLikes.toString(),
                      //   style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),),
                      // Divider(
                      //   color: Colors.grey,
                      // )
                    ]),
                  ],
                ),
              );
            } else if (snapshot.connectionState == ConnectionState.none) {
              print("No data");
            }

            return Text("");
          }),
    );
  }


  Widget _makeLeaderboard(userid, noLikes, postid, screenSize) {
    print("makeleaderboard");
    String username;

    Future<DocumentSnapshot> getUsername() async {
      // String uid = fbAuth.currentUser.uid;
      DocumentReference userRef = fbFirestore.collection("users").doc(userid);

      await userRef.get().then((snapshot) {
        // print("in here");
        username = snapshot.get("username");
        // print("username:"+username);

        return snapshot;
      });
    }

    return Container(
      width: screenSize.width,
      padding: EdgeInsets.all(10),
      // color: Colors.yellow,

      child: FutureBuilder(
          future: getUsername(),
          builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
            if (snapshot.connectionState == ConnectionState.done) {
              position++;

              return InkWell(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    // SizedBox(height: 20, width: 12,),
                    Row(children: <Widget>[
                      SizedBox(height: 20, width: 20),
                      // incPosition(),
                      Text(
                        position.toString(),
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.w900),
                      ),
                      SizedBox(height: 20, width: 20),
                      buildProfilePic(userid),
                      SizedBox(height: 20, width: 12),

                      GestureDetector(
                        child: Text(
                          username,
                          style: TextStyle(
                              fontSize: 18, fontWeight: FontWeight.w900),
                        ),
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      UserProfilePage(userid: userid)));
                        },
                      ),
                      Expanded(child: SizedBox()),
                      Text(
                        "",
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.w900),
                      ),
                      // Expanded(child:SizedBox()),
                      // RaisedButton(
                      //   child: Text("View",style: TextStyle(color: Colors.white),),
                      //   color: Colors.black,
                      //   onPressed: () {
                      //     // Navigator.push(context, MaterialPageRoute(builder: (context) => ViewChallenge(name: challengeName,id: challengeid, desc: challengedesc, deadline: challengedeadline,)),);
                      //   },
                      //
                      //
                      // ),
                      Padding(
                        padding: const EdgeInsets.only(right: 20),
                        child: Column(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(
                                top: 8,
                              ),
                              child: Text("Score:"),
                            ),
                            Padding(
                              padding: const EdgeInsets.only(top: 2),
                              child: Text(
                                noLikes.toString(),
                                style: TextStyle(
                                    fontSize: 19,
                                    fontWeight: FontWeight.w900,
                                    color: Colors.yellow[700]),
                              ),
                            ),
                          ],
                        ),
                      ),
                      GestureDetector(
                        child: buildPostPic(postid),
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (contetx) => IndividualPost(
                                        pid: postid,
                                        challengeid: widget.id,
                                      )));
                        },
                      ),
                      // buildPostPic(postid),
                      Divider(
                        color: Colors.grey,
                      )
                    ]),
                  ],
                ),
              );
            } else if (snapshot.connectionState == ConnectionState.none) {
              print("No data");
            }

            return Text("");
          }),
    );
  }

  Future<List<Widget>> _makeLeaderboardList(screenSize) async {
    print("makeleaderboardlist");
    List<String> users = await _getUsers();

    List<Widget> widgetleaderboard = [];
    print(numOfposts);

    if (numOfposts >= 1) {
      widgetleaderboard.add(
          _makeLeaderboard1(userIDs[0], numLikes[0], postIDs[0], screenSize, Colors.amberAccent));
    }
    if (numOfposts >= 2) {
      widgetleaderboard.add(
          _makeLeaderboard1(userIDs[1], numLikes[1], postIDs[1], screenSize, Colors.grey[400]));
    }
    if (numOfposts >= 3) {
      widgetleaderboard.add(
          _makeLeaderboard1(userIDs[2], numLikes[2], postIDs[2], screenSize, Colors.orange[300]));
    }
    // widgetleaderboard.add(_makeLeaderboard(userIDs[i], numLikes[i], screenSize));

    for (int i = 3; i < numOfposts; i++) {
      widgetleaderboard.add(
          _makeLeaderboard(userIDs[i], numLikes[i], postIDs[i], screenSize));
    }

    return widgetleaderboard;
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        leading: (IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        )),

        title: Text(
          widget.name + " Leaderboard",
          //style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),
        ),
        toolbarHeight: 65,
        //centerTitle: true,
        //backgroundColor: Colors.black87,
        actions: <Widget>[],
      ),
      body: Stack(
        children: <Widget>[
          SafeArea(
            child: SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  _buildLeaderboardTile(screenSize),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}