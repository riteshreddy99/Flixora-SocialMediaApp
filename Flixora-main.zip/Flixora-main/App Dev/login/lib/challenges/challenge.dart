import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:login/challenges/challengeList.dart';
import 'package:login/challenges/createChallenge.dart';


void main() => runApp(ChallengePage());

class ChallengePage extends StatefulWidget {
  ChallengePage({Key key, this.challengeid}) : super(key: key);

  final String challengeid;
  //Post post;

  @override
  _ChallengePage createState() => _ChallengePage();
}

class _ChallengePage extends State<ChallengePage> {
  @override



  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        leading:(
            IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.pop(context);
              },
            )

        ),

        title: Text("Challenges",style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),),
        toolbarHeight: 65,
        //centerTitle: true,
        backgroundColor: Colors.black87,
        actions: <Widget>[
        ],
      ),
      body: Stack(
        children: <Widget>[

          SafeArea(
            child: SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.only(top: 15),

                    child: Text("Select one of the options",
                        style: TextStyle(color: Colors.grey, fontSize: 15),
                      ),
                    ),
                  Padding(
                    padding: EdgeInsets.only(top: screenSize.height/7, left: screenSize.width/17),
                    child: RaisedButton.icon(
                      padding: EdgeInsets.all(25),
                      shape: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),
                          borderSide: BorderSide(
                              color: Colors.grey.shade100
                          )
                      ),
                      icon: Icon(Icons.create,color: Colors.white, size: 30,),
                      label: Text("Create a challenge",
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                            fontSize: 22
                        ),
                      ),
                      onPressed: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context) => createChallenge()),);
                      },
                      color: Colors.black87,
                    )
                  ),
                  Padding(
                      padding: EdgeInsets.only(top: screenSize.height/8, left: screenSize.width/15),
                      child: RaisedButton.icon(
                        padding: EdgeInsets.all(25),
                        shape: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                            borderSide: BorderSide(
                                color: Colors.grey.shade100
                            )
                        ),
                        icon: Icon(Icons.upload_sharp,color: Colors.white, size: 30,),
                        label: Text("Participate in a challenge",
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                              fontSize: 22
                          ),
                        ),
                        onPressed: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context) => ChallengeList()),);
                        },
                        color: Colors.black87,
                      )
                  ),

                ],
              ),
            ),
          )
        ],
      ),

    );
  }

}