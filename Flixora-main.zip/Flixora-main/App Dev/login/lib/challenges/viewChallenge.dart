import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:line_icons/line_icons.dart';
import 'package:login/challenges/challengeDescription.dart';
import 'package:login/challenges/challengeLeaderboard.dart';
import 'package:login/challenges/challengeList.dart';
import 'package:login/challenges/uploadToChallenge.dart';
import 'package:login/data/post.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:like_button/like_button.dart';
import 'package:login/profile/main-profileOther.dart';
import 'package:login/challenges/commentsChallenge.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart' as gc;
import 'package:login/challenges/challengeMap.dart';

class ViewChallenge extends StatefulWidget {
  ViewChallenge({Key key, this.name, this.id, this.desc, this.deadline, this.country, this.creator})
      : super(key: key);

  final String name;
  final String id;
  final String desc;
  final String deadline;
  final String country;
  final String creator;

  ViewChallengeState createState() => ViewChallengeState();
}

class ViewChallengeState extends State<ViewChallenge> {
  void initState() {
    super.initState();
  }

  final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
  final FirebaseAuth fbAuth = FirebaseAuth.instance;
  String usersLocation;
  List<String> postlocations = new List<String>();
  String username = "";
  int numOfposts = 0;
  String creator = "";

  Future<List<Post>> getChallengePosts() async {
    List<Post> challengePosts = new List<Post>();
    postlocations.clear();
    numOfposts = 0;


    DocumentReference creatorRef = fbFirestore.collection("users").doc(widget.creator);

    await creatorRef.get().then((snapshot) {
      // print("in here");
      creator = snapshot.get("username");
    });


    CollectionReference postRef =
        fbFirestore.collection("challenges/" + widget.id + "/posts");

    await postRef.get().then((snapshot) => snapshot.docs.forEach((p) {
          bool likedBefore = false;

          for (int k = 0; k < p.get("likes").length; k++) {
            if (fbAuth.currentUser.uid == p.get("likes")[k]) likedBefore = true;
          }

          numOfposts++;

          challengePosts.add(new Post(
              username,
              p.get("user"),
              p.get("postId"),
              p.get("image-desc"),
              p.get("image-link"),
              p.get("likes").length,
              likedBefore,
              false));
          
          postlocations.add(p.get("location"));
        }));

    for (int i = 0; i < numOfposts; i++) {
      DocumentReference userRef =
          fbFirestore.doc("users/" + challengePosts[i].userid);
      await userRef.get().then((snapshot) {
        // print("in here");
        username = snapshot.get("username");
      });
      challengePosts[i].user = username;

    }
    return challengePosts;
  }

  Future<List<Widget>> getPosts() async {
    // Stores our posts in an array
    List<Widget> widgetPosts = [];
    List<Post> allPosts =
        await getChallengePosts(); // get all the posts of users being followed by current user

    // for (Post p in allPosts) {
    //   widgetPosts.add(getPost(p)); // formatting magic
    // }
    for (int i=0; i<numOfposts;i++)
    {
      widgetPosts.add(getPost(allPosts[i], postlocations[i]));
    }

    return widgetPosts;
  }

  Widget feedBody() {
    // generate the feed of a user
    return Container(
      // color: Theme.of(context).accentColor,
      child: FutureBuilder(
          future: getPosts(),
          builder: (context, AsyncSnapshot<List<Widget>> snapshot) {
            if (snapshot.connectionState == ConnectionState.done) {
              return ListView(
                children: <Widget>[
                  Column(children: snapshot.data),
                ],
              );
            } else if (snapshot.connectionState == ConnectionState.none) {
              return Text("No data");
            }
            return SpinKitFadingCube(
              color: Colors.yellow[600],
              size: 60.0,
            );
          }),
    );
  }

  Future<bool> _likePost(Post post) async {
    DocumentReference postRef = fbFirestore
        .collection("challenges")
        .doc(widget.id)
        .collection("posts")
        .doc(post.postid);

    // DocumentReference userRef = FirebaseFirestore.instance.doc("challenges/" + widget.id + posts + post);

    String userid = post.userid;
    DocumentReference userRef =
        FirebaseFirestore.instance.doc("users/" + userid);
    // print(userid);
    // print(widget.id);
    // print(post.postid);
    int points;
    int numLikes;
    await userRef.get().then((snapshot) {
      points = snapshot.get("points");
    });

    await postRef.get().then((snapshot) {
      List<dynamic> likes = snapshot.get("likes");
      String currentUID = fbAuth.currentUser.uid;

      numLikes = snapshot.get("numLikes");

      if (post.isLiked) {
        likes.remove(currentUID);
        postRef.update({"likes": likes});
        postRef.update({"numLikes": numLikes - 1});

        post.isLiked = false;

        userRef.update({"points": points - 1});

        return post.isLiked;
      }

      likes.add(currentUID);
      postRef.update({"likes": likes});
      postRef.update({"numLikes": numLikes + 1});
      post.isLiked = true;

      userRef.update({"points": points + 1});
    });

    return post.isLiked;
  }

  Future<DocumentSnapshot> _getProfileDetails(userid) {
    return fbFirestore.doc("users/" + userid).get();
  }

  Widget buildProfilePic(userid) {
    return FutureBuilder(
        future: _getProfileDetails(userid),
        builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return Container(
              margin: EdgeInsets.all(5),
              width: 40.0,
              height: 40.0,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: NetworkImage(snapshot.data.get("photoUrl")),
                  fit: BoxFit.cover,
                ),
                borderRadius: BorderRadius.circular(80.0),
                border: Border.all(
                  color: Colors.grey[800],
                  width: 1.0,
                ),
              ),
            );
          } else if (snapshot.connectionState == ConnectionState.none) {
            print("No data");
          }
          return SpinKitPulse(
            size: 30,
            color: Colors.grey,
          );
        });
  }

  Widget getPost(Post post,String location) {
    // Function to create the post widgets

    return Padding(
      padding: const EdgeInsets.only(top: 25, left: 20, right: 20),
      child: Card(
        elevation: 20,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0),
        ),
        child: Column(
          children: [
            GestureDetector(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) =>
                            UserProfilePage(userid: post.userid)));
              },
              child: ListTile(
                leading: buildProfilePic(post.userid),
                title: Text(post.user),
                subtitle: Text(location),
                trailing: Icon(Icons.more_vert),
              ),
            ),
            Container(
              child: Image.network(post.pictureLink),
            ),
            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  StreamBuilder(
                      stream: fbFirestore
                          .collection("challenges")
                          .doc(widget.id)
                          .collection("posts")
                          .doc(post.postid)
                          .snapshots(),
                      builder: (context, snapshot) {
                        if (!snapshot.hasData)
                          return Padding(
                            padding: EdgeInsets.fromLTRB(10, 10, 5, 0),
                            child: LikeButton(
                              size: 26,
                              isLiked: post.isLiked,
                            ),
                          );
                        else {
                          return Padding(
                            padding: EdgeInsets.fromLTRB(10, 10, 5, 0),
                            child: LikeButton(
                              size: 26,
                              animationDuration: Duration(milliseconds: 1000),
                              likeCountAnimationDuration:
                                  Duration(milliseconds: 300),
                              likeCount: snapshot.data["likes"].length,
                              isLiked: post.isLiked,
                              onTap: (x) => _likePost(post),
                            ),
                          );
                        }
                      }),
                  Padding(
                    padding: EdgeInsets.fromLTRB(10, 10, 5, 0),
                    child: LikeButton(
                      bubblesColor: BubblesColor(
                        dotPrimaryColor: Colors.purple,
                        dotSecondaryColor: Colors.green,
                      ),
                      likeBuilder: (bool isCommented) {
                        return Icon(Icons.messenger_outline_rounded);
                      },
                      onTap: (x) {
                        return Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => PostCommentSection(
                                      post: post,
                                      challengeid: widget.id,
                                    )));
                      },
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.fromLTRB(10, 10, 5, 0),
                    child: LikeButton(
                      size: 26,
                      bubblesColor: BubblesColor(
                        dotPrimaryColor: Colors.blue,
                        dotSecondaryColor: Colors.green,
                      ),
                      likeBuilder: (bool isShared) {
                        return Icon(Icons.share_outlined);
                      },
                    ),
                  ),
                ],
              ),
            ),
            Column(
              children: [
                SizedBox(
                  height: 5,
                ),
                Padding(
                  padding: EdgeInsets.all(10),
                  child: Container(child: Text(post.description)),
                ),
                SizedBox(
                  height: 10,
                )
              ],
            ),
          ],
        ),
      ),
    );
  }

  // CollectionReference challengeRef = fbFirestore.collection("challenges");

  showAlertDialog(BuildContext context, String msg) {
    // set up the button
    Widget okButton = FlatButton(
      child: Text("OK"),
      onPressed: () {
        Navigator.pop(context);
      },
    );
    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("Invalid Country"),
      content: Text(msg),
      actions: [
        okButton,
      ],
    );
    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }



  @override
  Widget build(BuildContext context) {
    final Geolocator geolocator = Geolocator();
    Position _currentPosition;

    Future<String> _getAddressFromLatLng() async {
      try {
        List<gc.Placemark> p = await gc.placemarkFromCoordinates(
            _currentPosition.latitude, _currentPosition.longitude);
        gc.Placemark place = p[0];
        setState(() {
          usersLocation = place.country;
          print("usersLoc = " + usersLocation);
        });
      } catch (e) {
        print(e);
      }

      return usersLocation;
    }

    Future<String> _getCurrentLocation() async {
      GeolocationStatus geolocationStatus =
          await Geolocator().checkGeolocationPermissionStatus();
      String finalLocation = "";
      if (geolocationStatus == GeolocationStatus.denied) {
        print("Location permission denied");
      }
      geolocator
          .getCurrentPosition(desiredAccuracy: LocationAccuracy.best)
          .then((Position position) async {
        setState(() {
          _currentPosition = position;
          print(_currentPosition);
        });
        finalLocation = await _getAddressFromLatLng(); // This function is for Geocoding.
      }).catchError((e) {
        print(e);
      });
      finalLocation = usersLocation;
      return finalLocation;
    }

    return Scaffold(
      appBar: AppBar(
        leading: (IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
          onPressed: () async {

            Navigator.pop(context);
            Navigator.pop(context);
            await Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => ChallengeList()),
            );
          },
        )),

        title: Text(
          widget.name,
          //style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
        ),
        toolbarHeight: 65,
        //centerTitle: true,
        //backgroundColor: Colors.black87,
        actions: <Widget>[
          Container(
            padding: EdgeInsets.only(top: 3, right: 15),
            alignment: Alignment.center,
            child: new Row(children: <Widget>[
               IconButton(
                iconSize: 25,
                icon: Icon(
                  Icons.map_outlined,
                  color: Colors.white,
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => challengeMap(challengename: widget.name, challengeid: widget.id)),
                  );
                },
              ),

              IconButton(
                icon: Icon(
                  Icons.leaderboard_sharp,
                  color: Colors.white,
                  size: 25,
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ChallengeLeaderboard(
                              name: widget.name,
                              id: widget.id,
                              desc: widget.desc,
                              deadline: widget.deadline,
                            )),
                  );
                },
              ),
              IconButton(
                icon: Icon(
                  Icons.info_outline,
                  color: Colors.white,
                  size: 25,
                ),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ChallengeDescription(
                              name: widget.name,
                              desc: widget.desc,
                              deadline: widget.deadline,
                              country : widget.country,
                              creatorid: widget.creator,
                              creator: creator,
                            )),
                  );
                },
              ),
            ]),

            // child: RaisedButton(
            //     child: Text("View Details", style: TextStyle(color: Colors.white),),
            //   color: Colors.black,
            //   onPressed: () {
            //     Navigator.push(context, MaterialPageRoute(builder: (context) => ChallengeDescription(name: widget.name,desc: widget.desc, deadline: widget.deadline,)),);
            //   },
            //     shape: RoundedRectangleBorder(
            //             borderRadius: BorderRadius.circular(45.0),
            //             side: BorderSide(color: Colors.white)
            //         ),
            // )
          ),
        ],
      ),
      body: feedBody(),
      floatingActionButton: FloatingActionButton(
        child: Icon(LineIcons.plus),
        onPressed: () async{
          var currentUserLocation = await _getCurrentLocation();
          currentUserLocation = usersLocation;
          print(currentUserLocation);
          // while(currentUserLocation == null) {
          //   currentUserLocation = await _getCurrentLocation();
          // }
          if(currentUserLocation == widget.country || widget.country == "Global") {
            var route = new MaterialPageRoute(
                builder: (BuildContext context) => new UploadChallengePage(
                  challengeId: widget.id,
                  challengename: widget.name,
                ));
            Navigator.of(context).push(route);
          } else {
            showAlertDialog(context, "You cannot participate in this challenge.");
          }

        },
      ),
    );
  }
}
