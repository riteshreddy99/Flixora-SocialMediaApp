import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:login/data/post.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:like_button/like_button.dart';
import 'package:login/profile/main-profileOther.dart';
import 'package:login/widgets/commentsPage.dart';
import 'package:login/challenges/challengeList.dart';

class IndividualPost extends StatefulWidget {
  IndividualPost({Key key,this.pid, this.challengeid}) : super(key: key);

  final String pid;
  final String challengeid;
  IndividualPostState createState() => IndividualPostState();
}

class IndividualPostState extends State<IndividualPost> {

  void initState() {
    super.initState();
  }

  final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
  final FirebaseAuth fbAuth = FirebaseAuth.instance;


  String username = "";

  String postlocation;
  Future<Post> getChallengePost() async {
    Post challengePost;
    postlocation = "";

    DocumentReference postRef = fbFirestore.collection("challenges/"+widget.challengeid+"/posts").doc(widget.pid);


    int numOfposts=0;
    bool likedBefore = false;

    await postRef.get().then((p) {

      for(int k = 0; k <  p.get("likes").length; k++){
        if (fbAuth.currentUser.uid ==  p.get("likes")[k])
          likedBefore = true;
      }

      // print(p.get("user"));

      postlocation = p.get("location");

      challengePost = new Post(
          username,
          p.get("user"),
          p.get("postId"),
          p.get("image-desc"),
          p.get("image-link"),
          p.get("likes").length,
          likedBefore,
          false);


    });

    DocumentReference userRef = fbFirestore.doc("users/" + challengePost.userid);
    await userRef.get().then((snapshot) {
      // print("in here");
      username = snapshot.get("username");
      challengePost.user = username;
    });


    return challengePost;
  }

  Future<List<Widget>> getPosts() async {

    print("getPosts");
    // Stores our posts in an array
    List<Widget> widgetPost = [];
    Post post =
    await getChallengePost(); // get all the posts of users being followed by current user

    widgetPost.add(getPost(post, postlocation));

    return widgetPost;

  }

  Widget feedBody() {

    print("feedBody");
    // generate the feed of a user
    return Container(
      // color: Theme.of(context).accentColor,
      child: FutureBuilder(
          future: getPosts(),
          builder: (context, AsyncSnapshot<List<Widget>> snapshot) {
            if (snapshot.connectionState == ConnectionState.done) {
              return ListView(
                children: <Widget>[
                  Column(children: snapshot.data),
                ],
              );
            } else if (snapshot.connectionState == ConnectionState.none) {
              return Text("No data");
            }
            return SpinKitRipple(
              color: Colors.grey[800],
              size: 60.0,
            );
          }),
    );
  }


  Future<bool> _likePost(Post post) async{
    DocumentReference postRef =
    fbFirestore.collection("challenges")
        .doc(widget.challengeid)
        .collection("posts")
        .doc(post.postid);


    String userid = post.userid;
    DocumentReference userRef = FirebaseFirestore.instance.doc("users/" + userid);
    int points;
    int numLikes;
    await userRef.get().then((snapshot){
      points = snapshot.get("points");
    });



    await postRef.get().then((snapshot){

      List<dynamic> likes = snapshot.get("likes");
      String currentUID = fbAuth.currentUser.uid;

      numLikes = snapshot.get("numLikes");

      if(post.isLiked) {
        likes.remove(currentUID);
        postRef.update({"likes":likes});
        postRef.update({"numLikes":numLikes-1});

        post.isLiked = false;


        userRef.update({"points":points-1});


        return post.isLiked;


      }

      likes.add(currentUID);
      postRef.update({"likes":likes});
      postRef.update({"numLikes":numLikes+1});
      post.isLiked = true;

      userRef.update({"points":points+1});

    });

    return post.isLiked;
  }

  Future<DocumentSnapshot> _getProfileDetails(userid){
    return  fbFirestore.doc("users/" + userid).get();
  }

  Widget buildProfilePic(userid) {
    return FutureBuilder(
        future: _getProfileDetails(userid),
        builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return Container(
              margin: EdgeInsets.all(5),
              width: 40.0,
              height: 40.0,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: NetworkImage(snapshot.data.get("photoUrl")),
                  fit: BoxFit.cover,
                ),
                borderRadius: BorderRadius.circular(80.0),
                border: Border.all(
                  color: Colors.grey[800],
                  width: 1.0,
                ),
              ),
            );
          }

          else if (snapshot.connectionState == ConnectionState.none) {
            print("No data");
          }
          return SpinKitPulse(
            size: 30,
            color: Colors.grey,
          );
        }
    );
  }

  _deletePost(Post post) async {
    print("starting process");



    DocumentReference postRef =
    fbFirestore
        .collection("challenges")
        .doc(widget.challengeid)
        .collection("posts")
        .doc(post.postid);

    Navigator.pop(context);
    Navigator.pop(context);
    Navigator.pop(context);
    Navigator.pop(context);
    Navigator.pop(context);
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) => ChallengeList()),
    );


    CollectionReference mapRef =    // delete from map
    fbFirestore
        .collection("challengemarkers")
        .doc(widget.challengeid)
        .collection("posts");

    await mapRef.get().then((snapshot) => snapshot.docs.forEach((p) {
      if (p.id==post.postid) {
        fbFirestore
            .collection("challengemarkers")
            .doc(widget.challengeid)
            .collection("posts")
            .doc(post.postid)
            .delete()
            .then((value) =>
        {print("post deleted from map")});
      }
    }));

    int pointsLikes= 0;
    int pointsComments= 0;

    await postRef.get().then((postData) {
      pointsLikes = postData.get("numLikes");
    });




    await postRef.collection("comments").get().then((snapshot) => snapshot.docs.forEach((com) {
      if (com.get("user-id")!=post.userid) {
        pointsComments+=3;
      }
    }));


    int pointsToDeduct = pointsLikes+pointsComments;


    DocumentReference userRef = FirebaseFirestore.instance.doc("users/" + post.userid);
    int points;
    int numLikes;
    await userRef.get().then((snapshot){
      int points = snapshot.get("points");
      userRef.update({"points":points-pointsToDeduct});
    });


    CollectionReference commentsRef =
    postRef.collection("comments");     // delete all comments in post

    await commentsRef.get().then((snapshot){
      for(int i = 0; i < snapshot.docs.length; i++){
        snapshot.docs[i].reference.delete();
      }
    });

    await postRef.delete();
    print("deleted post");


  }


  Widget getPost(Post post, String location) {
    // Function to create the post widgets

    return Padding(
      padding: const EdgeInsets.only(top: 25, left: 20, right: 20),
      child: Card(
        elevation: 20,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0),
        ),
        child: Column(
          children: [

            GestureDetector(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => UserProfilePage(
                            userid: post.userid)));
              },
              child: ListTile(
                minLeadingWidth: 50,
                  leading: buildProfilePic(post.userid),
                title: Text(post.user),
                subtitle: Text(location),
                trailing: GestureDetector(
                  child:Icon(Icons.more_vert),
                  onTap: (){
                    if(fbAuth.currentUser.uid == post.userid){
                      showMenu(
                        position: RelativeRect.fromLTRB(90,135,50,10),
                        items: <PopupMenuEntry>[
                          PopupMenuItem(
                              child: GestureDetector(
                                  child:Row(
                                    children: <Widget>[
                                      Icon(Icons.delete),
                                      Text("Delete"),
                                    ],
                                  ),
                                  onLongPress: () async {
                                    await _deletePost(post);
                                  }
                              )
                          )
                        ],
                        context: context,
                      );
                    }
                  },
                ),
              ),
            ),
            Container(
              child: Image.network(post.pictureLink),
            ),
            
            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  StreamBuilder(
                      stream:  fbFirestore.collection("challenges")
                          .doc(widget.challengeid)
                          .collection("posts")
                          .doc(post.postid).snapshots(),
                      builder: (context,snapshot) {
                        if(!snapshot.hasData)
                          return Padding(
                            padding: EdgeInsets.fromLTRB(10, 10, 5, 0),
                            child: LikeButton(
                              size: 26,
                              isLiked: post.isLiked,
                            ),
                          );
                        else {
                          return Padding(
                            padding: EdgeInsets.fromLTRB(10, 10, 5, 0),
                            child: LikeButton(
                              size: 26,
                              animationDuration: Duration(milliseconds: 1000),
                              likeCountAnimationDuration: Duration(
                                  milliseconds: 300),
                              likeCount: snapshot.data["likes"].length,
                              isLiked: post.isLiked,
                              onTap: (x) => _likePost(post),
                            ),
                          );
                        }
                      }
                  ),
                  Padding(
                    padding: EdgeInsets.fromLTRB(10, 10, 5, 0),
                    child: LikeButton(
                      bubblesColor: BubblesColor(
                        dotPrimaryColor: Colors.purple,
                        dotSecondaryColor: Colors.green,
                      ),
                      likeBuilder: (bool isCommented) {
                        return Icon(Icons.messenger_outline_rounded);
                      },
                      onTap: (x) {
                        return Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => PostCommentSection(
                                    post: post
                                )
                            )
                        );
                      },
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.fromLTRB(10, 10, 5, 0),
                    child: LikeButton(
                      size: 26,
                      bubblesColor: BubblesColor(
                        dotPrimaryColor: Colors.blue,
                        dotSecondaryColor: Colors.green,
                      ),
                      likeBuilder: (bool isShared) {
                        return Icon(Icons.share_outlined);
                      },
                    ),
                  ),
                ],
              ),
            ),
            Column(
              children: [
                SizedBox(
                  height: 5,
                ),
                Padding(
                  padding: EdgeInsets.all(10),
                  child: Container(child: Text(post.description)),
                ),
                SizedBox(
                  height: 10,
                )
              ],
            ),
          ],
        ),
      ),
    );
  }







  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading:(
            IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.pop(context);
              },
            )

        ),

        title: Text("Post",style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),),
        toolbarHeight: 65,
        //centerTitle: true,
        backgroundColor: Colors.black87,
      ),
      body: feedBody(),

    );
  }


}