import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:login/challenges/uploadToChallenge.dart';
import 'package:login/data/post.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:like_button/like_button.dart';
import 'package:login/profile/main-profileOther.dart';

class ChallengeDescription extends StatefulWidget {
  ChallengeDescription({Key key, this.name, this.desc, this.deadline, this.country, this.creatorid, this.creator}) : super(key: key);

  final String name;
  final String desc;
  final String deadline;
  final String country;
  final String creatorid;
  final String creator;

  ChallengeDescriptionState createState() => ChallengeDescriptionState();
}

class ChallengeDescriptionState extends State<ChallengeDescription> {

  final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;

  Future<DocumentSnapshot> _getProfileDetails(userid) {
    return fbFirestore.doc("users/" + userid).get();
  }

  Widget buildProfilePic(userid) {
    return FutureBuilder(
        future: _getProfileDetails(userid),
        builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return Container(
              margin: EdgeInsets.all(5),
              width: 40.0,
              height: 40.0,
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: NetworkImage(snapshot.data.get("photoUrl")),
                  fit: BoxFit.cover,
                ),
                borderRadius: BorderRadius.circular(80.0),
                border: Border.all(
                  color: Colors.grey[800],
                  width: 1.0,
                ),
              ),
            );
          } else if (snapshot.connectionState == ConnectionState.none) {
            print("No data");
          }
          return SpinKitPulse(
            size: 30,
            color: Colors.grey,
          );
        });
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        leading:(
            IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.pop(context);
              },
            )

        ),

        title: Text(widget.name,style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),),
        toolbarHeight: 65,
        //centerTitle: true,
        backgroundColor: Colors.black87,
        actions: <Widget>[],
      ),
      body: Stack(
        children: <Widget>[

          SafeArea(
            child: SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  Container(
                      padding: EdgeInsets.only( top: screenSize.height/35, left: screenSize.width/35),
                      child: Column(
                        children: <Widget>[


                          Container(
                            padding: EdgeInsets.only( left: screenSize.width/25),
                            alignment: Alignment.centerLeft,
                            child: Text(
                              'Challenge Description: ',
                              style: TextStyle(
                                  fontSize: 20.0, fontWeight: FontWeight.bold),
                            ),
                          ),
                          SizedBox(height: 20.0),
                          Container(
                            padding: EdgeInsets.only( left: screenSize.width/25),
                            alignment: Alignment.centerLeft,
                            child: Text(
                              widget.desc,
                              style: TextStyle(
                                fontSize: 20.0, ),
                            ),
                          ),

                          SizedBox(height: 30.0),
                          Container(
                            padding: EdgeInsets.only( left: screenSize.width/25),
                            alignment: Alignment.centerLeft,
                            child: Text(
                              'Deadline: ',
                              style: TextStyle(
                                  fontSize: 20.0, fontWeight: FontWeight.bold),
                            ),
                          ),
                          SizedBox(height: 20.0),
                          Container(
                            padding: EdgeInsets.only( left: screenSize.width/25),
                            alignment: Alignment.centerLeft,
                            child: Text(
                              widget.deadline + " at 12:00 AM",
                              style: TextStyle(
                                fontSize: 20.0, ),
                            ),
                          ),
                          SizedBox(height: 30.0),
                          Container(
                            padding: EdgeInsets.only( left: screenSize.width/25),
                            alignment: Alignment.centerLeft,
                            child: Text(
                              'Country: ',
                              style: TextStyle(
                                  fontSize: 20.0, fontWeight: FontWeight.bold),
                            ),
                          ),
                          SizedBox(height: 20.0),
                          Container(
                            padding: EdgeInsets.only( left: screenSize.width/25),
                            alignment: Alignment.centerLeft,
                            child: Text(
                              widget.country,
                              style: TextStyle(
                                fontSize: 20.0, ),
                            ),
                          ),
                          SizedBox(height: 30.0),
                          Container(
                            padding: EdgeInsets.only( left: screenSize.width/25),
                            alignment: Alignment.centerLeft,
                            child: Text(
                              'Creator: ',
                              style: TextStyle(
                                  fontSize: 20.0, fontWeight: FontWeight.bold),
                            ),
                          ),
                          SizedBox(height: 20.0),
                          GestureDetector(
                            child:
                            Row(
                              children: [
                                SizedBox(width: 30.0),
                                buildProfilePic(widget.creatorid),
                                SizedBox(width: 10.0),
                                Text(
                                  widget.creator+"       ",
                                  style: TextStyle(
                                    fontSize: 20.0, ),
                                ),

                              ],
                            ),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => UserProfilePage(userid: widget.creatorid),),
                              );
                            }
                          ),
                        ],
                      )


                  )


                ],
              ),
            ),
          )
        ],
      ),

    );
  }
}