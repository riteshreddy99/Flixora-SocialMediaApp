import 'package:flutter/material.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'package:line_icons/line_icons.dart';
import 'package:login/homePage.dart';
import 'package:login/leaderboard/main-leaderboard.dart';
import 'package:login/likes.dart';
import 'package:login/search.dart';
import 'package:login/profile/main-profile.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:flutter/cupertino.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _index = 0;

  List<Widget> _pageOptions = [
    HPage(),
    MainLeaderboard(),
    SPage(),
    MainProfile(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        // appBar: buildTopNavBar(context),
        // drawer: buildDrawer(context),
        bottomNavigationBar: CurvedNavigationBar(
          backgroundColor: Colors.black87,
          buttonBackgroundColor: Colors.black,
          color: Colors.grey[800],
          height: 60,
          items: <Widget>[
            Icon(
              LineIcons.home,
              size: 30,
              color: _index == 0 ? Colors.yellow[600] : Colors.white,
            ),
            Icon(
              Icons.leaderboard_outlined,
              size: 30,
              color: _index == 1 ? Colors.yellow[600] : Colors.white ,
            ),
            Icon(
              LineIcons.search,
              size: 30,
              color: _index == 2 ? Colors.yellow[600] : Colors.white,
            ),
            Icon(
              LineIcons.user,
              size: 30,
              color: _index == 3 ? Colors.yellow[600] : Colors.white,
            ),
          ],
          onTap: (index) {
            //Handle button tap
            setState(() {
              _index = index;
            });
          },
        ),
        body: SmartRefresher(
        enablePullDown: true,
        enablePullUp: true,
        header: WaterDropHeader(),
        footer: CustomFooter(
          builder: (BuildContext context,LoadStatus mode){
            Widget body ;
            if(mode==LoadStatus.idle)
              body =  Text("pull up load");

            else if(mode==LoadStatus.loading)
              body =  CupertinoActivityIndicator();

            else if(mode == LoadStatus.failed)
              body = Text("Load Failed!Click retry!");

            else if(mode == LoadStatus.canLoading)
              body = Text("release to load more");

            else
              body = Text("No more Data");

            return Container(
              height: 55.0,
              child: Center(child:body),
            );
          },
        ),
        controller: _refreshController,
        onRefresh: _onRefresh,
        onLoading: _onLoading,
        child:IndexedStack(
              index: _index,
              children: _pageOptions,
            )
        )
    );
  }

  RefreshController _refreshController =
  RefreshController(initialRefresh: false);

  void _onRefresh() async{
    // monitor network fetch
    await Future.delayed(Duration(milliseconds: 1000));
    Navigator.popAndPushNamed(context,'/home');
    // if failed,use refreshFailed()
    _refreshController.refreshCompleted();
  }

  void _onLoading() async{
    // monitor network fetch
    await Future.delayed(Duration(milliseconds: 1000));

    _refreshController.loadComplete();
  }
}
