import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:login/profile/edit-profile.dart';
import 'package:login/widgets/drawer.dart';
import 'package:login/widgets/grid.dart';
import 'package:login/helper/profile-image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:login/widgets/top-nav-bar.dart';
import 'package:login/widgets/following.dart';
import 'package:login/widgets/followers.dart';

import 'dart:io';

import '../homePage.dart';

void main() => runApp(MainProfile());

class MainProfile extends StatelessWidget {
  final String name = "Firstname Lastname";

  final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
  final FirebaseAuth fbAuth = FirebaseAuth.instance;

  Stream<DocumentSnapshot> _getProfileDetails() {
    String uid = fbAuth.currentUser.uid;
    return fbFirestore.doc("users/" + uid).snapshots();
  }

  Widget _buildCoverImage(Size screenSize) {
    return Container(
      //   margin: EdgeInsets.only(top: 0),
      height: screenSize.height / 2.3,
      decoration: BoxDecoration(
        color: Colors.grey[900],
      ),
    );
  }

  Widget _buildFullName() {
    TextStyle _nameTextStyle = TextStyle(
      fontFamily: 'Roboto',
      color: Colors.amber[100],
      fontSize: 20.0,
      // fontWeight: FontWeight.w700,
    );

    return StreamBuilder(
        stream: _getProfileDetails(),
        builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (snapshot.hasData) {
            if (snapshot.connectionState == ConnectionState.active) {
              String _fname = snapshot.data.get("first-name");
              String _lname = snapshot.data.get("last-name");

              return Text(_fname + " " + _lname, style: _nameTextStyle);
            } else if (snapshot.connectionState == ConnectionState.none) {
              print("No data");
            }
          } else
            print("eeoo");
          return Text("");
        });
  }

  Widget _buildStatItemfollowing(
      String label, String count, BuildContext context) {
    return GestureDetector(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              count,
              style: TextStyle(
                //color: Colors.black54,
                color: Colors.white,
                fontSize: 24.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                fontFamily: 'Roboto',
                color: Colors.white,
                fontSize: 16.0,
                fontWeight: FontWeight.w200,
              ),
            ),
          ],
        ),
        onTap: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) =>
                      FollowingPage(userid: fbAuth.currentUser.uid)));
        });
  }

  Widget _buildStatItemfollowers(
      String label, String count, BuildContext context) {
    return GestureDetector(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              count,
              style: TextStyle(
                //color: Colors.black54,
                color: Colors.white,
                fontSize: 24.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                fontFamily: 'Roboto',
                color: Colors.white,
                fontSize: 16.0,
                fontWeight: FontWeight.w200,
              ),
            ),
          ],
        ),
        onTap: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) =>
                      FollowersPage(userid: fbAuth.currentUser.uid)));
        });
  }

  Widget _buildStatItem(String label, String count) {
    TextStyle _statLabelTextStyle = TextStyle(
      fontFamily: 'Roboto',
      color: Colors.white,
      fontSize: 14.0,
      fontWeight: FontWeight.w200,
    );

    TextStyle _statCountTextStyle = TextStyle(
      //color: Colors.black54,
      color: Colors.white,
      fontSize: 24.0,
      fontWeight: FontWeight.bold,
    );

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Text(
          count,
          style: _statCountTextStyle,
        ),
        Text(
          label,
          style: _statLabelTextStyle,
        ),
      ],
    );
  }

  Stream<QuerySnapshot> _getPostsDetails() {
    String uid = fbAuth.currentUser.uid;
    return fbFirestore.collection("users/" + uid + "/posts").snapshots();
  }

  Widget _getScore(BuildContext context, Size screenSize) {
    return Container(
        width: screenSize.width,
        padding: EdgeInsets.only(left: 120, right: 120),
        //alignment: Alignment.bottomLeft,
        // color: Colors.pink,
        // child: Text("Points:"+Points.toString(), style: TextStyle(fontSize: 20),),
        child: StreamBuilder(
            stream: _getProfileDetails(),
            builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
              if (snapshot.connectionState == ConnectionState.active) {
                // return  RaisedButton(
                //   child: Text("Score: "+snapshot.data.get("points").toString(), style: TextStyle(fontSize: 18, color: Colors.white)),
                //   color: Colors.grey[900],
                //   onPressed: () {},
                //
                // );

                return FlatButton(
                  child: Text(
                    "Score : " + snapshot.data.get("points").toString(),
                    style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        color: Colors.yellow[700]),
                  ),
                  onPressed: () {},
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                      side: BorderSide(color: Colors.yellow[700])),
                );
              } else if (snapshot.connectionState == ConnectionState.none) {
                print("No data");
              }

              return CircularProgressIndicator();
            }));
  }

  Widget _buildStatContainer(BuildContext context) {
    return Container(
        height: 60.0, //height of the posts, followers table
        margin: EdgeInsets.only(top: 15.0), //space b/w name and table
        decoration: BoxDecoration(

            //color: Color(0xFFEFF4F7),
            ),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: <
            Widget>[
          Container(
            padding: EdgeInsets.only(left: 28),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: StreamBuilder(
                      stream: _getPostsDetails(),
                      builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
                        if (snapshot.connectionState == ConnectionState.active) {
                          return _buildStatItem(
                              "Posts", snapshot.data.docs.length.toString());
                        } else if (snapshot.connectionState == ConnectionState.none) {
                          print("No data");
                        }
                        return Text("");
                      }),
                ),
                //SizedBox(width: 30),
                Text(
                  "|",
                  style: TextStyle(fontSize: 30, color: Colors.yellow[700]),
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: StreamBuilder(
                      stream: _getProfileDetails(),
                      builder:
                          (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
                        if (snapshot.connectionState ==
                            ConnectionState.active) {
                          int followers = snapshot.data.get("followers").length;
                          return _buildStatItemfollowers(
                              "Followers",
                              followers.toString(),
                              context,);
                        } else if (snapshot.connectionState ==
                            ConnectionState.none) {
                          print("No data");
                        }
                        return Text("");
                      }),
                ),
                //SizedBox(width: 30),
                Text(
                  "|",
                  style: TextStyle(fontSize: 30, color: Colors.yellow[700]),
                ),

                Container(
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: StreamBuilder(
                      stream: _getProfileDetails(),
                      builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
                        if (snapshot.connectionState == ConnectionState.active) {
                          int following = snapshot.data.get("following").length;
                          return _buildStatItemfollowing(
                            "Following",
                            following.toString(),
                            context,
                          );
                        } else if (snapshot.connectionState == ConnectionState.none) {
                          print("No data");
                        }
                        return Text("");
                      }),
                ),
              ],
            ),
          ),
        ]));
  }

  Widget _buildBio(BuildContext context) {
    TextStyle optionalDarkStyle = TextStyle(color: Colors.grey, fontSize: 18.0);

    return StreamBuilder(
        stream: _getProfileDetails(),
        builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (snapshot.hasData) {
            if (snapshot.connectionState == ConnectionState.active) {
              print(snapshot);
              String bio = snapshot.data.get("bio");

              return Text(bio, style: optionalDarkStyle);
            } else if (snapshot.connectionState == ConnectionState.none) {
              print("No data");
            }
          } else
            print("nope");
          return Text("");
        });
  }

  // Widget _buildSeparator(Size screenSize) {
  //   return Container(
  //     width: screenSize.width / 1.6,
  //     height: 1.0,
  //    // color: Colors.black54,
  //     color: Colors.white,
  //     margin: EdgeInsets.only(top: 1.0),
  //   );
  // }

  /*Widget _buildGetInTouch(BuildContext context) {
    return Container(
      color: Theme.of(context).scaffoldBackgroundColor,
      padding: EdgeInsets.only(top: 8.0),
      child: Text(
        "Get in Touch with ${name.split(" ")[0]},",
        style: TextStyle(fontFamily: 'Roboto', fontSize: 16.0),
      ),
    );
  }
   */

  Widget _buildButtons(BuildContext context) {
    return RaisedButton(
      onPressed: () {
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => EditProfilePage()));
      },
      color: Colors.yellow[700],
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 60),
        child: Text("EDIT PROFILE"),
      ),
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20.0),
          side: BorderSide(color: Colors.yellow[700])),
      textColor: Colors.black,
    );
    // return Padding(
    //   padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
    //   child: Row(
    //     children: <Widget>[
    //       Expanded(
    //         child: InkWell(
    //           onTap: () => Navigator.push(
    //             context,
    //             MaterialPageRoute(builder: (context) => EditProfilePage()),
    //           ),
    //           child: Padding(
    //             padding: const EdgeInsets.only(right: 10, left: 10),
    //             child: Container(
    //               height: 40.0,
    //               decoration: BoxDecoration(
    //                 color: Colors.yellow[700],
    //               ),
    //               child: Center(
    //                 child: Padding(
    //                   padding: EdgeInsets.all(10.0),
    //                   child: Text(
    //                     "EDIT PROFILE",
    //                     style: TextStyle(
    //                         color: Colors.black, fontWeight: FontWeight.w600),
    //                   ),
    //                 ),
    //               ),
    //             ),
    //           ),
    //         ),
    //       ),
    //     ],
    //   ),
    // );
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    _getProfileDetails();
    return Scaffold(
      appBar: buildTopNavBar(context),
      drawer: buildDrawer(context),
      body: Stack(
        children: <Widget>[
          //     navBar(screenSize),

          // _buildCoverImage(screenSize),
          SafeArea(
            child: SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  Stack(
                    fit: StackFit.loose,
                    children: [
                      _buildCoverImage(screenSize),
                      SafeArea(
                        child: Column(
                          children: [
                            SizedBox(height: 20),
                            Center(child: buildProfilePic(currentUser.uid)),
                            SizedBox(height: 10),
                            Center(child: _buildFullName()),
                            SizedBox(height: 5),
                            SizedBox(height: 5),
                            Center(child: _buildBio(context)),
                            _buildStatContainer(context),

                            SizedBox(height: 5.0),
                            Center(child: _getScore(context, screenSize)),
                            //             _buildGetInTouch(context),
                            SizedBox(height: 20.0),
                            _buildButtons(context),
                            SizedBox(height: 15.0),
                          ],
                        ),
                      )
                    ],
                  ),
                  buildGridView(screenSize, fbAuth.currentUser.uid),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
