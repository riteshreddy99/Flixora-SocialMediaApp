import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_ml_vision/firebase_ml_vision.dart';
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'package:login/helper/profile-image.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image_cropper/image_cropper.dart';
import 'dart:io';
import 'package:image/image.dart' as Img;
import 'package:firebase_storage/firebase_storage.dart' as FBS;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../homePage.dart';

class EditProfilePage extends StatefulWidget {
  @override
  _EditProfilePageState createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  final picker = ImagePicker();
  File imgFile;
  bool isHuman;
  bool isUploading = false;
  String postID = Uuid().v4();

  final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
  final FirebaseAuth fbAuth = FirebaseAuth.instance;


  final fnameController = TextEditingController();
  final lnameController = TextEditingController();
  final usernameController = TextEditingController();
  final bioController = TextEditingController();

  Widget _buildBackground(Size screenSize) {
    return Container(
      height: screenSize.height,
      decoration: BoxDecoration(
        // color: Colors.black,
      ),
    );
  }

  Future<void> _showChoiceDialogue(BuildContext context) {
    return showDialog(

        context: context,
        builder: (BuildContext context) {

          return AlertDialog(
            backgroundColor: Colors.black,

            title: Text("Choose Option",style: TextStyle(color: Colors.yellow[600])),
            elevation: 8,

            content: SingleChildScrollView(
                child: ListBody(
                  children: <Widget>[

                    GestureDetector(
                      child: Text("Open Gallery",style: TextStyle(color: Colors.amber[100])),
                      onTap: () {
                        _getImage(ImageSource.gallery);
                      },
                    ),
                    Padding(padding: EdgeInsets.all(8.0)),
                    GestureDetector(
                      child: Text("Open Camera",style: TextStyle(color: Colors.amber[100])),
                      onTap: () {
                        _getImage(ImageSource.camera);
                      },
                    ),
                  ],
                )),
          );
        });
  }

  _getImage(ImageSource src) async {
    final pickedFile = await picker.getImage(source: src);
    if (pickedFile != null) {
      File cropped = await ImageCropper.cropImage(
          sourcePath: pickedFile.path,
          cropStyle: CropStyle.circle,
          aspectRatio: CropAspectRatio(ratioX: 1, ratioY: 1),
          compressFormat: ImageCompressFormat.jpg,
          androidUiSettings: AndroidUiSettings(
            toolbarTitle: "Crop Image",
          ));

      final image = FirebaseVisionImage.fromFile(cropped);
      final faceDetector = FirebaseVision.instance.faceDetector(
        FaceDetectorOptions(
          mode: FaceDetectorMode.accurate,
          enableLandmarks: true,
        ),
      );

      List<Face> faces = await faceDetector.processImage(image);
      Navigator.pop(context);
      if (faces.isEmpty) {
        setState(() {
          imgFile = File(cropped.path);
        });
        isUploading = true;
        //imageCompress to 80%
        final temporaryDir = await getTemporaryDirectory();
        final path = temporaryDir.path;
        Img.Image imageFile = Img.decodeImage(imgFile.readAsBytesSync());
        final compImgFile = File('$path/img_$postID,jpg')
          ..writeAsBytes(Img.encodeJpg(imageFile, quality: 80));

        FBS.UploadTask upTask =
        storageRef.child("post_$postID.jpg").putFile(imgFile);
        String imgURL = await (await upTask).ref.getDownloadURL();

        String uid = FirebaseAuth.instance.currentUser.uid;
        userRef.doc(uid).update({
          "photoUrl" : imgURL
        });



        setState(() {
          imgFile = null;
          isUploading = false;
          postID = Uuid().v4();
        });

        Navigator.pop(context);

        setState(() {
          imgFile = compImgFile;
        });
      } else {
        setState(() {
          isHuman = true;
          Navigator.pop(context);
        });
      }
    }
  }

  Widget _buildButton() {
    return Padding(
        padding: EdgeInsets.all(8.0),
        child: RichText(
          text: TextSpan(
              text: 'Change Profile Picture',
              style: TextStyle(color: Colors.white, fontSize: 18.0),
              recognizer: TapGestureRecognizer()
                ..onTap = () {
                  _showChoiceDialogue(context);
                }),
        ));
  }

  Widget _buildTextBoxes(Size screenSize) {
    TextStyle defaultDarkStyle = TextStyle(color: Colors.amber[100], fontSize: 18.0);
    TextStyle defaultDarkStyle2 = TextStyle(color: Colors.white, fontSize: 18.0);
    TextStyle hintStyle = TextStyle(color: Colors.white54, fontSize: 18.0);

    return Padding(
      padding: EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          new Text(
            "First Name",
            style: defaultDarkStyle,
          ),
          new TextField(
            style: defaultDarkStyle2,
            decoration: new InputDecoration(
              hintStyle: hintStyle,
              enabledBorder: const UnderlineInputBorder(
                borderSide: const BorderSide(color: Colors.white),
              ),
              focusedBorder: const UnderlineInputBorder(
                borderSide: const BorderSide(color: Colors.yellow),

              ),
              hintText: "First Name",
            ),
            controller: fnameController,
          ),
          new SizedBox(height: 30),
          new Text(
            "Last Name",
            style: defaultDarkStyle,
          ),
          new TextField(
            style: defaultDarkStyle2,
            decoration: new InputDecoration(
              hintStyle: hintStyle,
              enabledBorder: const UnderlineInputBorder(
                borderSide: const BorderSide(color: Colors.white),
              ),
              focusedBorder: const UnderlineInputBorder(
                borderSide: const BorderSide(color: Colors.yellow),

              ),
              hintText: "Last Name",
            ),
            controller: lnameController,
          ),
          new SizedBox(height: 30),
          new Text(
            "Username",
            style: defaultDarkStyle,
            textAlign: TextAlign.left,
          ),
          new TextField(
            style: defaultDarkStyle2,
            decoration: new InputDecoration(
              hintStyle: hintStyle,
              enabledBorder: const UnderlineInputBorder(
                borderSide: const BorderSide(color: Colors.white),
              ),
              focusedBorder: const UnderlineInputBorder(
                borderSide: const BorderSide(color: Colors.yellow),

              ),
              hintText: "Username",
            ),
            controller: usernameController,
          ),
          new SizedBox(height: 30),
          new Text(
            "Bio",
            style: defaultDarkStyle,
            textAlign: TextAlign.left,
          ),
          new TextField(
            style: defaultDarkStyle2,
            decoration: new InputDecoration(
              hintStyle: hintStyle,
              enabledBorder: const UnderlineInputBorder(
                borderSide: const BorderSide(color: Colors.white),
              ),
              focusedBorder: const UnderlineInputBorder(
                borderSide: const BorderSide(color: Colors.yellow),

              ),
              hintText: "Bio",
            ),
            controller: bioController,
          )
        ],
      ),
    );
  }

  Future<void> _updateData() async{

    String currID = fbAuth.currentUser.uid;
    DocumentReference userRef = fbFirestore.collection("users").doc(currID);

    await userRef.get().then((snapshot){
      String newFirstName, newBio, newUsername, newLastName;

      if(fnameController.text.isEmpty)
        newFirstName = snapshot.get("first-name");
      else
        newFirstName = fnameController.text;

      if(lnameController.text.isEmpty)
        newLastName = snapshot.get("last-name");
      else
        newLastName = lnameController.text;

      if(bioController.text.isEmpty)
        newBio = snapshot.get("bio");
      else
        newBio = bioController.text;

      if(usernameController.text.isEmpty)
        newUsername = snapshot.get("username");
      else
        newUsername = usernameController.text;

      Map<String, dynamic> newUserData = {
        "first-name": newFirstName,
        "last-name": newLastName,
        "bio": newBio,
        "username": newUsername
      };

      userRef.update(newUserData);

      fnameController.clear();
      lnameController.clear();
      usernameController.clear();
      bioController.clear();

      Navigator.pop(context);

    });
  }

  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.black,
          elevation: 15,
          shadowColor: Colors.amber[100],
          leading: (IconButton(
            icon: Icon(
              Icons.arrow_back,
              color: Colors.white,
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          )),
          title: Text("Edit Profile",style: TextStyle(color: Color(0xfffdd835))),
          toolbarHeight: 65,
          centerTitle: true,
          actions: <Widget>[
            IconButton(
              icon: Icon(
                Icons.check,
                color: Colors.white,
              ),
              onPressed: () => _updateData(),
            )
          ],
        ),
        body: Stack(children: <Widget>[
          isUploading == false ? Text("") : LinearProgressIndicator(),
          SafeArea(
              child: SingleChildScrollView(
                  child: Column(
                    children: <Widget>[
                      Stack(
                        children: [
                          _buildBackground(screenSize),
                          SafeArea(
                              child: Column(
                                children: [
                                  SizedBox(height: screenSize.height / 20),
                                  buildProfilePic(fbAuth.currentUser.uid),
                                  _buildButton(),
                                  SizedBox(height: 30),
                                  _buildTextBoxes(screenSize)
                                ],
                              ))
                        ],
                      )
                    ],
                  )))
        ]));
  }
}
