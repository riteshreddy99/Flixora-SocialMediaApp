import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:login/widgets/grid.dart';
import 'package:login/widgets/chatscreen.dart';
import 'package:login/widgets/top-nav-bar.dart';
import 'package:login/helper/profile-image.dart';
import 'package:login/widgets/drawer.dart';
import 'package:login/widgets/BottomNavBar.dart';
import 'package:login/data/post.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:login/helper/notifications.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:login/widgets/following.dart';
import 'package:login/widgets/followers.dart';

void main() => runApp(UserProfilePage());


class UserProfilePage extends StatefulWidget {
  UserProfilePage({Key key, this.userid}) : super(key: key);

  final String userid;
  //Post post;

  @override
  _UserProfilePage createState() => _UserProfilePage();
}

class _UserProfilePage extends State<UserProfilePage> {

  final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
  final FirebaseAuth fbAuth = FirebaseAuth.instance;

  String followerID;
  String followerName;



  /*
  Future<String> getData(String petId) async {
    String uid = fbAuth.currentUser.uid;
    //   DocumentReference userRef = fbFirestore.collection("users/" + uid).doc();


    // await userRef.get().then((snapshot) {
    //   fname = snapshot.get("first-name").toString();
    //   lname = snapshot.get("last-name").toString();
    //
    //   fullName = fname + " " + lname;
    //   print(fname);
    // });

    return null;
  }

 */



  Future<DocumentSnapshot> _getProfileDetails(){
    String uid = widget.userid;
    print("uid"+uid);
    return  fbFirestore.doc("users/" + uid).get();
  }

  Widget coverImage(Size screenSize) {
    return Container(
      //   margin: EdgeInsets.only(top: 0),
      height: screenSize.height / 2.3,
      decoration: BoxDecoration(

        color: Colors.black,


      ),

    );
  }



  Widget _buildFullName() {
    TextStyle _nameTextStyle = TextStyle(
      fontFamily: 'Roboto',
      color: Colors.amber[100],
      fontSize: 20.0,
      // fontWeight: FontWeight.w700,
    );

    return FutureBuilder(
        future: _getProfileDetails(),
        builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            String _fname = snapshot.data.get("first-name");
            String _lname = snapshot.data.get("last-name");
            followerName = _fname + " " + _lname;

            return Text(followerName, style: _nameTextStyle);
          }

          else if (snapshot.connectionState == ConnectionState.none) {
            print("No data");
          }
          return CircularProgressIndicator();
        }
    );
  }




  Widget _buildBio(BuildContext context) {

    TextStyle optionalDarkStyle = TextStyle(color: Colors.grey, fontSize: 18.0);


    return FutureBuilder(
        future: _getProfileDetails(),
        builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {

            String bio = snapshot.data.get("bio");

            return Text(bio, style: optionalDarkStyle);
          }

          else if (snapshot.connectionState == ConnectionState.none) {
            print("No data");
          }
          return CircularProgressIndicator();
        }
    );
  }


  Widget _buildStatItemfollowing(String label,String count)
  {
    return GestureDetector(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              count,
              style: TextStyle(
                //color: Colors.black54,
                color: Colors.white,
                fontSize: 24.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                fontFamily: 'Roboto',
                color: Colors.white,
                fontSize: 16.0,
                fontWeight: FontWeight.w200,
              ),
            ),
          ],
        ),
        onTap: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) =>
                      FollowingPage(userid: widget.userid)));
        }

    );

  }



  Widget _buildStatItemfollowers(String label,String count)
  {
    return GestureDetector(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              count,
              style: TextStyle(
                //color: Colors.black54,
                color: Colors.white,
                fontSize: 24.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                fontFamily: 'Roboto',
                color: Colors.white,
                fontSize: 16.0,
                fontWeight: FontWeight.w200,
              ),
            ),
          ],
        ),
        onTap: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) =>
                      FollowersPage(userid: widget.userid)));
        }

    );

  }



  Widget _buildStatItem(String label, String count) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        Text(
          count,
          style: TextStyle(
            //color: Colors.black54,
            color: Colors.white,
            fontSize: 24.0,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontFamily: 'Roboto',
            color: Colors.white,
            fontSize: 16.0,
            fontWeight: FontWeight.w200,
          ),
        ),
      ],
    );
  }


  Future<QuerySnapshot> _getPostsDetails() async {
    String uid = widget.userid;
    return fbFirestore.collection("users/" + uid + "/posts").get();
  }



  Widget _buildStatContainer() {

    return Container(
      height: 60.0,   //height of the posts, followers table
      margin: EdgeInsets.only(top: 15.0),  //space b/w name and table
      decoration: BoxDecoration(
        //color: Color(0xFFEFF4F7),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[

          FutureBuilder(
              future: _getPostsDetails(),
              builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
                if (snapshot.connectionState == ConnectionState.done) {

                  return _buildStatItem("Posts", snapshot.data.docs.length.toString());
                }

                else if (snapshot.connectionState == ConnectionState.none) {
                  print("No data");
                }
                return SpinKitCircle(color: Colors.blue,);
              }
          ),
          SizedBox(width:30),
          FutureBuilder(
              future: _getProfileDetails(),
              builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
                if (snapshot.connectionState == ConnectionState.done) {

                  int followers = snapshot.data.get("followers").length;
                  return _buildStatItemfollowers("Followers", followers.toString());
                }

                else if (snapshot.connectionState == ConnectionState.none) {
                  print("No data");
                }
                return SpinKitCircle(color: Colors.blue,);
              }
          ),
          SizedBox(width:30),
          FutureBuilder(
              future: _getProfileDetails(),
              builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
                if (snapshot.connectionState == ConnectionState.done) {

                  int following = snapshot.data.get("following").length;
                  return _buildStatItemfollowing("Following", following.toString());
                }

                else if (snapshot.connectionState == ConnectionState.none) {
                  print("No data");
                }
                return SpinKitCircle(color: Colors.blue,);
              }
          ),

        ],
      ),
    );
  }



  String textOnButton1 = 'FOLLOW';

  Future<DocumentSnapshot> _checkFollowing() async{
    String uid = widget.userid;
    String currentUser = fbAuth.currentUser.uid;
    DocumentReference userRef = fbFirestore.collection("users").doc(uid);
    followerID = uid;

    await userRef.get().then((snapshot) {
      var followers = snapshot.get("followers");
      bool isFollowing = false;

      for(String follower in followers){
        if(currentUser == follower)
          isFollowing = true;
      }

      if(isFollowing==true)
        textOnButton1 = 'FOLLOWING';

      else
        textOnButton1 = 'FOLLOW';

      return snapshot;
    });
  }


  Widget _getScore(BuildContext context, Size screenSize) {
    int Points;

    Future<DocumentSnapshot> getPoints() async {
      String uid = widget.userid;
      DocumentReference userRef = fbFirestore.collection("users").doc(uid);

      await userRef.get().then((snapshot) {
        // print("in here");
        Points = snapshot.get("points");

        return snapshot;
      });


    }

    return Container(
        width: screenSize.width,
        padding: EdgeInsets.only(left: screenSize.width/15),
        alignment: Alignment.bottomLeft,
        // color: Colors.pink,
        // child: Text("Points:"+Points.toString(), style: TextStyle(fontSize: 20),),
        child: FutureBuilder(
            future: getPoints(),
            builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
              if (snapshot.connectionState == ConnectionState.done) {

                return  RaisedButton(
                  child: Text("Score: "+Points.toString(), style: TextStyle(fontSize: 18, color: Colors.white),),
                  color: Colors.grey[900],
                  onPressed: () {},

                );
              }

              else if (snapshot.connectionState == ConnectionState.none) {
                print("No data");
              }

              return CircularProgressIndicator();
            }
        )
    );


  }


  Widget _buildButtons(BuildContext context) {

    void changeTextOnFollow() async {
      String uid = widget.userid;
      String currentUser = fbAuth.currentUser.uid;
      DocumentReference userRef = fbFirestore.collection("users").doc(uid);
      DocumentReference currUserRef = fbFirestore.collection("users").doc(currentUser);

      // update on current user's end
      await currUserRef.get().then((snapshot){
        var following = snapshot.get("following");
        bool isFollowing = false;

        for(String follower in following){
          if(uid == follower)
            isFollowing = true;
        }

        if(isFollowing==false) {
          following.add(uid);
          currUserRef.update({"following":following});

          isFollowing = true;
        }
        else {
          following.remove(uid);
          currUserRef.update({"following":following});

          isFollowing = false;
        }

      });
      bool isFollowing;
      // update on user whose profile has been visited
      await userRef.get().then((snapshot){

        var followers = snapshot.get("followers");
        isFollowing = false;

        for(String follower in followers){
          if(currentUser == follower)
            isFollowing = true;
        }

        if(isFollowing==false) {
          followers.add(currentUser);
          userRef.update({"followers":followers});

          setState(() {
            textOnButton1 = 'FOLLOWING';
          });
          isFollowing = true;
        }
        else {
          followers.remove(currentUser);
          userRef.update({"followers":followers});

          setState(() {
            textOnButton1 = 'FOLLOW';
          });
          isFollowing = false;
        }
      });

      if(isFollowing) {           // send notif to user
        DocumentReference user =
        fbFirestore.collection("users")
            .doc(fbAuth.currentUser.uid);

        String username;

        await user.get().then((snapshot) {
          username = snapshot.get("username");
        });

        DocumentReference posterRef =
        fbFirestore.collection("users")
            .doc(widget.userid)
            .collection("notifications").doc();

        Map<String, dynamic> notifData = {
          "message": "started following you!",
          "time-sent": DateTime.now(),
          "type": "follow",
          "userID": fbAuth.currentUser.uid,
          "username": username,
          "refPID":null,
          "refUID":fbAuth.currentUser.uid,
        };

        sendNotif(widget.userid,"has followed you!");
        posterRef.set(notifData);
      }
    }




    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      child: Row(
        children: <Widget>[
          const SizedBox(height: 40,width: 10,),
          Expanded(

              child: RaisedButton(
                onPressed: (){
                  changeTextOnFollow();
                  /*
               AlertDialog alert = AlertDialog(
                 backgroundColor: Colors.black54,
                  content: Stack(
                    children: <Widget>[
                      IconButton(
                        icon: Icon(
                          Icons.check,
                          color: Colors.white,
                        ),
                        //onPressed: (){},
                      ),
                      Text("FOLLOWED",textAlign: TextAlign.center,style: TextStyle(color: Colors.white))
                    ],
                      ),


                );

                showDialog(
                  barrierColor: Colors.white.withOpacity(0),
                  context: context,
                  builder: (BuildContext context) {
                    return alert;
                  },
                );

                 */
                },

                color: Colors.yellow[600],
                padding: EdgeInsets.all(10.0),

                child: FutureBuilder(
                    future: _checkFollowing(),
                    builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
                      if (snapshot.connectionState == ConnectionState.done) {

                        return Text(
                          "$textOnButton1",
                          style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                              fontSize: 15
                          ),
                        );
                      }

                      else if (snapshot.connectionState == ConnectionState.none) {
                        print("No data");
                      }
                      return CircularProgressIndicator();
                    }
                ),

              )


          ),
          const SizedBox(height: 40,width: 10,),
          Expanded(
            child: RaisedButton(
              onPressed: (){
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => ChatScreen(
                            userProfileId: followerID,
                            userName: followerName
                        )
                    )
                ); // Navigator
              },

              padding: EdgeInsets.all(10.0),
              color: Colors.white,


              child: const Text(
                'MESSAGE',
                style: TextStyle(
                    color: Colors.black,
                    fontWeight: FontWeight.w600,
                    fontSize: 15
                ),
              ),

            ),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    _getProfileDetails();
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.black,
        elevation: 15,
        shadowColor: Colors.grey[700],
        leading:(
            IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: Colors.white,
              ),
              onPressed: (){
                Navigator.pop(context);
              },
            )
        ),
        title: Text("Flixora",style: TextStyle(color: Color(0xfffdd835))),
        toolbarHeight: 65,
        centerTitle: true,
        actions: <Widget>[
          IconButton(
            icon: Icon(
              Icons.messenger_outline_rounded,
              color: Colors.white,
            ),
            //onPressed: (){},
          )
        ],
      ),
      drawer: buildDrawer(context),
      body: Stack(
        children: <Widget>[
          SafeArea(
            child: SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  Stack(
                    fit: StackFit.loose,
                    children: [
                      coverImage(screenSize),
                      SafeArea(child: Column(
                        children: [
                          SizedBox(height:20),
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceAround ,
                              children: <Widget>[
                                buildProfilePic(widget.userid),
                                _buildStatContainer(),
                              ]
                          ),
                          SizedBox(height:5),
                          Row(
                              mainAxisAlignment: MainAxisAlignment.start  ,
                              children: <Widget>[
                                SizedBox(width: 30,),
                                _buildFullName(),
                              ]
                          ),
                          SizedBox(height:5),
                          Row(
                              mainAxisAlignment: MainAxisAlignment.start  ,
                              children: <Widget>[
                                SizedBox(width: 30,),
                                _buildBio(context),
                              ]
                          ),

                          SizedBox(height: 5.0),
                          _getScore(context, screenSize),
                          //             _buildGetInTouch(context),
                          SizedBox(height: 8.0),
                          _buildButtons(context),
                        ],

                      ),)
                    ],

                  ),

                  buildGridView(screenSize, widget.userid),
                ],
              ),
            ),
          ),

        ],
      ),
    );
  }
}
