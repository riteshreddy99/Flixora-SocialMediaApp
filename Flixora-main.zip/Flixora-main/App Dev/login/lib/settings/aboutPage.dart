import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'package:login/challenges/viewChallenge.dart';
import 'package:uuid/uuid.dart';

class AboutPage extends StatefulWidget {
  AboutPage({Key key, this.userProfileId}) : super(key: key);

  final String userProfileId;

  AboutPageState createState() => AboutPageState();
}

class AboutPageState extends State<AboutPage> {
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        leading: (IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        )),

        title: Text(
          "About",
          style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),
        ),
        toolbarHeight: 65,
        //centerTitle: true,
        backgroundColor: Colors.black87,
        actions: <Widget>[],
      ),
      body: Stack(
        children: <Widget>[
          SafeArea(
            child: SingleChildScrollView(
              child: Container(
                child: Column(
                  children: [
                    SizedBox(height:15),
                    Text("Flixora aims to provide individuals with a passion for photography, a place of comfort. By providing them with different "
                        "categorical pages that may help them discover new styles of photography, make friends, and compete against others. ",
                    style: TextStyle(color: Colors.white, fontSize: 18.0)
                    ),
                    SizedBox(height: 15,),
                    Text("Our main goal is to provide a safe haven for like-minded individuals who love to photograph and explore. Unlike our "
                        "competitors, our idea is solely based for users to be able to upload pictures of objects and animals they spot and love.",
                        style: TextStyle(color: Colors.white, fontSize: 18.0)),
                    SizedBox(height: 15,),
                    Text("We aim to be different compared to other photography apps and provide a unique twist on how users interact with each other "
                        "and the system. Furthermore, photography enthusiasts should be able to challenge regional players to see who can complete "
                        "challenges that are local themed. Flixora aims to be unique in its own format, and be a haven for photography lovers, that "
                        "being beginners or even pros.",
                        style: TextStyle(color: Colors.white, fontSize: 18.0)),
                    SizedBox(height: 15,),
                    Text("Our group of dedicated students are aiming to allow individuals to access the platform both on iOS and Android, as well as,"
                        " from the comfort of their browser, at any time and from any place.",
                        style: TextStyle(color: Colors.white, fontSize: 18.0)),
                  ],



                ),

              ),
            ),
          )
        ],
      ),
    );
  }

}