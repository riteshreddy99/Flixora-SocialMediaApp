import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'package:login/challenges/viewChallenge.dart';
import 'package:uuid/uuid.dart';

class ScorePoints extends StatefulWidget {
  ScorePoints({Key key, this.userProfileId}) : super(key: key);

  final String userProfileId;

  ScorePointsState createState() => ScorePointsState();
}

class ScorePointsState extends State<ScorePoints> {
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        leading: (IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        )),

        title: Text(
          "Scoring Points",
          style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),
        ),
        toolbarHeight: 65,
        //centerTitle: true,
        backgroundColor: Colors.black87,
        actions: <Widget>[],
      ),
      body: Stack(
        children: <Widget>[
          SafeArea(
            child: SingleChildScrollView(
              child: Container(
                child: Column(
                  children: [
                    SizedBox(height:15),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        child: Text(
                          "Global Leaderboard",
                          style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
                        ),
                      ),
                    ),
                    SizedBox(height: 5,),
                    Text("Participate in challenges and earn likes and comments from other users to rise up on the leaderboard! "
                        "Each like is worth 1 point and comments by other users are worth 3 points!",
                        style: TextStyle(color: Colors.white, fontSize: 18.0)),

                    SizedBox(height: 25,),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        child: Text(
                          "Challenges",
                          style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
                        ),
                      ),
                    ),
                    SizedBox(height: 5,),
                    Text("You can interact with posts on every existing challenge. However, you can upload posts only on global challenges or challenges"
                        " that are specifically set to your country by the creator of the challenge. You can upload multiple posts to one challenge."
                        " The posts occupy the positions on the leaderboard rather than the users.",
                        style: TextStyle(color: Colors.white, fontSize: 18.0)),


                    SizedBox(height: 25,),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        child: Text(
                          "Challenge Leaderboard",
                          style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
                        ),
                      ),
                    ),
                    SizedBox(height: 5,),
                    Text("Upload your clicks and earn likes to collect users points."
                        " Each like is worth 1 point. Earn likes to get your posts to a higher position on the leaderboard.",
                        style: TextStyle(color: Colors.white, fontSize: 18.0)),
                  ],



                ),

              ),
            ),
          )
        ],
      ),
    );
  }

}