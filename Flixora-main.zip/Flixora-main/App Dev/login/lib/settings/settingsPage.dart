import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:login/settings/termsandcond.dart';
import 'package:login/settings/aboutPage.dart';
import 'package:login/settings/team.dart';
import 'package:login/settings/scorePoints.dart';
import 'package:login/revampedSignup/AuthenService.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'package:login/challenges/viewChallenge.dart';
import 'package:uuid/uuid.dart';

class SettingsPage extends StatefulWidget {
  SettingsPage({Key key, this.userProfileId}) : super(key: key);

  final String userProfileId;

  SettingsPageState createState() => SettingsPageState();
}

class SettingsPageState extends State<SettingsPage> {

  showAlertDialog(BuildContext context, String msg) {
    // set up the button
    Widget okButton = FlatButton(
      child: Text("OK"),
      onPressed: () {
        Navigator.pop(context);
      },
    );
    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("Reset Password"),
      content: Text(msg),
      actions: [
        okButton,
      ],
    );
    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        leading: (IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        )),

        title: Text(
          "Settings",
          style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),
        ),
        toolbarHeight: 65,
        //centerTitle: true,
        backgroundColor: Colors.black87,
        actions: <Widget>[],
      ),
      body: Stack(
        children: <Widget>[
          SafeArea(
            child: SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  Container(
                    child: Row(
                      children: [
                        SizedBox(),
                        IconButton(
                            icon: Icon(Icons.security),
                            onPressed: () async {
                              final auth = FirebaseAuth.instance;
                              String email = auth.currentUser.email;
                              await auth.sendPasswordResetEmail(
                                  email: auth.currentUser.email);
                              showAlertDialog(context, "Please check your email $email for further instructions");
                            },),
                        SizedBox(),
                        GestureDetector(
                          child: Text("Change Password                 ", style: TextStyle(color: Colors.white, fontSize: 20.0, fontWeight: FontWeight.w500),),
                          onTap: () async {
                            final auth = FirebaseAuth.instance;
                            String email = auth.currentUser.email;
                            await auth.sendPasswordResetEmail(
                                email: auth.currentUser.email);
                            showAlertDialog(context, "Please check your email $email for further instructions");
                          },
                        )
                      ],
                    ),

                  ),

                  Container(
                    child: Row(
                      children: [
                        SizedBox(),
                        IconButton(
                          icon: Icon(Icons.integration_instructions_outlined),
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) => ScorePoints()),);
                          },),
                        SizedBox(),
                        GestureDetector(
                          child: Text("How to Earn Points                ", style: TextStyle(color: Colors.white, fontSize: 20.0, fontWeight: FontWeight.w500),),
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) => ScorePoints()),);
                          },
                        )
                      ],
                    ),

                  ),

                  Container(
                    child: Row(
                      children: [
                        SizedBox(),
                        IconButton(
                            icon: Icon(Icons.people_alt_rounded),
                            onPressed: () {
                              Navigator.push(context, MaterialPageRoute(builder: (context) => TeamPage()),);
                            }),
                        SizedBox(),
                        GestureDetector(
                          child: Text("The Team                         ", style: TextStyle(color: Colors.white, fontSize: 20.0, fontWeight: FontWeight.w500),),
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) => TeamPage()),);
                          },
                        )
                      ],
                    ),

                  ),
                  Container(
                    child: Row(
                      children: [
                        SizedBox(),
                        IconButton(
                            icon: Icon(Icons.info_outline_rounded),
                            onPressed: () {
                              Navigator.push(context, MaterialPageRoute(builder: (context) => AboutPage()),);
                            }),
                        SizedBox(),
                        GestureDetector(
                          child: Text("About                            ", style: TextStyle(color: Colors.white, fontSize: 20.0, fontWeight: FontWeight.w500),),
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) => AboutPage()),);
                          },
                        )
                      ],
                    ),

                  ),
                  Container(
                    child: Row(
                      children: [
                        SizedBox(),
                        IconButton(
                            icon: Icon(Icons.article_outlined),
                            onPressed: () {
                              Navigator.push(context, MaterialPageRoute(builder: (context) => TermsCond()),);
                            }),
                        SizedBox(),
                        GestureDetector(
                          child: Text("Terms and Conditions       ", style: TextStyle(color: Colors.white, fontSize: 20.0, fontWeight: FontWeight.w500),),
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) => TermsCond()),);
                          },
                        )
                      ],
                    ),

                  ),
                  Container(
                    child: Row(
                      children: [
                        SizedBox(),
                        IconButton(
                            icon: Icon(Icons.logout),
                            onPressed: () {
                              context.read<AuthenService>().signOut();
                            }),
                        SizedBox(),
                        GestureDetector(
                          child: Text("Log Out                                   ", style: TextStyle(color: Colors.white, fontSize: 20.0, fontWeight: FontWeight.w500),),
                          onTap: () {
                            context.read<AuthenService>().signOut();
                          },
                        )
                      ],
                    ),

                  ),

                  ListTile(
                    leading: Text("Delete account", style: TextStyle(fontSize: 26),
                    ),
                    onTap: () {

                    },
                  )


                  // _buildChallengeTile(screenSize),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

}
