import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'package:login/challenges/viewChallenge.dart';
import 'package:uuid/uuid.dart';

class TeamPage extends StatefulWidget {
  TeamPage({Key key, this.userProfileId}) : super(key: key);

  final String userProfileId;

  TeamPageState createState() => TeamPageState();
}

class TeamPageState extends State<TeamPage> {
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        leading: (IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Colors.white,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        )),

        title: Text(
          "The Team",
          style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),
        ),
        toolbarHeight: 65,
        //centerTitle: true,
        backgroundColor: Colors.black87,
        actions: <Widget>[],
      ),
      body: Stack(
        children: <Widget>[
          SafeArea(
            child: SingleChildScrollView(
              child: Container(
                child: Column(
                  children: [
                    SizedBox(height:8),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        child: Text(
                          "About Us",
                          style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
                        ),
                      ),
                    ),
                    SizedBox(height:15),
                    Text("We are a group of students based in the United Arab Emirates who attend Heriot-Watt University. "
                        "We are in our third year of our Bachelor’s in computer science. ",
                        style: TextStyle(color: Colors.white, fontSize: 18.0)
                    ),
                    SizedBox(height: 15,),
                    Text("Our idea is based both on a web application, as well as, on a mobile application. It is a photography application that enables "
                        "users to be able to interact with a community of photographers and hobbyists alike.",
                        style: TextStyle(color: Colors.white, fontSize: 18.0)),
                    SizedBox(height: 15,),
                    Text("Our main goal is to create a safe haven for like-minded individuals who love to photograph and love to explore. Unlike our "
                        "competitors, our idea is solely based for users to be able to upload pictures of objects and animals they spot and love.",
                        style: TextStyle(color: Colors.white, fontSize: 18.0)),
                    SizedBox(height: 15,),
                    Text("Our group of dedicated students are aiming to allow individuals to access the platform both on iOS and Android, as well as,"
                        " from the comfort of their browser, any time, any place.",
                        style: TextStyle(color: Colors.white, fontSize: 18.0)),
                    SizedBox(height: 15,),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        child: Text(
                          "Members and their Github IDs",
                          style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18.0),
                        ),
                      ),
                    ),
                    SizedBox(height: 12,),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        child: GestureDetector(
                          child: Text("Sumaiya Arshad     : Sfa29",
                            style: TextStyle(fontWeight: FontWeight.w300, fontSize: 18.0),),
                          onTap: () {
                            Navigator.of(context).pushNamed('/forgotpw');
                          },
                          
                        )
                        
                      ),
                    ),
                    SizedBox(height: 5,),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        child: Text("Yousuf Ashraf El-Baesy     : Aymr07 ",
                          style: TextStyle(fontWeight: FontWeight.w300, fontSize: 18.0),),
                      ),
                    ),
                    SizedBox(height: 5,),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        child: Text("Harini Balamurugan     : HariniBalamurugan",
                          style: TextStyle(fontWeight: FontWeight.w300, fontSize: 18.0),),
                      ),
                    ),
                    SizedBox(height: 5,),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        child: Text("Ritesh Bandam Reddy     : riteshreddy99",
                          style: TextStyle(fontWeight: FontWeight.w300, fontSize: 18.0),),
                      ),
                    ),
                    SizedBox(height: 5,),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        child: Text("Pranav Chachara     : PC-02",
                          style: TextStyle(fontWeight: FontWeight.w300, fontSize: 18.0),),
                      ),
                    ),
                    SizedBox(height: 5,),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        child: Text("Brenden Cyrus Monteiro     : brendenmonteiro",
                          style: TextStyle(fontWeight: FontWeight.w300, fontSize: 18.0),),
                      ),
                    ),
                    SizedBox(height: 5,),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        child: Text("Marwan Solanki     : marwansolanki",
                          style: TextStyle(fontWeight: FontWeight.w300, fontSize: 18.0),),
                      ),
                    ),
                    SizedBox(height: 5,),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        child: Text("Harshal Thachapully     : Harshal12355",
                          style: TextStyle(fontWeight: FontWeight.w300, fontSize: 18.0),),
                      ),
                    ),
                    SizedBox(height: 5,),

                  ],



                ),

              ),
            ),
          )
        ],
      ),
    );
  }

}