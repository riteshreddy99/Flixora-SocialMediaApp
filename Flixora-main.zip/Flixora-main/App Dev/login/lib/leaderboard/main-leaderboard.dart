import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:line_icons/line_icons.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:login/profile/main-profileOther.dart';
import 'package:login/homePage.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:login/widgets/top-nav-bar.dart';
import 'package:login/widgets/drawer.dart';

class MainLeaderboard extends StatefulWidget {
  @override
  _MainLeaderboardState createState() => _MainLeaderboardState();
}

class _MainLeaderboardState extends State<MainLeaderboard> {
  Widget _buildTopThree(List<QueryDocumentSnapshot> users, Size screenSize) {
    return Container(
      height: (MediaQuery.of(context).size.height * 0.3),
      decoration: BoxDecoration(
          color: Colors.grey[900],
          borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(10),
              bottomRight: Radius.circular(10))),
      child: Container(
        child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
          _buildProfilePoints(45.0, users[1], screenSize, Colors.grey),
          _buildCenterProfilePoints(
              0.0, users[0], screenSize, Colors.amberAccent),
          _buildProfilePoints(45.0, users[2], screenSize, Colors.orange[700]),
        ]),
        // padding: EdgeInsets.symmetric(horizontal: 40),
      ),
    );
  }

  Widget _buildProfilePoints(
      height, QueryDocumentSnapshot users, Size screenSize, Color colour) {
    return Padding(
      padding: const EdgeInsets.only(top: 40, bottom: 10),
      child: Card(
        elevation: 20,
        // shape: RoundedRectangleBorder(
        //   borderRadius: BorderRadius.circular(20.0),
        //),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Icon(
                LineIcons.crown,
                color: colour,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(right: 40, left: 40),
              child: CircleAvatar(
                backgroundImage: NetworkImage(users.get("photoUrl")),
              ),
            ),
            GestureDetector(
              child: Text(
                users.get("username"),
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
              ),
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) =>
                            UserProfilePage(userid: users.id)));
              },
            ),
            FlatButton(
              child: Text(
                users.get("points").toString(),
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: Colors.yellow[700]),
              ),
              onPressed: () {},
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                  side: BorderSide(color: Colors.yellow[700])),
            ),
          ],
        ),
      ),
    );

    // return Container(
    //   //padding: EdgeInsets.only(left: screenSize.width / 50),
    //   child: Padding(
    //     padding: const EdgeInsets.all(8.0),
    //     child: Card(
    //       elevation: 10,
    //       child: Column(
    //         children: [
    //           //new SizedBox(height: height),
    //           Padding(
    //             padding: const EdgeInsets.only(top: 10, bottom: 5),
    //             child: Icon(
    //               LineIcons.crown,
    //               color: colour,
    //             ),
    //           ),
    //           CircleAvatar(
    //             backgroundImage: NetworkImage(users.get("photoUrl")),
    //           ),
    //           GestureDetector(
    //             child: Padding(
    //               padding: const EdgeInsets.only(top: 10),
    //               child: Text(
    //                 users.get("username"),
    //                 style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
    //               ),
    //             ),
    //             onTap: () {
    //               Navigator.push(
    //                   context,
    //                   MaterialPageRoute(
    //                       builder: (context) => UserProfilePage(userid: users.id)));
    //             },
    //           ),
    //           new SizedBox(height: 10),
    //           FlatButton(
    //             child: Text(
    //               users.get("points").toString(),
    //               style: TextStyle(
    //                   fontSize: 18,
    //                   fontWeight: FontWeight.w900,
    //                   color: Colors.yellow[700]),
    //             ),
    //             onPressed: () {},
    //             shape: RoundedRectangleBorder(
    //                 borderRadius: BorderRadius.circular(10.0),
    //                 side: BorderSide(color: Colors.yellow[700])),
    //           ),
    //         ],
    //       ),
    //     ),
    //   ),
    // );
  }

  Widget _buildCenterProfilePoints(
      height, QueryDocumentSnapshot users, Size screenSize, Color colour) {
    return Padding(
      padding: const EdgeInsets.only(top: 10, bottom: 40),
      child: Card(
        elevation: 20,
        // shape: RoundedRectangleBorder(
        //   borderRadius: BorderRadius.circular(20.0),
        //),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Icon(
                LineIcons.crown,
                color: colour,
              ),
            ),
            Padding(
              padding: const EdgeInsets.only(right: 40, left: 40),
              child: CircleAvatar(
                backgroundImage: NetworkImage(users.get("photoUrl")),
              ),
            ),
            GestureDetector(
              child: Text(
                users.get("username"),
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
              ),
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) =>
                            UserProfilePage(userid: users.id)));
              },
            ),
            FlatButton(
              child: Text(
                users.get("points").toString(),
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                    color: Colors.yellow[700]),
              ),
              onPressed: () {},
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                  side: BorderSide(color: Colors.yellow[700])),
            ),
          ],
        ),
      ),
    );
  }

  Widget _makeLeaderboard(
      QueryDocumentSnapshot user, screenSize, int position) {
    return Container(
        width: screenSize.width,
        padding: EdgeInsets.all(10),
        child: ListTile(
          onTap: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => UserProfilePage(userid: user.id)));
          },
          leading: CircleAvatar(
            backgroundImage: NetworkImage(user.get("photoUrl")),
          ),
          title: Text(user.get("username")),
          subtitle: Row(
            children: [
              Text(
                position.toString(),
                style: TextStyle(fontSize: 20, color: Colors.yellow[600]),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Text(
                  "th",
                  style: TextStyle(fontSize: 14, color: Colors.yellow[600]),
                ),
              ),
            ],
          ),
          trailing: Padding(
            padding: const EdgeInsets.only(right: 20),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                    top: 8,
                  ),
                  child: Text("Score:"),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Text(
                    user.get("points").toString(),
                    style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.w900,
                        color: Colors.yellow[700]),
                  ),
                ),
              ],
            ),
          ),
        ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: buildTopNavBar(context),
        drawer: buildDrawer(context),
        body: FutureBuilder(
          future: userRef.limit(10).orderBy("points", descending: true).get(),
          builder:
              (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
            List<Widget> widgetData;
            Size screenSize = MediaQuery.of(context).size;

            if (snapshot.hasData) {
              List<QueryDocumentSnapshot> snapshotData = snapshot.data.docs;
              widgetData = <Widget>[
                _buildTopThree(snapshotData, screenSize),
              ];
              snapshotData.removeRange(0, 3);
              for (int i = 0; i < snapshotData.length; i++) {
                widgetData
                    .add(_makeLeaderboard(snapshotData[i], screenSize, i + 4));
              }
            } else if (snapshot.hasError) {
            } else {
              widgetData = const <Widget>[
                SizedBox(
                  child: CircularProgressIndicator(),
                  width: 60,
                  height: 60,
                ),
              ];
            }

            return SafeArea(
              child: SingleChildScrollView(
                child: Column(
                  children: widgetData,
                ),
              ),
            );
          },
        ));
  }
}
