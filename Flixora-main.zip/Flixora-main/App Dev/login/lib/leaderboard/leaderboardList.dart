import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

Widget leaderboardList(screenSize) {
  TextStyle defaultDarkStyle =
      TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.w900);
  return Column(children: <Widget>[
    Container(
      //green up arrow

      height: 75,
      child: Row(
        children: <Widget>[
          IconButton(
            icon: Icon(
              Icons.arrow_drop_up_sharp,
              color: Colors.green,
              size: 35,
            ),
          ),
          Text("4", style: defaultDarkStyle),
          SizedBox(
            width: 16,
          ),
          CircleAvatar(
            backgroundImage: AssetImage('Image/profilepic.png'),
            maxRadius: 20,
          ),
          SizedBox(
            width: 12,
          ),
          Container(
            width: 165,
            //       color: Colors.yellow,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                SizedBox(
                  height: 27,
                ),
                Text(
                  "Leslie John",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                ),
                // SizedBox(height: 6,),
                //  Text("Frontend developer",style: TextStyle(fontSize: 13,color: Colors.grey.shade600, ),),
              ],
            ),
          ),

          //SizedBox(height: 27,),
          Container(
            width: 7,
          ),
          Container(
            //    color: Colors.deepPurpleAccent,
            // margin: EdgeInsets.only(left: screenSize.width/5),
            width: 80,
            height: 40,
            child: Center(
                child: Text(
              "2465",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
            )),
            decoration: BoxDecoration(
                color: Colors.black12,
                borderRadius: BorderRadius.all(Radius.circular(100))),
          ),

          // SizedBox(height: 6,),
          //  Text("Frontend developer",style: TextStyle(fontSize: 13,color: Colors.grey.shade600, ),),
        ],
      ),
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(color: Colors.black12),
          bottom: BorderSide(color: Colors.black12),
        ),
      ),
    ),
    Container(
      //red down arrow

      height: 75,
      child: Row(
        children: <Widget>[
          IconButton(
            icon: Icon(
              Icons.arrow_drop_down_sharp,
              color: Colors.red,
              size: 35,
            ),
          ),
          Text("5", style: defaultDarkStyle),
          SizedBox(
            width: 16,
          ),
          CircleAvatar(
            backgroundImage: AssetImage('Image/profilepic.png'),
            maxRadius: 20,
          ),
          SizedBox(
            width: 12,
          ),
          Container(
            width: 165,
            //       color: Colors.yellow,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                SizedBox(
                  height: 27,
                ),
                Text(
                  "Leslie John",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                ),
                // SizedBox(height: 6,),
                //  Text("Frontend developer",style: TextStyle(fontSize: 13,color: Colors.grey.shade600, ),),
              ],
            ),
          ),

          //SizedBox(height: 27,),
          Container(
            width: 7,
          ),
          Container(
            //    color: Colors.deepPurpleAccent,
            // margin: EdgeInsets.only(left: screenSize.width/5),
            width: 80,
            height: 40,
            child: Center(
                child: Text(
              "2465",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
            )),
            decoration: BoxDecoration(
                color: Colors.black12,
                borderRadius: BorderRadius.all(Radius.circular(100))),
          ),

          // SizedBox(height: 6,),
          //  Text("Frontend developer",style: TextStyle(fontSize: 13,color: Colors.grey.shade600, ),),
        ],
      ),
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(color: Colors.black12),
          bottom: BorderSide(color: Colors.black12),
        ),
      ),
    ),
    Container(
      //yellow

      height: 75,
      child: Row(
        children: <Widget>[
          IconButton(
            icon: Icon(
              Icons.horizontal_rule_rounded,
              color: Colors.amber,
              size: 25,
            ),
          ),
          Text("6", style: defaultDarkStyle),
          SizedBox(
            width: 16,
          ),
          CircleAvatar(
            backgroundImage: AssetImage('Image/profilepic.png'),
            maxRadius: 20,
          ),
          SizedBox(
            width: 12,
          ),
          Container(
            width: 165,
            //       color: Colors.yellow,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                SizedBox(
                  height: 27,
                ),
                Text(
                  "Leslie John",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                ),
                // SizedBox(height: 6,),
                //  Text("Frontend developer",style: TextStyle(fontSize: 13,color: Colors.grey.shade600, ),),
              ],
            ),
          ),

          //SizedBox(height: 27,),
          Container(
            width: 7,
          ),
          Container(
            //    color: Colors.deepPurpleAccent,
            // margin: EdgeInsets.only(left: screenSize.width/5),
            width: 80,
            height: 40,
            child: Center(
                child: Text(
              "2465",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900),
            )),
            decoration: BoxDecoration(
                color: Colors.black12,
                borderRadius: BorderRadius.all(Radius.circular(100))),
          ),

          // SizedBox(height: 6,),
          //  Text("Frontend developer",style: TextStyle(fontSize: 13,color: Colors.grey.shade600, ),),
        ],
      ),
      decoration: BoxDecoration(
        border: Border(
          top: BorderSide(color: Colors.black12),
          bottom: BorderSide(color: Colors.black12),
        ),
      ),
    ),
  ]);
}
