import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_svg/svg.dart';
import 'package:line_icons/line_icons.dart';
import 'package:login/widgets/BottomNavBar.dart';
import 'package:uuid/uuid.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:login/profile/main-profileOther.dart';

/*
class MainLeaderboard extends StatefulWidget {
  MainLeaderboard({Key key}) : super(key: key);

  MainLeaderboardState createState() => MainLeaderboardState();
}

class MainLeaderboardState extends State<MainLeaderboard> {
  void initState() {
    super.initState();
  }

  final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
  final FirebaseAuth fbAuth = FirebaseAuth.instance;

  int numOfusers = 0;
  int position = 3;

  List<String> userIDs = new List<String>();
  List<String> usernames = new List<String>();
  List<int> points = new List<int>();

  Future<List<String>> _getUsers() async {
    numOfusers = 0;
    position = 3;
    userIDs.clear();
    points.clear();
    usernames.clear();
    CollectionReference usersRef = fbFirestore.collection("users");

    Query orderedUsers;

    await usersRef.get().then((snapshot) => snapshot.docs.forEach((u) {
          orderedUsers = usersRef.orderBy("points", descending: true);
        }));

    await orderedUsers.get().then((snapshot) => snapshot.docs.forEach((u) {
          // Query orderedUsers = postsRef.orderBy("likes".length);
          userIDs.add(u.id);
          usernames.add(u.get("username"));
          points.add(u.get("points"));
          numOfusers++;
        }));
    return userIDs;
  }

  Widget _buildLeaderboardTile(screenSize) {
    return Container(
      // height: screenSize.height,
      child: Row(
        children: <Widget>[
          FutureBuilder(
            future: _makeLeaderboardList(screenSize),
            builder: (context, AsyncSnapshot<List<Widget>> snapshot) {
              if (snapshot.connectionState == ConnectionState.done) {
                return Column(children: snapshot.data);
              } else if (snapshot.connectionState == ConnectionState.none) {
                return Text("No data");
              }
              return Container(
                height: MediaQuery.of(context).size.height - 100,
                width: MediaQuery.of(context).size.width,
                child: SpinKitFadingCube(
                  color: Colors.yellow[600],
                  size: 60,
                ),
              );
            },
          ),

          // SizedBox(height: 6,),
          //  Text("Frontend developer",style: TextStyle(fontSize: 13,color: Colors.grey.shade600, ),),
        ],
      ),
    );
  }

  Future<DocumentSnapshot> _getProfileDetails(userid) {
    return fbFirestore.doc("users/" + userid).get();
  }

  Widget buildProfilePic(userid) {
    return FutureBuilder(
        future: _getProfileDetails(userid),
        builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return CircleAvatar(
              // margin: EdgeInsets.all(5),
              // width: 40,
              // height: 40.0,
              backgroundImage: NetworkImage(snapshot.data.get("photoUrl")),
              // decoration: BoxDecoration(
              //   image: DecorationImage(
              //     image: NetworkImage(snapshot.data.get("photoUrl")),
              //     fit: BoxFit.cover,
              //   ),
              //   borderRadius: BorderRadius.circular(80.0),
              //   border: Border.all(
              //     color: Colors.grey[800],
              //     width: 1.0,
              //   ),
              // ),
            );
          } else if (snapshot.connectionState == ConnectionState.none) {
            print("No data");
          }
          return SpinKitPulse(
            size: 30,
            color: Colors.grey,
          );
        });
  }

  Widget _buildProfilePoints(
      height, userid, username, score, Size screenSize, Color colour) {
    TextStyle defaultDarkStyle = TextStyle(color: Colors.white, fontSize: 20.0);

    return Container(
      //color: Colors.pink,
      // alignment: Alignment.center,
      padding: EdgeInsets.only(left: screenSize.width / 50),
      child: Column(
        //crossAxisAlignment: CrossAxisAlignment.,
        children: [
          new SizedBox(height: height),
          Padding(
            padding: const EdgeInsets.only(top: 10, bottom: 5),
            child: Icon(
              LineIcons.crown,
              color: colour,
            ),
          ),
          buildProfilePic(userid),
          GestureDetector(
            child: Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Text(
                username,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
              ),
            ),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => UserProfilePage(userid: userid)));
            },
          ),
          new SizedBox(height: 10),
          FlatButton(
            child: Text(
              score.toString(),
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  color: Colors.yellow[700]),
            ),
            // color: Colors.yellow[700],
            onPressed: () {},
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
                side: BorderSide(color: Colors.yellow[700])),
          ),

          // new Divider(
          //     color: Colors.white
          // )
        ],
      ),
    );
  }

  Widget _buildTopThree(userid1, userid2, userid3, user1, user2, user3, points1,
      points2, points3, Size screenSize) {
    return Container(
      child: Row(children: <Widget>[
        _buildProfilePoints(
            45.0, userid2, user2, points2, screenSize, Colors.grey),

        //SizedBox(width: 5,),
        _buildProfilePoints(
            0.0, userid1, user1, points1, screenSize, Colors.amberAccent),
        //SizedBox(width: 5,),
        _buildProfilePoints(
            45.0, userid3, user3, points3, screenSize, Colors.orange[700]),
      ]),
      padding: EdgeInsets.symmetric(horizontal: 40),

      height: (MediaQuery.of(context).size.height * 0.3),
      decoration: BoxDecoration(
          color: Colors.grey[700],
          borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(36),
              bottomRight: Radius.circular(36))),
    );

    // return Container(
    //     padding: EdgeInsets.only(
    //         left: screenSize.width / 57, top: screenSize.height / 700),
    //     child: Row(children: <Widget>[
    //       _buildProfilePoints(
    //           45.0, userid2, user2, points2, screenSize, Colors.grey),
    //       _buildProfilePoints(
    //           0.0, userid1, user1, points1, screenSize, Colors.amberAccent),
    //       _buildProfilePoints(
    //           45.0, userid3, user3, points3, screenSize, Colors.orange[700]),
    //     ]));
  }


  Widget _makeLeaderboard(userid, username, score, screenSize, int position) {

    // String username;

    // Future<DocumentSnapshot> getUsername() async {
    //   // String uid = fbAuth.currentUser.uid;
    //   DocumentReference userRef = fbFirestore.collection("users").doc(userid);
    //   return userRef;
    // }

    return Container(
        width: screenSize.width,
        padding: EdgeInsets.all(10),
        child: ListTile(
          onTap: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => UserProfilePage(userid: userid)));
          },
          leading: buildProfilePic(userid),
          title: Text(username),
          subtitle: Text(
            position.toString(),

            style: TextStyle(fontSize: 20, color: Colors.yellow[600]),

          ),
          trailing: Padding(
            padding: const EdgeInsets.only(right: 20),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                    top: 8,
                  ),
                  child: Text("Score:"),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Text(
                    score.toString(),
                    style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.w900,
                        color: Colors.yellow[700]),
                  ),
                ),
              ],
            ),
          ),
        ));

    // return Container(
    //   child: Column(
    //     crossAxisAlignment: CrossAxisAlignment.start,
    //     children: <Widget>[
    //       // SizedBox(height: 20, width: 12,),
    //
    //       Row(
    //         children: <Widget>[
    //           Text(
    //             position.toString(),
    //             style: TextStyle(
    //                 fontSize: 18, fontWeight: FontWeight.w900),
    //           ),
    //           Card(
    //             child: Container(
    //               child: Row(children: <Widget>[
    //                 SizedBox(height: 30, width: 10),
    //                 // incPosition(),
    //
    //                 SizedBox(height: 20, width: 20),
    //                 buildProfilePic(userid),
    //                 SizedBox(height: 20, width: 12),
    //
    //                 GestureDetector(
    //                   child: Text(
    //                     username,
    //                     style: TextStyle(
    //                         fontSize: 18,
    //                         fontWeight: FontWeight.w900),
    //                   ),
    //                   onTap: () {
    //                     Navigator.push(
    //                         context,
    //                         MaterialPageRoute(
    //                             builder: (context) =>
    //                                 UserProfilePage(userid: userid)));
    //                   },
    //                 ),
    //                 //Expanded(child: SizedBox()),
    //                 // Text(
    //                 //   "",
    //                 //   style: TextStyle(
    //                 //       fontSize: 40, fontWeight: FontWeight.w900),
    //                 // ),
    //                 //Expanded(child:SizedBox()),
    //                 // RaisedButton(
    //                 //   child: Text("View",style: TextStyle(color: Colors.white),),
    //                 //   color: Colors.black,
    //                 //   onPressed: () {
    //                 //     // Navigator.push(context, MaterialPageRoute(builder: (context) => ViewChallenge(name: challengeName,id: challengeid, desc: challengedesc, deadline: challengedeadline,)),);
    //                 //   },
    //                 //
    //                 //
    //                 // ),
    //                 Padding(
    //                   padding: const EdgeInsets.only(right: 40),
    //                   child: FlatButton(
    //                     child: Text(
    //                       score.toString(),
    //                       style: TextStyle(
    //                           fontSize: 18,
    //                           fontWeight: FontWeight.w900,
    //                           color: Colors.yellow[700]),
    //                     ),
    //                     onPressed: () {},
    //                   ),
    //                 ),
    //                 Divider(
    //                   color: Colors.grey,
    //                 )
    //               ]),
    //             ),
    //           )
    //         ],
    //       ),
    //     ],
    //   ),
    // );
  }

  Future<List<Widget>> _makeLeaderboardList(screenSize) async {
    // print("makeleaderboardlist");
    List<String> users = await _getUsers();

    List<Widget> widgetleaderboard = [];

    widgetleaderboard.add(_buildTopThree(
        userIDs.removeAt(0),
        userIDs.removeAt(0),
        userIDs.removeAt(0),
        usernames.removeAt(0),
        usernames.removeAt(0),
        usernames.removeAt(0),
        points.removeAt(0),
        points.removeAt(0),
        points.removeAt(0),
        screenSize));

    for (int i = 0; i < numOfusers - 3; i++) {

      position++;
      widgetleaderboard.add(_makeLeaderboard(userIDs[i],
          usernames[i], points[i], screenSize, position));

    }

    return widgetleaderboard;
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      // resizeToAvoidBottomInset: false,
      // appBar: AppBar(
      //   leading: (IconButton(
      //     icon: Icon(
      //       Icons.arrow_back,
      //       color: Colors.white,
      //     ),
      //     onPressed: () {
      //       Navigator.pop(context);
      //     },
      //   )),
      //   title: Text(
      //     "Global Leaderboard",
      //     style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),
      //   ),
      //   toolbarHeight: 65,
      //   backgroundColor: Colors.black87,
      //   actions: <Widget>[],
      // ),
      body: Stack(
        children: <Widget>[
          SafeArea(
            child: SingleChildScrollView(
              child:
                  // SizedBox(height: 15,),
                  _buildLeaderboardTile(screenSize),
            ),
          )
        ],
      ),
    );
  }
}

NEW CODE


import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:line_icons/line_icons.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:login/profile/main-profileOther.dart';
import 'package:login/homePage.dart';

class MainLeaderboard extends StatefulWidget {
  MainLeaderboard({Key key}) : super(key: key);

  MainLeaderboardState createState() => MainLeaderboardState();
}

class MainLeaderboardState extends State<MainLeaderboard> {
  void initState() {
    super.initState();
  }

  List<QueryDocumentSnapshot> userPointList = [];
  List<Widget> widgetleaderboard = [];

  Future<List<dynamic>> _getUsers() async {
    Query orderedUsers;
    userPointList.clear();

    await userRef.limit(10).get().then((snapshot) => snapshot.docs.forEach((u) {
      orderedUsers = userRef.orderBy("points", descending: true);
    }));

    await orderedUsers.limit(10).get().then((snapshot) => snapshot.docs.forEach((u) {
      // Query orderedUsers = postsRef.orderBy("likes".length);
      userPointList.add(u);
    }));
    return userPointList;
  }

  Widget _buildLeaderboardTile(screenSize) {
    return Container(
      // height: screenSize.height,
      child: Row(
        children: <Widget>[
          FutureBuilder(
            future: _makeLeaderboardList(screenSize),
            builder: (context, AsyncSnapshot<List<Widget>> snapshot) {
              if (snapshot.connectionState == ConnectionState.done) {
                return Column(children: snapshot.data);
              } else if (snapshot.connectionState == ConnectionState.none) {
                return Text("No data");
              }
              return Container(
                height: MediaQuery.of(context).size.height - 100,
                width: MediaQuery.of(context).size.width,
                child: SpinKitFadingCube(
                  color: Colors.yellow[600],
                  size: 60,
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Future<DocumentSnapshot> _getProfileDetails(userid) {
    return fbFirestore.doc("users/" + userid).get();
  }

  Widget buildProfilePic(userid) {
    return FutureBuilder(
        future: _getProfileDetails(userid),
        builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return CircleAvatar(
              backgroundImage: NetworkImage(snapshot.data.get("photoUrl")),
            );
          } else if (snapshot.connectionState == ConnectionState.none) {
            print("No data");
          }
          return SpinKitPulse(
            size: 30,
            color: Colors.grey,
          );
        });
  }

  Widget _buildProfilePoints(height, QueryDocumentSnapshot users, Size screenSize, Color colour) {
    return Container(
      //color: Colors.pink,
      // alignment: Alignment.center,
      padding: EdgeInsets.only(left: screenSize.width / 50),
      child: Column(
        //crossAxisAlignment: CrossAxisAlignment.,
        children: [
          new SizedBox(height: height),
          Padding(
            padding: const EdgeInsets.only(top: 10, bottom: 5),
            child: Icon(
              LineIcons.crown,
              color: colour,
            ),
          ),
          buildProfilePic(users.id),
          GestureDetector(
            child: Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Text(
                users.get("username"),
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
              ),
            ),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => UserProfilePage(userid: users.id)));
            },
          ),
          new SizedBox(height: 10),
          FlatButton(
            child: Text(
              users.get("points").toString(),
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  color: Colors.yellow[700]),
            ),
            onPressed: () {},
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
                side: BorderSide(color: Colors.yellow[700])),
          ),
        ],
      ),
    );
  }

  Widget _buildTopThree(List<QueryDocumentSnapshot> users, Size screenSize) {
    return Container(
      child: Row(children: <Widget>[
        _buildProfilePoints(45.0, users[1], screenSize, Colors.grey),
        _buildProfilePoints(0.0, users[0], screenSize, Colors.amberAccent),
        _buildProfilePoints(45.0, users[2], screenSize, Colors.orange[700]),
      ]),
      padding: EdgeInsets.symmetric(horizontal: 40),
      height: (MediaQuery.of(context).size.height * 0.3),
      decoration: BoxDecoration(
          color: Colors.grey[700],
          borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(36),
              bottomRight: Radius.circular(36))),
    );
  }

  Widget _makeLeaderboard(QueryDocumentSnapshot user, screenSize, int position) {
    return Container(
        width: screenSize.width,
        padding: EdgeInsets.all(10),
        child: ListTile(
          onTap: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => UserProfilePage(userid: user.id)));
          },
          leading: buildProfilePic(user.id),
          title: Text(user.get("username")),
          subtitle: Text(
            position.toString(),
            style: TextStyle(fontSize: 20, color: Colors.yellow[600]),
          ),
          trailing: Padding(
            padding: const EdgeInsets.only(right: 20),
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                    top: 8,
                  ),
                  child: Text("Score:"),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 2),
                  child: Text(
                    user.get("points").toString(),
                    style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.w900,
                        color: Colors.yellow[700]),
                  ),
                ),
              ],
            ),
          ),
        ));
  }

  Future<List<Widget>> _makeLeaderboardList(screenSize) async {
    await _getUsers();
    List<QueryDocumentSnapshot> topThree = userPointList.sublist(0,3);
    userPointList.removeRange(0, 3);

    widgetleaderboard.add(_buildTopThree(topThree, screenSize));

    for (int i = 0; i < userPointList.length; i++) {
      widgetleaderboard.add(_makeLeaderboard(
          userPointList[i], screenSize, i+4));
    }

    return widgetleaderboard;
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      body: Stack(
        children: <Widget>[
          SafeArea(
            child: SingleChildScrollView(
              child: _buildLeaderboardTile(screenSize),
            ),
          )
        ],
      ),
    );
  }
}


 */