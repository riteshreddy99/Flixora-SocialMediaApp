import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:line_icons/line_icons.dart';
import 'package:login/likes.dart';
import 'package:login/uploadPage.dart';
import 'package:login/widgets/top-nav-bar.dart';
import 'package:login/widgets/drawer.dart';
import 'package:login/data/post.dart';
import 'package:like_button/like_button.dart';
import 'package:login/profile/main-profileOther.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'dart:async';
import 'package:login/widgets/commentsPage.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'search.dart';
import 'package:login/helper/notifications.dart';

final storageRef = FirebaseStorage.instance.ref();
final userRef = FirebaseFirestore.instance.collection("users");
final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
final FirebaseAuth fbAuth = FirebaseAuth.instance;
final User currentUser = FirebaseAuth.instance.currentUser;

class HPage extends StatefulWidget {
  @override
  _HPageState createState() => _HPageState();
}

class _HPageState extends State<HPage> {
  String username;
  String photoUrl;

  @override
  Widget build(BuildContext context) {
    if (Platform.isAndroid) registerNotification();

    return Scaffold(
      appBar: buildTopNavBar(context),
      drawer: buildDrawer(context),
      body: feedBody(),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.yellow[600],
        child: Icon(LineIcons.plus),
        onPressed: () {
          var route = new MaterialPageRoute(
              builder: (BuildContext context) => new UploadPage());
          Navigator.of(context).push(route);
        },
      ),
    );
  }

  _getChannelPosts(List<Post> userPosts, String cid) async {
    DocumentReference channelRef = fbFirestore.doc("channels/" + cid);

    List<dynamic> posts;

    await channelRef.get().then((snapshot) {
      posts = snapshot.get("posts");
    });

    for (String post in posts) {
      print(post);
      String userID = post.toString().split("/")[2];
      String postID = post.toString().split("/")[4];
      String username;
      String profilepiclink;

      if (userID == fbAuth.currentUser.uid) // post by current user
        continue;

      for (Post p in userPosts) {
        // duplicate post
        if (p.postid == postID) continue;
      }

      DocumentReference userRef = fbFirestore.collection("users").doc(userID);

      await userRef.get().then((userData) {
        username = userData.get("username");
        profilepiclink = userData.get("photoUrl");
      });

      DocumentReference postRef = fbFirestore.doc(post);
      await postRef.get().then((snapshot) {
        // get posts

        bool likedBefore = false;

        for (int i = 0; i < snapshot.get("likes").length; i++) {
          if (fbAuth.currentUser.uid == snapshot.get("likes")[i])
            likedBefore = true;
        }

        profilepics.add(profilepiclink);
        postlocations.add(snapshot.get("location"));
        
        userPosts.add(new Post(
            username,
            userID,
            snapshot.get("postId"),
            snapshot.get("image-desc"),
            snapshot.get("image-link"),
            snapshot.get("likes").length,
            likedBefore,
            false));
        numOfPosts++;
      });
    }

    return;
  }

  List<String> profilepics = new List<String>();
  List<String> postlocations = new List<String>();
  int numOfPosts = 0;
  // This function takes an input of List of AuthIDs(users) and returns all the posts made by those users in a list
  Future<List<Post>> getUserPosts(List<String> following) async {
    List<Post> userPosts = new List<Post>();
    profilepics.clear();
    postlocations.clear();
    numOfPosts = 0;

    for (int i = 0; i < following.length; i++) {
      DocumentReference userRef = fbFirestore.doc("users/" + following[i]);

      if (following[i].toString().length != 28) {
        print(following[i].toString());
        await _getChannelPosts(userPosts, following[i]);
      }
      else {
        CollectionReference postRef =
        fbFirestore.collection("users/" + following[i] + "/posts");
        String username;
        String profilepiclink;

        await userRef.get().then((userData) {
          photoUrl =
              userData.get("photoUrl"); // use this to store photo of postee
          username = userData.get("username");
          profilepiclink = userData.get("photoUrl");
        });

        await postRef.get().then((snapshot) {
          // get posts
          for (int j = 0; j < snapshot.docs.length; j++) {
            bool likedBefore = false;

            for (Post p in userPosts) {
              // avoid duplicate posts
              if (p.postid == snapshot.docs[j].get("postId")) continue;
            }

            for (int k = 0; k < snapshot.docs[j]
                .get("likes")
                .length; k++) {
              if (fbAuth.currentUser.uid == snapshot.docs[j].get("likes")[k])
                likedBefore = true;
            }

            profilepics.add(profilepiclink);
            postlocations.add(snapshot.docs[j].get("location"));

            userPosts.add(new Post(
                username,
                following[i],
                snapshot.docs[j].get("postId"),
                snapshot.docs[j].get("image-desc"),
                snapshot.docs[j].get("image-link"),
                snapshot.docs[j]
                    .get("likes")
                    .length,
                likedBefore,
                false));
            numOfPosts++;
          }
        });
      }
    }
    print("num of posts = " + numOfPosts.toString());
    return userPosts;
  }

  // This function gets all the users the current user is following
  Future<List<String>> getFollowing() async {
    String uid = fbAuth.currentUser.uid;

    DocumentReference userRef = fbFirestore.doc("users/" + uid);
    List<String> following = new List<String>();

    await userRef.get().then((snapshot) {
      int numOfFollowing = snapshot.get("following").length;
      username = snapshot.get("username");

      for (int i = 0; i < numOfFollowing; i++) {
        following.add(snapshot.get("following")[i]);
      }
    });
    return following;
  }

  Future<List<Widget>> getPosts() async {
    // Stores our posts in an array
    List<Widget> widgetPosts = [];

    List<String> following =
        await getFollowing(); // get all the users that current user is following

    List<Post> allPosts = await getUserPosts(
        following); // get all the posts of users being followed by current user

    // for (Post p in allPosts) {
    //   widgetPosts.add(getPost(p)); // formatting magic
    // }
    print(numOfPosts);
    for (int i = 0; i < numOfPosts; i++) {
      widgetPosts.add(getPost(allPosts[i], profilepics[i], postlocations[i]));
      print(i);
    }
    print(widgetPosts);
    return widgetPosts;
  }

  Future<bool> _likePost(Post post) async {
    DocumentReference postRef = fbFirestore
        .collection("users")
        .doc(post.userid)
        .collection("posts")
        .doc(post.postid);

    DocumentReference posterRef = fbFirestore
        .collection("users")
        .doc(post.userid)
        .collection("notifications")
        .doc();

    Map<String, dynamic> notifData = {
      "message": "liked your post!",
      "time-sent": DateTime.now(),
      "type": "like",
      "userID": fbAuth.currentUser.uid,
      "username": username,
      "refPID": post.postid,
      "refUID": fbAuth.currentUser.uid,
    };

    posterRef.set(notifData);

    await postRef.get().then((snapshot) {
      List<dynamic> likes = snapshot.get("likes");
      String currentUID = fbAuth.currentUser.uid;

      if (post.isLiked) {
        likes.remove(currentUID);
        postRef.update({"likes": likes});

        post.isLiked = false;
        return post.isLiked;
      }

      likes.add(currentUID);
      postRef.update({"likes": likes});
      post.isLiked = true;
    });

    sendNotif(post.userid, "liked your post!");

    return post.isLiked;
  }

  Widget feedBody() {
    // generate the feed of a user
    return Container(
      // color: Theme.of(context).accentColor,
      child: FutureBuilder(
          future: getPosts(),
          builder: (context, AsyncSnapshot<List<Widget>> snapshot) {
            if (snapshot.connectionState == ConnectionState.done) {
              print("inside feed body");
              return ListView(
                children: <Widget>[
                  snapshot.data == null
                      ? Center(child: Text("Start following users today!"))
                      : Column(children: snapshot.data),
                ],
              );
            } else if (snapshot.connectionState == ConnectionState.none) {
              return Text("No data");
            }
            return SpinKitFadingCube(
              color: Colors.yellow[600],
              size: 60.0,
            );
          }),
    );
  }

  Widget getPost(Post post, String profilepic, String location) {
    // Function to create the post widgets

    return Padding(
      padding: const EdgeInsets.only(top: 25, left: 20, right: 20),
      child: Card(
        elevation: 20,
        color: Colors.grey[900],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0),
        ),
        child: Column(
          children: [
            GestureDetector(
              onTap: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) =>
                            UserProfilePage(userid: post.userid)));
              },
              child: ListTile(
                // leading: buildProfilePic(post.userid),
                leading: CircleAvatar(
                  backgroundImage: NetworkImage(profilepic),
                ),
                title: Text(post.user),
                subtitle: Text(location),
                trailing: Icon(Icons.more_vert),
              ),
            ),
            Container(
              child: Image.network(post.pictureLink),
            ),
            Container(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  StreamBuilder(
                      stream: fbFirestore
                          .collection("users")
                          .doc(post.userid)
                          .collection("posts")
                          .doc(post.postid)
                          .snapshots(),
                      builder: (context, snapshot) {
                        if (!snapshot.hasData)
                          return Padding(
                            padding: EdgeInsets.fromLTRB(10, 10, 5, 0),
                            child: LikeButton(
                              size: 26,
                              isLiked: post.isLiked,
                            ),
                          );
                        else {
                          return Padding(
                            padding: EdgeInsets.fromLTRB(10, 10, 5, 0),
                            child: LikeButton(
                              size: 26,
                              animationDuration: Duration(milliseconds: 1000),
                              likeCountAnimationDuration:
                                  Duration(milliseconds: 300),
                              likeCount: snapshot.data["likes"].length,
                              isLiked: post.isLiked,
                              onTap: (x) => _likePost(post),
                            ),
                          );
                        }
                      }),
                  Padding(
                    padding: EdgeInsets.fromLTRB(10, 10, 5, 0),
                    child: LikeButton(
                      likeBuilder: (bool isCommented) {
                        return Icon(Icons.messenger_outline_rounded,
                            color: Colors.yellow[600]);
                      },
                      onTap: (x) {
                        return Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    PostCommentSection(post: post)));
                      },
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.fromLTRB(10, 10, 5, 0),
                    child: LikeButton(
                      size: 26,
                      likeBuilder: (bool isShared) {
                        return Icon(Icons.share_outlined,
                            color: Colors.yellow[600]);
                      },
                    ),
                  ),
                ],
              ),
            ),
            Column(
              children: [
                SizedBox(
                  height: 5,
                ),
                Padding(
                  padding: EdgeInsets.all(10),
                  child: Container(child: Text(post.description)),
                ),
                SizedBox(
                  height: 10,
                )
              ],
            ),
          ],
        ),
      ),
    );
  }
}
