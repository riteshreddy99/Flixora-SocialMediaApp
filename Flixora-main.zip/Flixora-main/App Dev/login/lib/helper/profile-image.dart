import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

import '../widgets/drawer.dart';

Future<DocumentSnapshot> _getProfileDetails(uid) {
  // String uid = fbAuth.currentUser.uid;
  return fbFirestore.doc("users/" + uid).get();
}

Widget buildProfilePic(uid) {
  return FutureBuilder(
      future: _getProfileDetails(uid),
      builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
        if (snapshot.connectionState == ConnectionState.done) {
          return CircleAvatar(
            backgroundImage: NetworkImage(
              snapshot.data.get("photoUrl"),
            ),
            radius: 40,
          );

          // return Container(
          //   margin: EdgeInsets.all(5),
          //   width: 80.0,
          //   height: 80.0,
          //   decoration: BoxDecoration(
          //     image: DecorationImage(
          //       image: NetworkImage(snapshot.data.get("photoUrl")),
          //       fit: BoxFit.cover,
          //     ),
          //     borderRadius: BorderRadius.circular(80.0),
          //     border: Border.all(
          //       color: Colors.grey[800],
          //       width: 1.0,
          //     ),
          //   ),
          // );
        } else if (snapshot.connectionState == ConnectionState.none) {
          print("No data");
        }
        return SpinKitPulse(
          size: 30,
          color: Colors.grey,
        );
      });
}
