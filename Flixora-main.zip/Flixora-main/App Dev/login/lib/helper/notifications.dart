import 'dart:io';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'dart:convert';
import 'package:http/http.dart';

final firebaseMessaging = FirebaseMessaging();
final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
final FirebaseAuth fbAuth = FirebaseAuth.instance;


final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
FlutterLocalNotificationsPlugin();

void showNotification(message) async {
  var androidPlatformChannelSpecifics = new AndroidNotificationDetails(
    'channel-test',
    'Flutter chat demo',
    'your channel description',
    playSound: true,
    enableVibration: true,
    importance: Importance.max,
    priority: Priority.high,
  );
  NotificationDetails platformChannelSpecifics =
      NotificationDetails(android: androidPlatformChannelSpecifics);

   await flutterLocalNotificationsPlugin.show(
      0, message['notification']['title'].toString(), message['notification']['body'].toString(), platformChannelSpecifics,
      payload: json.encode(message));
}

void genFCMToken() async{

  if(!Platform.isAndroid)
    return;

  CollectionReference tokens;
  String token;
  await firebaseMessaging.getToken().then((data) {

    tokens = FirebaseFirestore.instance
        .collection('devices')
        .doc(fbAuth.currentUser.uid)
        .collection("tokens");

    token = data;

  }).catchError((err) {
    print("error");
  });

  await tokens.get().then((snapshot) {
    // get posts
    for (int i = 0; i < snapshot.docs.length; i++) {
      if(snapshot.docs[i].get("push-token") == token){      // if token exists
        snapshot.docs[i].reference.update({"active":true});
        return;
      }
    }

    tokens.add({            // if new token
      "push-token" : token,
      "active" : true
    });

  });
}

void deactivateToken() async{
  CollectionReference tokens;
  String token;
  await firebaseMessaging.getToken().then((data) {

    tokens = FirebaseFirestore.instance
        .collection('devices')
        .doc(fbAuth.currentUser.uid)
        .collection("tokens");

    token = data;

  }).catchError((err) {
    print("error");
  });

  await tokens.get().then((snapshot) {
    // get posts
    for (int i = 0; i < snapshot.docs.length; i++) {
      if (snapshot.docs[i].get("push-token") == token) { // if token exists
        snapshot.docs[i].reference.update({"active": false});
        return;
      }
    }
  });
  return;
}

void sendNotif(uid,msg) async{

  if(!Platform.isAndroid)
    return;

  CollectionReference tokenRef =
  fbFirestore.collection("devices")
      .doc(uid)
      .collection("tokens");

  String token,username;

  await tokenRef.get().then((snapshot) {
    // get posts
    for (int i = 0; i < snapshot.docs.length; i++) {
      if (snapshot.docs[i].get("active") == true) { // if token exists
        token = snapshot.docs[i].get("push-token");
        break;
      }
    }
  });

  DocumentReference userRef =
  fbFirestore.collection("users")
  .doc(fbAuth.currentUser.uid);

  await userRef.get().then((snapshot){
    username = snapshot.get("username");
  });

  sendReq(username,msg,token);
}

void sendReq(user,message,token) async {

  await post('https://fcm.googleapis.com/fcm/send',
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'key=AAAA0qcqAPQ:APA91bHWX_zWNBO5z4f5TWMimiBg8UlEVAJi5kgo99IjDDstFo-uQ9UF1_oN3LYGEphUeoqPZNPRqI30SZtSk4Yg8rFmlLI0rfbkWC_ZSds6buEwtpVElgmBU-B6zVRBw7Q-SQChysvW'
      },
      body: jsonEncode({
        'notification': <String, dynamic>{
          'title': user,
          'body': message,
          'sound': 'true'
        },
//          'priority': 'high',
        'android':{
          'priority' : 'high'
        },
        'apns':{
          'headers':{
            'apns-priority': '5'
          }
        },
        'webpush': {
          'headers': {
            'Urgency': 'high'
          }
        },
        'data': <String, dynamic>{

          'click_action': 'FLUTTER_NOTIFICATION_CLICK',
          'id': '1',
          'status': 'done',
          // parameter to pass with the message
//            'promotionId': promotion.promotionId,
//            'imageUrl': promotion.imageUrl,
//            'isPromotion' : promotion.isPromotion,
//            'productName': promotion.productName,
//            'productCategory': promotion.category,
//            'vendor': promotion.vendor,
//            'price': promotion.price,
//            'description': promotion.productDescription
        },
        'to': token
      })).whenComplete(() {

  }).catchError((e) {
    print(':( error: $e');
  });
}




void registerNotification() {

  if(!Platform.isAndroid)
    return;

  var initializationSettingsAndroid =
  AndroidInitializationSettings('@mipmap/ic_launcher');

  var initializationSettings = InitializationSettings(android: initializationSettingsAndroid);
      firebaseMessaging.requestNotificationPermissions();

  flutterLocalNotificationsPlugin.initialize(initializationSettings);


  firebaseMessaging.configure(onMessage: (Map<String, dynamic> message) {
    print('onMessage: $message');
    showNotification(message);
   return;
  }, onResume: (Map<String, dynamic> message) {
    print('onResume: $message');
    return;
  }, onLaunch: (Map<String, dynamic> message) {
    print('onLaunch: $message');
    return;
  });

  genFCMToken();

}