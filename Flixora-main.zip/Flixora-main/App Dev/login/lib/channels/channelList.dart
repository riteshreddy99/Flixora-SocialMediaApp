import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:login/data/channel.dart';
import 'channelEdit.dart';


TextStyle defaultDarkStyle = TextStyle(color: Colors.white, fontSize: 18.0);
TextStyle hintStyle = TextStyle(color: Colors.white54, fontSize: 18.0);
Future<QuerySnapshot> searchResultsFuture;

class ChannelList extends StatefulWidget {
  static of(BuildContext context, {bool root = false}) => root
      ? context.findRootAncestorStateOfType<ChannelListState>()
      : context.findAncestorStateOfType<ChannelListState>();

  @override
  ChannelListState createState() => ChannelListState();
}


class ChannelListState extends State<ChannelList> {
  final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
  final FirebaseAuth fbAuth = FirebaseAuth.instance;

  Stream<QuerySnapshot> _getChannelData(){
    CollectionReference chanRef = fbFirestore.collection("channels");
    return chanRef.snapshots();
  }

  buildList() {
    return StreamBuilder(
      stream: _getChannelData(),
      builder: (context,  AsyncSnapshot<QuerySnapshot> snapshot) {

        if (!snapshot.hasData || snapshot.hasError) {
          return SpinKitRipple(
            color: Colors.grey,
          );
        }
        else {
          List<DocumentSnapshot> docs = snapshot.data.docs;

          if(docs.length == 0)
            return Text("No Channels");

          return SizedBox(
            height: 200,
            child: new ListView.builder(
              itemCount: docs.length,
              itemBuilder: (BuildContext ctxt, int index) {
                var docInstance = docs[index];
                Channel chan = Channel();

                chan.posts = docInstance.get("posts");
                chan.id = docInstance.get("channel-id");
                chan.subtitle = docInstance.get("subtitle");
                chan.title = docInstance.get("title");
                chan.tags = docInstance.get("tags");

                return Padding(
                    padding: EdgeInsets.all(10),
                    child:Container(
                      decoration: BoxDecoration(
                        // border: Border(bottom: BorderSide(),)
                      ),
                      child: new Card(
                        // shape: StadiumBorder(
                        //   // borderRadius: BorderRadius.circular(15),
                        //   side: BorderSide(
                        //     color: Colors.black,
                        //     width: 2.0
                        //   )
                        // ),
                        elevation: 20,

                        child: ListTile(

                            onTap: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          ChannelEdit(channel: chan)));
                            },

                            title: Text(chan.title)
                        ),
                      )
                  )
                );
              },
            ),
          );
        }

        return Text("data");
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        leading:(
            IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.pop(context);
              },
            )

        ),

        title: Text("Channel List",style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),),
        toolbarHeight: 65,
        //centerTitle: true,
        backgroundColor: Colors.black87,
        actions: <Widget>[
        ],
      ),
      body: Column(
        children: <Widget>[
          Expanded(
            child: buildList(),
          ),
        ],
      ),
      // body: buildAnimSearchBar(),
      // bottomNavigationBar: BottomNavBar(),
    );
  }
}
