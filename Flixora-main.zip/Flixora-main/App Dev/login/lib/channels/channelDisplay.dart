import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:login/data/channel.dart';
import 'channelGrid.dart';

void main() => runApp(ChanDisplay());

class ChanDisplay extends StatefulWidget {
  ChanDisplay({Key key, this.channel}) : super(key: key);

  final Channel channel;
  //Post post;

  @override
  ChanDisplayState createState() => ChanDisplayState();
}

class ChanDisplayState extends State<ChanDisplay> {

  final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
  final FirebaseAuth fbAuth = FirebaseAuth.instance;


  Widget _buildChannelName() {
    TextStyle _nameTextStyle = TextStyle(
      fontFamily: 'Roboto',
      color: Colors.amber[100],
      fontSize: 30.0,

    );

    return Text(widget.channel.title, style: _nameTextStyle);

  }


  Widget _buildSub(BuildContext context) {

    TextStyle subStyle = TextStyle(
        color: Colors.grey,
        fontSize: 18.0
    );

    return Text(widget.channel.subtitle, style: subStyle);

  }

  String textOnButton1 = 'FOLLOW';

  Future<DocumentSnapshot> _checkFollowing() async{
    String cid = widget.channel.id;
    String currentUser = fbAuth.currentUser.uid;
    DocumentReference currRef = fbFirestore.collection("users").doc(currentUser);

    await currRef.get().then((snapshot) {
      var followers = snapshot.get("following");
      bool isFollowing = false;

      for(String follower in followers){
        if(cid == follower)
          isFollowing = true;
      }

      if(isFollowing==true)
        textOnButton1 = 'FOLLOWING';

      else
        textOnButton1 = 'FOLLOW';

      return snapshot;
    });
  }

  Widget _buildButtons(BuildContext context) {

    // on follow button click
    void changeTextOnFollow() async {
      String cid = widget.channel.id;
      String currentUser = fbAuth.currentUser.uid;
      DocumentReference userRef = fbFirestore.collection("users").doc(cid);
      DocumentReference currUserRef = fbFirestore.collection("users").doc(currentUser);

      // update on current user's end
      await currUserRef.get().then((snapshot){
        var following = snapshot.get("following");
        bool isFollowing = false;

        for(String follower in following){
          if(cid == follower)
            isFollowing = true;

        }

        if(isFollowing==false) {
          following.add(cid);
          currUserRef.update({"following":following});

          isFollowing = true;
          setState(() {
            textOnButton1 = 'FOLLOWING';
          });
        }
        else {
          following.remove(cid);
          currUserRef.update({"following":following});

          isFollowing = false;
          setState(() {
            textOnButton1 = 'FOLLOW';
          });
        }

      });
    }


    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
      child: Row(
        children: <Widget>[
          const SizedBox(height: 40,width: 10,),
          Expanded(
              child: RaisedButton(
                onPressed: (){
                  changeTextOnFollow();
                },
                color: Colors.yellow[400],
                padding: EdgeInsets.all(10.0),
                child: FutureBuilder(
                    future: _checkFollowing(),
                    builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
                      if (snapshot.connectionState == ConnectionState.done) {

                        return Text(
                          "$textOnButton1",
                          style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                              fontSize: 15
                          ),
                        );
                      }

                      else if (snapshot.connectionState == ConnectionState.none) {
                        print("No data");
                      }
                      return CircularProgressIndicator();
                    }
                ),
              )
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
   // _getProfileDetails();
    return Scaffold(
      appBar: AppBar(
        leading:(
            IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.pop(context);
              },
            )

        ),

        title: Text("Channel ",style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),),
        toolbarHeight: 65,
        //centerTitle: true,
        backgroundColor: Colors.black87,
        actions: <Widget>[
        ],
      ),
      body: Stack(
        children: <Widget>[
          SafeArea(
            child: SingleChildScrollView(
              child: Column(
                children: <Widget>[
                  Stack(
                    fit: StackFit.loose,
                    children: [
                      SafeArea(child: Column(
                        children: [
                          SizedBox(height:20),
                          SizedBox(height:5),

                          Row(
                              mainAxisAlignment: MainAxisAlignment.start  ,
                              children: <Widget>[
                                SizedBox(width: 30,),
                                _buildChannelName(),
                              ]
                          ),
                          SizedBox(height:5),

                          Row(
                              mainAxisAlignment: MainAxisAlignment.start  ,
                              children: <Widget>[
                                SizedBox(width: 30,),
                                _buildSub(context),
                              ]
                          ),

                          SizedBox(height: 5.0),
                          SizedBox(height: 8.0),
                          _buildButtons(context),
                          SizedBox(height: 15.0),

                         ],
                        ),
                      )
                    ],
                  ),
                  buildChannelGridView(screenSize, widget.channel.id),

                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
