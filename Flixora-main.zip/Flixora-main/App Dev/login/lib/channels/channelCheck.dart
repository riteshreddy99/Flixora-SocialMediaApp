import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

final FirebaseFirestore _fbFirestore = FirebaseFirestore.instance;
final FirebaseAuth _fbAuth = FirebaseAuth.instance;

Future<bool> checkIfCreator() async{
  String uid = _fbAuth.currentUser.uid;
  DocumentReference userRef = _fbFirestore.doc("users/" + uid);
  bool isCreator;

  await userRef.get().then((snapshot){


      isCreator = snapshot.get("role").toString() == "Channel Creator";

  });


  return isCreator;
}
