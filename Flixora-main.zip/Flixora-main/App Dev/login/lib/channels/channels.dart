import 'package:flutter/material.dart';
import 'channelSearch.dart';
import 'channelCreate.dart';
import 'channelList.dart';
import 'channelCheck.dart';

class ChannelsPage extends StatefulWidget {
  static of(BuildContext context, {bool root = false}) => root
      ? context.findRootAncestorStateOfType<_ChannelsPageState>()
      : context.findAncestorStateOfType<_ChannelsPageState>();

  @override
  _ChannelsPageState createState() => _ChannelsPageState();
}

class _ChannelsPageState extends State<ChannelsPage> {

  Color buttonBgColor = Colors.black87;
  Color buttonInnerColor = Colors.white;

  Future<bool> _checkIfAllowed() async{
    bool isCreator = await checkIfCreator();

    if(!isCreator){
      buttonBgColor = Colors.black26;
      buttonInnerColor = Colors.white38;
    }

    return isCreator;
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;

    return FutureBuilder(
      future:_checkIfAllowed(),
      builder:(context,allowed) {
        return Scaffold(
          appBar: AppBar(
            leading: (
                IconButton(
                  icon: Icon(
                    Icons.arrow_back,
                    color: Colors.white,
                  ),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                )

            ),

            title: Text("Channels",
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),),
            toolbarHeight: 65,
            //centerTitle: true,
            backgroundColor: Colors.black87,
            actions: <Widget>[
            ],
          ),
          body: Column(
            children: <Widget>[
              Padding(
                  padding: EdgeInsets.only(
                      top: screenSize.height / 7, left: screenSize.width / 17),
                  child: RaisedButton.icon(
                    padding: EdgeInsets.all(25),
                    shape: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide(
                            color: Colors.grey.shade100
                        )
                    ),
                    icon: Icon(Icons.search, color: Colors.white, size: 30,),
                    label: Text("Look up channels",
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                          fontSize: 22
                      ),
                    ),
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(
                          builder: (context) => ChannelSearch()),);
                    },
                    color: Colors.black87,
                  )
              ),
              Padding(
                  padding: EdgeInsets.only(
                      top: screenSize.height / 8, left: screenSize.width / 15),
                  child: RaisedButton.icon(
                    padding: EdgeInsets.all(25),
                    shape: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide(
                            color: Colors.grey.shade100
                        )
                    ),
                    icon: Icon(Icons.add, color: buttonInnerColor, size: 30,),
                    label: Text("Create your own channel",
                      style: TextStyle(
                          color: buttonInnerColor,
                          fontWeight: FontWeight.w600,
                          fontSize: 22
                      ),
                    ),
                    onPressed: () {
                      print(allowed.data);
                      if(allowed.data) {
                        Navigator.push(context, MaterialPageRoute(
                            builder: (context) => ChannelCreate()),);
                      }
                      else return null;
                    },
                    color: buttonBgColor,
                  )
              ),
              Padding(
                  padding: EdgeInsets.only(
                      top: screenSize.height / 8, left: screenSize.width / 15),
                  child: RaisedButton.icon(
                    disabledColor: Colors.blue,
                    disabledTextColor: Colors.grey,
                    disabledElevation: 0,
                    padding: EdgeInsets.all(25),
                    shape: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                        borderSide: BorderSide(
                            color: Colors.grey.shade100
                        )
                    ),
                    icon: Icon(
                      Icons.mode_outlined, color:buttonInnerColor, size: 30,),
                    label: Text("Edit existing channels",
                      style: TextStyle(
                          color: buttonInnerColor,
                          fontWeight: FontWeight.w600,
                          fontSize: 22
                      ),
                    ),
                    onPressed: () {
                      if(allowed.data) {
                        Navigator.push(context, MaterialPageRoute(
                            builder: (context) => ChannelList()),);
                      }
                      else return null;
                    },
                    color: buttonBgColor,
                  )
              ),
            ],
          ),
          // body: buildAnimSearchBar(),
          // bottomNavigationBar: BottomNavBar(),
        );
      }
    );
  }
}
