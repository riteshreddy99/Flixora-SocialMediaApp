import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:login/data/channel.dart';
import 'channelDisplay.dart';


TextStyle defaultDarkStyle = TextStyle(color: Colors.white, fontSize: 18.0);
TextStyle hintStyle = TextStyle(color: Colors.white54, fontSize: 18.0);
Future<QuerySnapshot> searchResultsFuture;
TextEditingController searchController = TextEditingController();

class ChannelSearch extends StatefulWidget {
  static of(BuildContext context, {bool root = false}) => root
      ? context.findRootAncestorStateOfType<_ChannelSearchState>()
      : context.findAncestorStateOfType<_ChannelSearchState>();

  @override
  _ChannelSearchState createState() => _ChannelSearchState();
}

class _ChannelSearchState extends State<ChannelSearch> {
  final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
  final FirebaseAuth fbAuth = FirebaseAuth.instance;

  Widget buildSearchBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(15),
      child: Container(
        decoration: new BoxDecoration(
          // border: Border.all(
          //   color: Colors.grey,
          // ),
          borderRadius: BorderRadius.all(Radius.circular(10)),
          color: Colors.grey[700],
        ),
        child: Container(
          child: Padding(
            padding: EdgeInsets.all(8.0),
            child: TextField(
              controller: searchController,
              onSubmitted: handleSearch,
              style: defaultDarkStyle,
              decoration: new InputDecoration(
                border: InputBorder.none,
                prefixIcon: Icon(Icons.search, color: Colors.grey),
                hintStyle: hintStyle,
                // enabledBorder: const UnderlineInputBorder(
                //   borderSide: const BorderSide(color: Colors.white),
                // ),
                hintText: "Search",
              ),
            ),
          ),
        ),
      ),
    );
  }

  handleSearch(String query) async{

    if (query.isEmpty) return;
    print("Searching...");

    CollectionReference chanRef = fbFirestore.collection("channels");

    Future<QuerySnapshot> users =
    chanRef.where("title", isGreaterThanOrEqualTo: query).get();

    setState(() {
      searchResultsFuture = users;
    });
  }

  buildSearch() {
    return FutureBuilder(
      future: searchResultsFuture,
      builder: (context, snapshot) {

        if (!snapshot.hasData || snapshot.hasError) {
          return SpinKitRipple(
            color: Colors.grey,
          );
        }
        else {
          List<DocumentSnapshot> docsUnfiltered = snapshot.data.docs;

          List<DocumentSnapshot> docs = [];
          docsUnfiltered.forEach((element) {
            String s = element.get("title");
            s = s.toLowerCase();

            if (s.contains(searchController.text.toLowerCase())) {
              docs.add(element);
            }
          });


          if(docs.length == 0)
            return Text("No results");

          return SizedBox(
            height: 200,
            child: new ListView.builder(
              itemCount: docs.length,
              itemBuilder: (BuildContext ctxt, int index) {
                var docInstance = docs[index];
                Channel chan = Channel();

                chan.posts = docInstance.get("posts");
                chan.id = docInstance.get("channel-id");
                chan.subtitle = docInstance.get("subtitle");
                chan.title = docInstance.get("title");
                chan.tags = docInstance.get("tags");

                return Container(
                  decoration: BoxDecoration(
                    // border: Border(bottom: BorderSide(),)
                  ),
                  child: new Card(
                    // shape: StadiumBorder(
                    //   // borderRadius: BorderRadius.circular(15),
                    //   side: BorderSide(
                    //     color: Colors.black,
                    //     width: 2.0
                    //   )
                    // ),
                    elevation: 20,

                    child: ListTile(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    ChanDisplay(channel: chan)));
                      },

                      title: Text(chan.title)
                    ),
                  )
                );
              },
            ),
          );
        }

        return Text("data");
      },
    );
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        leading:(
            IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: Colors.white,
              ),
              onPressed: () {
                Navigator.pop(context);
              },
            )

        ),

        title: Text("Channel Search",style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),),
        toolbarHeight: 65,
        //centerTitle: true,
        backgroundColor: Colors.black87,
        actions: <Widget>[
        ],
      ),
      body: Column(
        children: <Widget>[
          buildSearchBar(context),
          Expanded(
            child: buildSearch(),
          ),
        ],
      ),
      // body: buildAnimSearchBar(),
      // bottomNavigationBar: BottomNavBar(),
    );
  }
}
