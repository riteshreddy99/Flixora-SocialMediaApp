import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:login/helper/notifications.dart';
import 'package:login/widgets/individualPost.dart';

Widget buildChannelGridView(Size screenSize, cid) {
  final FirebaseFirestore fb = FirebaseFirestore.instance;

  Future<DocumentSnapshot> getChannelRef() {
    print(cid);
    return fb.doc("channels/" + cid).get();
  }


  Future<String> getPostImage(postLink) async {

    DocumentReference postRef = fbFirestore.doc(postLink);

    String link;
    await postRef.get().then((snapshot){
      link = snapshot.get("image-link");
    });

    return link;
  }

  return Container(
      child: FutureBuilder(
          future: getChannelRef(),
          builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
            if (snapshot.connectionState == ConnectionState.done) {
              List posts = snapshot.data.get("posts");

              return GridView.builder(
                primary: false,
                shrinkWrap: true,
                gridDelegate:
                SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3, mainAxisSpacing: 2, crossAxisSpacing: 2
                ),
                itemCount: posts.length,
                itemBuilder: (BuildContext context, int index) {
                  String postLink = posts[index];
                  List<String> linkData = postLink.split("/");
                  print(postLink);

                  return FutureBuilder(

                      future: getPostImage(postLink),
                      builder: (context, AsyncSnapshot<String> post) {
                      if (post.connectionState == ConnectionState.done) {
                        print(linkData[2]);
                        print(linkData[4]);
                          return Container(

                            child: GestureDetector(
                              child: Image.network(
                                  post.data,
                                  fit: BoxFit.fill
                              ),
                              onTap: () =>
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(builder: (context) =>
                                        IndividualPost(
                                            uid: linkData[2],
                                            pid: linkData[4])),
                                  ),
                            ),
                          );
                      }
                      else if (snapshot.connectionState == ConnectionState.none) {
                        return Text("No data");
                      }
                      return SpinKitPulse(
                        color: Colors.grey,
                        size: 50,
                      );
                  });
                },
              );
            }
            else if (snapshot.connectionState == ConnectionState.none) {
              return Text("No data");
            }
            return SpinKitPulse(
              color: Colors.grey,
              size: 50,
            );

          }
      ),
      height: 300
  );

}
