import '../homePage.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ChannelCreate extends StatelessWidget {

  final titleController = TextEditingController();
  final subtitleController = TextEditingController();
  final tag1Controller = TextEditingController();
  final tag2Controller = TextEditingController();
  final tag3Controller = TextEditingController();



  Widget _buildTextBoxes(Size screenSize,context) {
    TextStyle defaultDarkStyle = TextStyle(color: Colors.amber[100], fontSize: 18.0);

    return Padding(
      padding: EdgeInsets.only(top: 30),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,

        children: <Widget>[
          Container(
            padding: EdgeInsets.all(15.0),
            child: Theme(
              data: Theme.of(context)
                  .copyWith(splashColor: Colors.transparent),
              child: TextField(
                controller: titleController,
                autofocus: false,
                style: defaultDarkStyle,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.black,
                  hintText: 'Channel Name',
                  contentPadding: const EdgeInsets.only(
                      left: 14.0, bottom: 12.0, top: 10.0),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white),
                    borderRadius: BorderRadius.circular(25.7),
                  ),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.black),
                    borderRadius: BorderRadius.circular(25.7),
                  ),
                ),
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.all(15.0),
            child: Theme(
              data: Theme.of(context)
                  .copyWith(splashColor: Colors.transparent),
              child: TextField(
                controller: subtitleController,
                autofocus: false,
                style: defaultDarkStyle,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.black,
                  hintText: 'Channel Description',
                  contentPadding: const EdgeInsets.only(
                      left: 14.0, bottom: 12.0, top: 10.0),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white),
                    borderRadius: BorderRadius.circular(25.7),
                  ),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.black),
                    borderRadius: BorderRadius.circular(25.7),
                  ),
                ),
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.all(15.0),
            child: Theme(
              data: Theme.of(context)
                  .copyWith(splashColor: Colors.transparent),
              child: TextField(
                controller: tag1Controller,
                autofocus: false,
                style: defaultDarkStyle,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.black,
                  hintText: '#Tag1',
                  contentPadding: const EdgeInsets.only(
                      left: 14.0, bottom: 12.0, top: 10.0),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white),
                    borderRadius: BorderRadius.circular(25.7),
                  ),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.black),
                    borderRadius: BorderRadius.circular(25.7),
                  ),
                ),
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.all(15.0),
            child: Theme(
              data: Theme.of(context)
                  .copyWith(splashColor: Colors.transparent),
              child: TextField(
                controller: tag2Controller,
                autofocus: false,
                style: defaultDarkStyle,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.black,
                  hintText: '#Tag2',
                  contentPadding: const EdgeInsets.only(
                      left: 14.0, bottom: 12.0, top: 10.0),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white),
                    borderRadius: BorderRadius.circular(25.7),
                  ),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.black),
                    borderRadius: BorderRadius.circular(25.7),
                  ),
                ),
              ),
            ),
          ),
          Container(
            padding: EdgeInsets.all(15.0),
            child: Theme(
              data: Theme.of(context)
                  .copyWith(splashColor: Colors.transparent),
              child: TextField(
                controller: tag3Controller,
                autofocus: false,
                style: defaultDarkStyle,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.black,
                  hintText: '#Tag3',
                  contentPadding: const EdgeInsets.only(
                      left: 14.0, bottom: 12.0, top: 10.0),
                  focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.white),
                    borderRadius: BorderRadius.circular(25.7),
                  ),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(color: Colors.black),
                    borderRadius: BorderRadius.circular(25.7),
                  ),
                ),
              ),
            ),
          ),

          new SizedBox(height: 30),
          Container(
            padding: EdgeInsets.all(10.0),
            height: 70.0,
            child: Material(
              borderRadius: BorderRadius.circular(20.0),
              shadowColor: Colors.black,
              color: Colors.black,
              elevation: 7.0,
              child: InkWell(
                onTap: () async {
                  await _addChannel();
                  Navigator.pop(context);
                },
                child: Center(
                  child: Text(
                    'CREATE',
                    style: TextStyle(
                        color: Colors.amber[300],
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Montserrat'),
                  ),
                ),
              ),
            ),
          ),

        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    return new Scaffold(
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          leading:(
              IconButton(
                icon: Icon(
                  Icons.arrow_back,
                  color: Colors.white,
                ),
                onPressed: () {
                  Navigator.pop(context);
                },
              )

          ),

          title: Text("Create Channel",style: TextStyle(fontSize: 25, fontWeight: FontWeight.w500),),
          toolbarHeight: 65,
          //centerTitle: true,
          backgroundColor: Colors.black87,
          actions: <Widget>[
          ],
        ),
        body: Container(
          child: Column(
            children:<Widget>[
              _buildTextBoxes(screenSize,context),

            ]
          )
        )
    );
  }

  _checkForHash(tag,tags){
    if(tag.text.isNotEmpty){

      if(tag.text[0] != '#')
        tag.text = '#' + tag.text;

      tags.add(tag.text);
      return tags;
    }

    return tags;
  }


  Future _addChannel() async {
      try {
        DocumentReference channelRef = fbFirestore.collection("channels").doc();

        List tags = [];

        if(tag1Controller.text.isEmpty && tag2Controller.text.isEmpty && tag3Controller.text.isEmpty)
          return;

        if(titleController.text.isEmpty)
          return;

        tags = _checkForHash(tag1Controller,tags);
        tags = _checkForHash(tag2Controller,tags);
        tags = _checkForHash(tag3Controller,tags);


        Map<String, dynamic> channelData = {
          "channel-id": channelRef.id,
          "posts": [],
          "subtitle": subtitleController.text,
          "title": titleController.text,
          "tags": tags,

        };

        channelRef.set(channelData);

      } catch (e) {
        print(e.message);
      }
    }
  }

