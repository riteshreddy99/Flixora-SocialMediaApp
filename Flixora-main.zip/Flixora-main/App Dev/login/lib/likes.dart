import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:login/data/notification.dart';
import 'package:login/profile/main-profileOther.dart';
import 'package:login/widgets/individualPost.dart';
import 'package:login/widgets/chatList.dart';
import 'package:line_icons/line_icons.dart';

class LikesPage extends StatefulWidget {
  @override
  _LikesPageState createState() => _LikesPageState();
}

final FirebaseFirestore fbFirestore = FirebaseFirestore.instance;
final FirebaseAuth fbAuth = FirebaseAuth.instance;


Future<DocumentSnapshot> _getProfileDetails(userid) {
  return fbFirestore.doc("users/" + userid).get();
}

Widget buildProfilePic(userid) {
  return FutureBuilder(
      future: _getProfileDetails(userid),
      builder: (context, AsyncSnapshot<DocumentSnapshot> snapshot) {
        if (snapshot.connectionState == ConnectionState.done) {
          return CircleAvatar(
            backgroundImage: NetworkImage(snapshot.data.get("photoUrl")),
          );
        } else if (snapshot.connectionState == ConnectionState.none) {
          print("No data");
        }
        return SpinKitPulse(
          size: 30,
          color: Colors.grey,
        );
      });
}

void checkNotifType(notif,context){

  if (notif.type == "comment-like"){      // comment has been liked
    print( notif.refUID);
    print(notif.refPID);
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => IndividualPost(uid: notif.refUID,pid: notif.refPID)
        )
    );
  }

  else if(notif.type == "follow"){  // new follower
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => UserProfilePage(userid: notif.uid)
        )
    );
  }

  else if(notif.type == "comment"){       // new comment on post
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => IndividualPost(uid: fbAuth.currentUser.uid,pid: notif.refPID)
        )
    );
  }

  else if(notif.type == "like"){          // post has been liked
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => IndividualPost(uid: fbAuth.currentUser.uid,pid: notif.refPID)
        )
    );
  }
}

Widget _buildNotifIcon(String type){
  if(type == "follow"){
    return Icon(Icons.person_add_alt);
  }
  else if(type == "comment"){
    return Icon(Icons.messenger_outline);
  }
  else if(type == "comment-like"){
    return Icon(Icons.favorite);
  }
  else if(type == "like"){
    return Icon(Icons.favorite);
  }
}

Widget _buildNotifs(){
  return Container(
    margin: const EdgeInsets.only(left: 20.0, top: 20.0,bottom:20,right:10),
    child: StreamBuilder(
        stream:  fbFirestore.collection("users")
            .doc(fbAuth.currentUser.uid)
            .collection("notifications")
            .orderBy("time-sent",descending: true)
            .snapshots(),
        builder: (context,snapshot) {

          if(!snapshot.hasData){
            return SpinKitRipple(
              color: Colors.grey[800],
              size: 60.0,
            );
          }

          List<NotificationBox> notifs = [];

          for(DocumentSnapshot doc in snapshot.data.docs){
            NotificationBox notif = new NotificationBox();

            notif.message = doc.get("message");
            notif.timeSent =  DateTime.parse(doc.get("time-sent").toDate().toString());
            notif.type = doc.get("type");
            notif.uid = doc.get("userID");
            notif.username = doc.get("username");
            notif.refPID = doc.get("refPID");
            notif.refUID = doc.get("refUID");
            notifs.add(notif);
          }

          if(!snapshot.hasData)
            return SpinKitFadingCube(
              color: Colors.yellow[600],
              size: 60.0,
            );
          else {
            return Expanded(
                child: ListView.builder(
                    shrinkWrap: true,
                    physics: BouncingScrollPhysics(),
                    reverse: false,
                    itemCount: notifs.length,
                    itemBuilder: (context, index) {
                      final notif = notifs[index];
                      return Padding(

                          padding: EdgeInsets.only(top: 10, bottom: 10),
                          child: Column(
                            children: <Widget>[
                              ListTile(
                                onTap: () {
                                  checkNotifType(notif,context);
                                },
                                leading: buildProfilePic(notif.uid),
                                title: Text(notif.username),
                                subtitle: Text(notif.message),
                                trailing: _buildNotifIcon(notif.type),
                              ),

                            ],
                          )
                      );
                    }
                )
            );
          }
        }
    ),
  );
}


class _LikesPageState extends State<LikesPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Notifications",style: TextStyle(color: Color(0xfffdd835))),
        toolbarHeight: 65,
        centerTitle: true,
        backgroundColor: Colors.black,
        actions: <Widget>[
          IconButton(
            icon: Icon(
              Icons.messenger_outline_rounded,
              color: Colors.white,
            ),
            onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context) => ChatList()),);
            },
          )
        ],
      ),
      body: Container(
          child:
            _buildNotifs()
      ),
    );
  }
}

