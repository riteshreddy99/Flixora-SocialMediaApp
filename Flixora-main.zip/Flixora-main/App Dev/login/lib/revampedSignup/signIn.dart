import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:login/homePage.dart';
import 'package:login/revampedSignup/AuthenService.dart';
import 'package:flutter/material.dart';
import 'package:login/revampedSignup/signInGoogle.dart';
import 'package:provider/provider.dart';
import 'package:flutter_signin_button/flutter_signin_button.dart';
import 'package:login/home.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:login/main.dart';

FirebaseAuth auth = FirebaseAuth.instance;
final GlobalKey<State> _keyLoader = new GlobalKey<State>();
final GlobalKey<State> _keyWaiter = new GlobalKey<State>();
final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

class SignInPage extends StatefulWidget {
  @override
  _SignInPageState createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  bool isValidCredentials = true;
  bool isSigningIn = false;
  final googleSignIn = GoogleSignIn();
  var newUser;


  @override
  void dispose() {
    // Clean up the controller when the widget is disposed.
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  Future<void> showWaitingDialog(BuildContext context, GlobalKey key) async {
    return showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return new WillPopScope(
              onWillPop: () async => false,
              child: SimpleDialog(
                  key: key,
                  backgroundColor: Colors.transparent,
                  children: <Widget>[
                    Center(child: Text("Please verify your email.")),
                    Padding(
                      padding: const EdgeInsets.only(top: 20),
                      child: OutlineButton(
                        onPressed: () {
                          Navigator.of(key.currentContext, rootNavigator: true)
                              .pop();
                        },
                        child: Text("OK"),
                      ),
                    )
                  ]));
        });
  }

  Future<void> showLoadingDialog(BuildContext context, GlobalKey key) async {
    return showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return new WillPopScope(
              onWillPop: () async => false,
              child: SimpleDialog(
                  key: key,
                  backgroundColor: Colors.transparent,
                  children: <Widget>[
                    Center(
                      child: SpinKitFadingCube(
                        color: Colors.yellow[600],
                        size: 60,
                      ),
                    )
                  ]));
        });
  }

  Future<bool> googleLogIn() async {
    var exists = false;
    final user = await googleSignIn.signIn();

    if (user != null) {
      final googleAuth = await user.authentication;
      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      try {
        final UserCredential userCredential =
            await FirebaseAuth.instance.signInWithCredential(credential);
        //
        newUser = userCredential.user;
        String uid = newUser.uid;

        await FirebaseFirestore.instance
            .doc("users/$uid")
            .get()
            .then((doc) async {
          // User exists in database
          if (doc.exists) {
            exists = true;
          }
          // User does not exist. Prompt to page to enter their username and all
          else {
            exists = false;
          }
        });
        return exists;
      } catch (e) {
        return false;
      }
    }
    return exists;
  }

  Future<User> googleLogInT() async {
    if (kIsWeb) {
      GoogleAuthProvider authProvider = GoogleAuthProvider();
      try {
        final UserCredential userCredential =
            await auth.signInWithPopup(authProvider);
        newUser = userCredential.user;
      } catch (e) {
        print(e);
      }
    } else {
      final GoogleSignIn googleSignIn = GoogleSignIn();

      final GoogleSignInAccount googleSignInAccount =
          await googleSignIn.signIn();

      if (googleSignInAccount != null) {
        final GoogleSignInAuthentication googleSignInAuthentication =
            await googleSignInAccount.authentication;

        final AuthCredential credential = GoogleAuthProvider.credential(
          accessToken: googleSignInAuthentication.accessToken,
          idToken: googleSignInAuthentication.idToken,
        );

        try {
          final UserCredential userCredential =
              await auth.signInWithCredential(credential);

          newUser = userCredential.user;
        } on FirebaseAuthException catch (e) {} catch (e) {}
      }
      return newUser;
    }
    return newUser;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        //backgroundColor: Colors.black,
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Container(
              child: Stack(
                children: <Widget>[
                  Container(
                    padding: EdgeInsets.fromLTRB(0.0, 160.0, 0.0, 0.0),
                    child: Center(
                      child: Text('Flixora',
                          style: TextStyle(
                              color: Colors.amber[600],
                              fontSize: 50.0,
                              fontWeight: FontWeight.bold)),
                    ),
                  ),
                ],
              ),
            ),
            Container(
                padding: EdgeInsets.only(top: 40.0, left: 20.0, right: 20.0),
                child: Column(
                  children: <Widget>[
                    SizedBox(height: 10.0),
                    Container(
                      child: Theme(
                        data: Theme.of(context)
                            .copyWith(splashColor: Colors.white),
                        child: Container(
                          decoration: BoxDecoration(
                              color: Colors.grey[900],
                              borderRadius: BorderRadius.circular(25)),
                          child: TextField(
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              errorText: isValidCredentials
                                  ? null
                                  : "Incorrect Credentials",
                              hintText: 'Email',
                              hintStyle: TextStyle(
                                fontSize: 15.0,
                                color: Colors.grey[500],
                              ),
                            ),
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold),
                            keyboardType: TextInputType.emailAddress,
                            textAlign: TextAlign.center,
                            controller: emailController,
                            autofocus: false,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 20.0),
                    Container(
                      child: Theme(
                        data: Theme.of(context)
                            .copyWith(splashColor: Colors.white),
                        child: Container(
                          decoration: BoxDecoration(
                              color: Colors.grey[900],
                              borderRadius: BorderRadius.circular(25)),
                          child: TextField(
                            enableSuggestions: false,
                            autocorrect: false,
                            obscureText: true,
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              errorText: isValidCredentials
                                  ? null
                                  : "Incorrect Credentials",
                              hintText: 'Password',
                              hintStyle: TextStyle(
                                fontSize: 15.0,
                                color: Colors.grey[500],
                              ),
                            ),
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold),
                            textAlign: TextAlign.center,
                            controller: passwordController,
                            autofocus: false,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 5.0),
                    Container(
                      alignment: Alignment(1.0, 0.0),
                      padding: EdgeInsets.only(top: 15.0, left: 20.0),
                      child: InkWell(
                        onTap: () {
                          Navigator.of(context).pushNamed('/forgotpw');
                        },
                        child: Text(
                          'Forgot Password?',
                          style: TextStyle(
                            color: Colors.amber[100],
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Montserrat',
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 40.0),
                    Container(
                      height: 40.0,
                      color: Colors.transparent,
                      child: Container(
                        decoration: BoxDecoration(
                            border: Border.all(
                                style: BorderStyle.solid, width: 1.0),
                            color: Colors.amber[600],
                            borderRadius: BorderRadius.circular(20.0)),
                        child: InkWell(
                          onTap: () async {
                            String emailText = emailController.text.trim();
                            String passwordText =
                                passwordController.text.trim();
                            if (emailText.isNotEmpty &&
                                passwordText.isNotEmpty) {
                              showLoadingDialog(context, _keyLoader);
                            }

                            String loginStatus =
                                await context.read<AuthenService>().signIn(
                                      email: emailText,
                                      password: passwordText,
                                    );
                            final loggingUser =
                                FirebaseAuth.instance.currentUser;
                            if (loginStatus == null) {
                              Navigator.of(context, rootNavigator: true).pop();
                              if (loggingUser.emailVerified) {
                                var route = new MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        new HomePage());
                                Navigator.of(context).pushAndRemoveUntil(
                                    route, (route) => false);
                              } else {
                                showWaitingDialog(context, _keyWaiter);
                              }
                            } else {
                              setState(() {
                                isValidCredentials = false;
                              });
                              Navigator.of(_keyLoader.currentContext,
                                      rootNavigator: true)
                                  .pop();
                            }
                          },
                          child: Center(
                            child: Text('LOGIN',
                                style: TextStyle(
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                    fontFamily: 'Montserrat')),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(height: 20.0),
                    Container(
                      height: 40.0,
                      color: Colors.transparent,
                      child: Container(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            SizedBox(width: 10.0),
                            SignInButton(
                              Buttons.Google,
                              text: "Sign in with Google",
                              onPressed: () async {
                                showLoadingDialog(context, _keyLoader);
                                bool isUser = await googleLogIn();
                                if (isUser) {
                                  print("The statement is true");
                                  var route = new MaterialPageRoute(
                                      builder: (BuildContext context) =>
                                          new HomePage());
                                  Navigator.of(_keyLoader.currentContext, rootNavigator: true).pop();

                                  Navigator.of(this.context).pushAndRemoveUntil(
                                      route, (route) => false);
                                } else {
                                  print("The statement is false");
                                  var route2 = new MaterialPageRoute(
                                      builder: (BuildContext context) =>
                                          new SignInGoogle(
                                            user: newUser,
                                          ));
                                  Navigator.of(_keyLoader.currentContext, rootNavigator: true).pop();

                                  Navigator.of(this.context).push(route2);
                                }
                              },
                            ),

                            //Add Icon for Facebook
                            // Google Icon and button
                          ],
                        ),
                      ),
                    ),
                  ],
                )),
            SizedBox(height: 15.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  'New to Flixora ?',
                  style: TextStyle(
                      fontFamily: 'Montserrat', color: Colors.amber[100]),
                ),
                SizedBox(width: 5.0),
                InkWell(
                  onTap: () {
                    Navigator.of(context).pushNamed('/createaccount');
                  },
                  child: Text(
                    'Register',
                    style: TextStyle(
                      color: Colors.amber[100],
                      fontFamily: 'Montserrat',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ));
  }
}
