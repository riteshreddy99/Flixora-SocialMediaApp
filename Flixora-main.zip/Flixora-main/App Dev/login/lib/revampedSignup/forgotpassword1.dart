import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class FPW1Page extends StatefulWidget {
  @override
  _FPW1PageState createState() => _FPW1PageState();
}

class _FPW1PageState extends State<FPW1Page> {
  TextEditingController _email = TextEditingController();
  final auth = FirebaseAuth.instance;

  showAlertDialog(BuildContext context, String msg) {
    // set up the button
    Widget okButton = FlatButton(
      child: Text("OK"),
      onPressed: () {
        Navigator.pop(context);
      },
    );
    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("Reset Password"),
      content: Text(msg),
      actions: [
        okButton,
      ],
    );
    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        resizeToAvoidBottomInset: false,
        body: Column(children: <Widget>[
          Container(
            child: Stack(
              children: <Widget>[
                Container(
                  padding: EdgeInsets.fromLTRB(0.0, 100.0, 0.0, 0.0),
                  child: Center(
                    child: Text(
                      'Please Enter Your',
                      style: TextStyle(
                          color: Colors.amber[100],
                          fontSize: 30.0,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.fromLTRB(0.0, 140.0, 0.0, 0.0),
                  child: Center(
                    child: Text(
                      'Registered Email ID ',
                      style: TextStyle(
                          color: Colors.amber[100],
                          fontSize: 30.0,
                          fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Container(
              padding: EdgeInsets.only(top: 65.0, left: 20.0, right: 20.0),
              child: Column(
                children: <Widget>[
                  SizedBox(height: 10.0),
                  Container(
                    child: Theme(
                      data: Theme.of(context)
                          .copyWith(splashColor: Colors.transparent),
                      child: TextFormField(
                        controller: _email,
                        autofocus: false,
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 15.0, color: Colors.white),
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: Colors.grey[900],
                          hintText: 'Email ID',
                          hintStyle: TextStyle(
                              fontSize: 15.0, color: Colors.grey[500]),
                          contentPadding: const EdgeInsets.only(
                            left: 0.0,
                            bottom: 0.0,
                            top: 0.0,
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.grey[900]),
                            borderRadius: BorderRadius.circular(25.7),
                          ),
                          enabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(color: Colors.grey[900]),
                            borderRadius: BorderRadius.circular(25.7),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 30.0),
                  Container(
                    height: 40.0,
                    child: Material(
                      borderRadius: BorderRadius.circular(20.0),
                      shadowColor: Colors.black,
                      color: Colors.amber[600],
                      elevation: 7.0,
                      child: InkWell(
                        onTap: () async{
                          String email = _email.text.trim();
                          try {
                            await auth.sendPasswordResetEmail(
                                email: email);
                            showAlertDialog(context, "Please check your email $email for further instructions");
                          } catch (e) {
                            showAlertDialog(context, "Please input a valid email.");
                          }
                        },
                        child: Center(
                          child: Text(
                            'Send Verification Code',
                            style: TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(height: 20.0),
                  Container(
                    height: 40.0,
                    color: Colors.transparent,
                    child: Container(
                      decoration: BoxDecoration(
                          border: Border.all(
                              color: Colors.black,
                              style: BorderStyle.solid,
                              width: 1.0),
                          color: Colors.black,
                          borderRadius: BorderRadius.circular(20.0)),
                      child: InkWell(
                        onTap: () {
                          Navigator.of(context).pop();
                        },
                        child: Center(
                          child: Text('Go Back',
                              style: TextStyle(
                                color: Colors.amber[100],
                                fontWeight: FontWeight.bold,
                              )),
                        ),
                      ),
                    ),
                  ),
                ],
              )),
        ]));
  }
}
