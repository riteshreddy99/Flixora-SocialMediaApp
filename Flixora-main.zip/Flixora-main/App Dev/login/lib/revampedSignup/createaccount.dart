import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:dropdown_formfield/dropdown_formfield.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:login/homePage.dart';
import '../home.dart';
import '../main.dart';

class New1Page extends StatefulWidget {
  @override
  _New1PageState createState() => _New1PageState();
}

class _New1PageState extends State<New1Page> {
  final fNameController = TextEditingController();
  final lNameController = TextEditingController();
  final userNameController = TextEditingController();
  final passController = TextEditingController();
  final emailController = TextEditingController();
  RegExp emailReg = new RegExp(
      r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,253}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,253}[a-zA-Z0-9])?)*$");
  bool emailValid = true;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  String _myRole = "User";
  final GlobalKey<State> _keyLoader = new GlobalKey<State>();
  final GlobalKey<State> _keyWaiter = new GlobalKey<State>();
  @override
  void dispose() {
    // Clean up the controller when the widget is disposed.
    fNameController.dispose();
    lNameController.dispose();
    userNameController.dispose();

    emailController.dispose();
    passController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        resizeToAvoidBottomInset: false,
        body: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Container(
                      padding:
                          EdgeInsets.only(top: 0.0, left: 20.0, right: 20.0),
                      child: Column(
                        children: <Widget>[
                          SizedBox(height: 10.0),
                          Container(
                            child: Stack(
                              children: <Widget>[
                                Container(
                                  padding:
                                      EdgeInsets.fromLTRB(15.0, 10.0, 0.0, 0.0),
                                  child: Center(
                                    child: SafeArea(
                                      child: Text(
                                        'Enter Details ',
                                        style: TextStyle(
                                            color: Colors.amber[100],
                                            fontSize: 30.0,
                                            fontWeight: FontWeight.bold),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 20.0),
                          Container(
                            decoration: BoxDecoration(
                                color: Colors.grey[900],
                                borderRadius: BorderRadius.circular(25)),
                            child: TextFormField(
                              decoration: InputDecoration(
                                border: InputBorder.none,
                                hintText: 'First Name',
                                hintStyle: TextStyle(
                                  fontSize: 15.0,
                                  color: Colors.grey[500],
                                ),
                              ),
                              validator: (name) {
                                Pattern pattern =
                                    r"^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$";
                                RegExp regex = new RegExp(pattern);
                                if (!regex.hasMatch(name))
                                  return 'Invalid first name';
                                else
                                  return null;
                              },
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.bold),
                              textAlign: TextAlign.center,
                              controller: fNameController,
                              autofocus: false,
                            ),
                          ),
                          SizedBox(height: 10.0),
                          Container(
                            decoration: BoxDecoration(
                                color: Colors.grey[900],
                                borderRadius: BorderRadius.circular(25)),
                            child: TextFormField(
                              decoration: InputDecoration(
                                border: InputBorder.none,
                                hintText: 'Last Name',
                                hintStyle: TextStyle(
                                  fontSize: 15.0,
                                  color: Colors.grey[500],
                                ),
                              ),
                              validator: (name) {
                                Pattern pattern =
                                    r"^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$";
                                RegExp regex = new RegExp(pattern);
                                if (!regex.hasMatch(name))
                                  return 'Invalid last name';
                                else
                                  return null;
                              },
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.bold),
                              textAlign: TextAlign.center,
                              controller: lNameController,
                              autofocus: false,
                            ),
                          ),
                          SizedBox(height: 10.0),
                          Container(
                            decoration: BoxDecoration(
                                color: Colors.grey[900],
                                borderRadius: BorderRadius.circular(25)),
                            child: TextFormField(
                              decoration: InputDecoration(
                                border: InputBorder.none,
                                hintText: 'Username',
                                hintStyle: TextStyle(
                                  fontSize: 15.0,
                                  color: Colors.grey[500],
                                ),
                              ),
                              validator: (name) {
                                Pattern pattern =
                                    r'^[A-Za-z0-9]+(?:[ _-][A-Za-z0-9]+)*$';
                                RegExp regex = new RegExp(pattern);
                                if (!regex.hasMatch(name.trim()))
                                  return 'Invalid username';
                                else
                                  return null;
                              },
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.bold),
                              textAlign: TextAlign.center,
                              controller: userNameController,
                              autofocus: false,
                            ),
                          ),
                          SizedBox(height: 10.0),
                          Container(
                            decoration: BoxDecoration(
                                color: Colors.grey[900],
                                borderRadius: BorderRadius.circular(25)),
                            child: TextFormField(
                              enableSuggestions: true,
                              autocorrect: false,
                              validator: (name) {
                                if (!emailReg.hasMatch(name))
                                  return 'Invalid email';
                                else
                                  return null;
                              },
                              decoration: InputDecoration(
                                border: InputBorder.none,
                                hintText: 'Email ID',
                                hintStyle: TextStyle(
                                  fontSize: 15.0,
                                  color: Colors.grey[500],
                                ),
                              ),
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.bold),
                              textAlign: TextAlign.center,
                              controller: emailController,
                              autofocus: false,
                            ),
                          ),
                          SizedBox(height: 10.0),
                          Container(
                            decoration: BoxDecoration(
                                color: Colors.grey[900],
                                borderRadius: BorderRadius.circular(25)),
                            child: TextFormField(
                              validator: (password) {
                                Pattern pattern =
                                    r'^(?=.*[0-9]+.*)(?=.*[a-zA-Z]+.*)[0-9a-zA-Z]{7,}$';
                                RegExp regex = new RegExp(pattern);
                                if (!regex.hasMatch(password))
                                  return 'Strong password required.';
                                else
                                  return null;
                              },
                              enableSuggestions: false,
                              autocorrect: false,
                              obscureText: true,
                              decoration: InputDecoration(
                                border: InputBorder.none,
                                hintText: 'Password',
                                hintStyle: TextStyle(
                                  fontSize: 15.0,
                                  color: Colors.grey[500],
                                ),
                              ),
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.bold),
                              textAlign: TextAlign.center,
                              controller: passController,
                              autofocus: false,
                            ),
                          ),
                          SizedBox(height: 10.0),
                          Container(
                              decoration: BoxDecoration(
                                color: Colors.grey[900],
                                borderRadius: BorderRadius.circular(25),
                              ),
                              child: DropdownButton<String>(
                                isExpanded: true,
                                value: _myRole,
                                onChanged: (String newValue) {
                                  setState(() {
                                    _myRole = newValue;
                                  });
                                },
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 15.0,
                                    fontWeight: FontWeight.bold),
                                underline: Container(
                                  color: null,
                                ),
                                items: <String>[
                                  'User',
                                  'Content Creator',
                                  'Channel Creator',
                                  'Platform Manager'
                                ].map((String value) {
                                  return new DropdownMenuItem<String>(
                                    value: value,
                                    child: Center(
                                        child: new Text(
                                      value,
                                      textAlign: TextAlign.center,
                                    )),
                                  );
                                }).toList(),
                              )),
                          Container(
                            padding: EdgeInsets.fromLTRB(15.0, 40.0, 0.0, 0.0),
                            child: Text(
                              ' By Clicking Create Account ',
                              style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 10.0,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.fromLTRB(10.0, 0.0, 0.0, 0.0),
                            child: Text(
                              'You Agree To All ',
                              style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 10.0,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.fromLTRB(15.0, 0.0, 0.0, 0.0),
                            child: Text(
                              'The Terms and Conditions',
                              style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 10.0,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                          SizedBox(height: 30.0),
                          Container(
                            height: 40.0,
                            child: Material(
                              borderRadius: BorderRadius.circular(20.0),
                              shadowColor: Colors.amber[100],
                              color: Colors.amber[600],
                              elevation: 7.0,
                              child: InkWell(
                                onTap: () async {
                                  if (_formKey.currentState.validate()) {
                                    _formKey.currentState.save();
                                    showLoadingDialog(context, _keyLoader);
                                    await signUp();
                                  }
                                },
                                child: Center(
                                  child: Text(
                                    'CREATE ACCOUNT',
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontFamily: 'Montserrat'),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: 10.0),
                          Container(
                            height: 40.0,
                            color: Colors.transparent,
                            child: Container(
                              decoration: BoxDecoration(
                                  border: Border.all(
                                      color: Colors.transparent,
                                      style: BorderStyle.solid,
                                      width: 1.0),
                                  color: Colors.transparent,
                                  borderRadius: BorderRadius.circular(20.0)),
                              child: InkWell(
                                onTap: () {
                                  Navigator.pop(context);
                                },
                                child: Center(
                                  child: Text('Go Back',
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontFamily: 'Montserrat',
                                          color: Colors.amber[100])),
                                ),
                              ),
                            ),
                          ),
                        ],
                      )),
                ]),
          ),
        ));
  }

  Future<void> showLoadingDialog(BuildContext context, GlobalKey key) async {
    return showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return new WillPopScope(
              onWillPop: () async => false,
              child: SimpleDialog(
                  backgroundColor: Colors.transparent,
                  key: key,
                  children: <Widget>[
                    Center(
                      child: SpinKitFadingCube(
                        color: Colors.yellow[600],
                        size: 60,
                      ),
                    )
                  ]));
        });
  }

  Future<void> showWaitingDialog(
      BuildContext context, GlobalKey key, String msg) async {
    return showDialog<void>(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext context) {
          return new WillPopScope(
              onWillPop: () async => false,
              child: SimpleDialog(
                  key: key,
                  backgroundColor: Colors.transparent,
                  children: <Widget>[
                    Center(child: Text(msg)),
                    Padding(
                      padding: const EdgeInsets.only(top: 20),
                      child: OutlineButton(
                        onPressed: () {
                          Navigator.of(key.currentContext, rootNavigator: true)
                              .pop();
                          Navigator.pushAndRemoveUntil(
                              context,
                              MaterialPageRoute(builder: (context) => MyApp()),
                              (route) => false);
                        },
                        child: Text("OK"),
                      ),
                    )
                  ]));
        });
  }

  Future signUp() async {
    try {
      await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: emailController.text, password: passController.text);

      Navigator.of(_keyLoader.currentContext, rootNavigator: true).pop();

      final FirebaseAuth auth = FirebaseAuth.instance;
      final User user = auth.currentUser;
      final uid = user.uid;
      final DocumentReference userRef =
          FirebaseFirestore.instance.collection('/users').doc(uid);

      Map<String, dynamic> userData = {
        "first-name": fNameController.text,
        "last-name": lNameController.text,
        "country": "",
        "username": userNameController.text,
        "email": emailController.text,
        "photoUrl":
            "https://firebasestorage.googleapis.com/v0/b/flixora-f29so.appspot.com/o/pngfind.com-male-symbol-png-349693.png?alt=media&token=daee2c36-5293-4754-8df9-c2b288b8a710",
        "bio": "I just signed up to Flixora!",
        "followers": [],
        "following": [],
        "role": _myRole,
        "points": 0,
      };
      await userRef.set(userData);

      if (user.emailVerified) {
        Navigator.pushReplacement(
            context, MaterialPageRoute(builder: (context) => HomePage()));
      } else {
        // Verify email
        showWaitingDialog(context, _keyWaiter,
            "Please follow email for further instructions");
        await auth.currentUser.sendEmailVerification();
      }
    } catch (e) {
      Navigator.of(_keyLoader.currentContext, rootNavigator: true).pop();
      showWaitingDialog(context, _keyWaiter, e.toString());
    }
  }
}
