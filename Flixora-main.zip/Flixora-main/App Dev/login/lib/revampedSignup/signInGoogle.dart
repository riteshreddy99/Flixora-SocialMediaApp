import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:dropdown_formfield/dropdown_formfield.dart';
import '../home.dart';

class SignInGoogle extends StatefulWidget {
  final User user;

  SignInGoogle({Key key, this.user}) : super(key: key);

  @override
  _SignInGoogleState createState() => _SignInGoogleState();
}

class _SignInGoogleState extends State<SignInGoogle> {
  final userNameController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  String _myRole = "User";

  @override
  void dispose() {
    // Clean up the controller when the widget is disposed.

    userNameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        resizeToAvoidBottomInset: false,
        body: Form(
          key: _formKey,
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                    padding: EdgeInsets.only(top: 0.0, left: 20.0, right: 20.0),
                    child: Column(
                      children: <Widget>[
                        Positioned(
                            width: MediaQuery.of(context).size.width,
                            top: MediaQuery.of(context).size.width *
                                0.10, //TRY TO CHANGE THIS **0.30** value to achieve your goal
                            child: Container(
                                padding:
                                    EdgeInsets.fromLTRB(265.0, 55.0, .0, 0.0),
                                child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      Image.asset('assets/images/Picture1.png',
                                          scale: 9.5),
                                    ]))),
                        Positioned(
                            width: MediaQuery.of(context).size.width,
                            top: MediaQuery.of(context).size.width *
                                0.10, //TRY TO CHANGE THIS **0.30** value to achieve your goal
                            child: Container(
                                padding:
                                    EdgeInsets.fromLTRB(200.0, 5.0, 0.0, 0.0),
                                child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: <Widget>[
                                      Image.asset('assets/images/Picture2.png',
                                          scale: 9.5),
                                    ]))),
                        SizedBox(height: 10.0),
                        Container(
                          child: Stack(
                            children: <Widget>[
                              Container(
                                padding:
                                    EdgeInsets.fromLTRB(15.0, 10.0, 0.0, 0.0),
                                child: Center(
                                  child: Text(
                                    'Enter Details ',
                                    style: TextStyle(
                                        color: Colors.amber[100],
                                        fontSize: 30.0,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 20.0),
                        SizedBox(height: 10.0),
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.grey[900],
                              borderRadius: BorderRadius.circular(25)),
                          child: TextFormField(
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              hintText: 'Username',
                              hintStyle: TextStyle(
                                fontSize: 15.0,
                                color: Colors.grey[500],
                              ),
                            ),
                            validator: (name) {
                              Pattern pattern =
                                  r'^[A-Za-z0-9]+(?:[ _-][A-Za-z0-9]+)*$';
                              RegExp regex = new RegExp(pattern);
                              if (!regex.hasMatch(name.trim()))
                                return 'Invalid username';
                              else
                                return null;
                            },
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 15.0,
                                fontWeight: FontWeight.bold),
                            textAlign: TextAlign.center,
                            controller: userNameController,
                            autofocus: false,
                          ),
                        ),
                        SizedBox(height: 10.0),
                        Container(
                            decoration: BoxDecoration(
                              color: Colors.grey[900],
                              borderRadius: BorderRadius.circular(25),
                            ),
                            child: DropdownButton<String>(
                              isExpanded: true,
                              value: _myRole,
                              onChanged: (String newValue) {
                                setState(() {
                                  _myRole = newValue;
                                });
                              },
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 15.0,
                                  fontWeight: FontWeight.bold),
                              underline: Container(
                                color: null,
                              ),
                              items: <String>[
                                'User',
                                'Content Creator',
                                'Channel Creator'
                                'Platform Manager',
                              ].map((String value) {
                                return new DropdownMenuItem<String>(
                                  value: value,
                                  child: Center(
                                      child: new Text(
                                    value,
                                    textAlign: TextAlign.center,
                                  )),
                                );
                              }).toList(),
                            )),
                        Container(
                          padding: EdgeInsets.fromLTRB(15.0, 40.0, 0.0, 0.0),
                          child: Text(
                            ' By Clicking Create Account ',
                            style: TextStyle(
                                color: Colors.grey,
                                fontSize: 10.0,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.fromLTRB(10.0, 0.0, 0.0, 0.0),
                          child: Text(
                            'You Agree To All ',
                            style: TextStyle(
                                color: Colors.grey,
                                fontSize: 10.0,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.fromLTRB(15.0, 0.0, 0.0, 0.0),
                          child: Text(
                            'The Terms and Conditions',
                            style: TextStyle(
                                color: Colors.grey,
                                fontSize: 10.0,
                                fontWeight: FontWeight.bold),
                          ),
                        ),
                        SizedBox(height: 30.0),
                        Container(
                          height: 40.0,
                          child: Material(
                            borderRadius: BorderRadius.circular(20.0),
                            shadowColor: Colors.amber[100],
                            color: Colors.amber[600],
                            elevation: 7.0,
                            child: InkWell(
                              onTap: () async {
                                if (_formKey.currentState.validate()) {
                                  _formKey.currentState.save();
                                  await signUp();
                                }
                              },
                              child: Center(
                                child: Text(
                                  'CREATE ACCOUNT',
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                      fontFamily: 'Montserrat'),
                                ),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(height: 10.0),
                        Container(
                          height: 40.0,
                          color: Colors.transparent,
                          child: Container(
                            decoration: BoxDecoration(
                                border: Border.all(
                                    color: Colors.transparent,
                                    style: BorderStyle.solid,
                                    width: 1.0),
                                color: Colors.transparent,
                                borderRadius: BorderRadius.circular(20.0)),
                            child: InkWell(
                              onTap: () {
                                Navigator.pop(context);
                              },
                              child: Center(
                                child: Text('Go Back',
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontFamily: 'Montserrat',
                                        color: Colors.amber[100])),
                              ),
                            ),
                          ),
                        ),
                      ],
                    )),
              ]),
        ));
  }

  Future signUp() async {
    final uid = widget.user.uid;

    final userRef = FirebaseFirestore.instance.collection('/users');

    List<String> fullName = widget.user.displayName.split(" ");

    Map<String, dynamic> userData = {
      "first-name": fullName.removeAt(0),
      "last-name": fullName.join(" "),
      "country": "",
      "username": userNameController.text,
      "email": widget.user.email,
      "photoUrl":
          "https://firebasestorage.googleapis.com/v0/b/flixora-f29so.appspot.com/o/pngfind.com-male-symbol-png-349693.png?alt=media&token=daee2c36-5293-4754-8df9-c2b288b8a710",
      "bio": "I just signed up to Flixora!",
      "followers": [],
      "following": [],
      "role": _myRole,
      "points": 0,
    };
    await userRef.doc(uid).set(userData);

    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => HomePage()));
  }
}
