import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:login/widgets/top-nav-bar.dart';
import 'package:login/widgets/drawer.dart';
import 'package:login/homePage.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';

import 'profile/main-profileOther.dart';

TextStyle defaultDarkStyle = TextStyle(color: Colors.white, fontSize: 18.0);
TextStyle hintStyle = TextStyle(color: Colors.white54, fontSize: 18.0);
Future<QuerySnapshot> searchResultsFuture;
TextEditingController searchController = TextEditingController();

class SPage extends StatefulWidget {
  static of(BuildContext context, {bool root = false}) => root
      ? context.findRootAncestorStateOfType<_SPageState>()
      : context.findAncestorStateOfType<_SPageState>();

  @override
  _SPageState createState() => _SPageState();
}

class _SPageState extends State<SPage> {
  Widget buildSearchBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(15),
      child: Container(
        decoration: new BoxDecoration(
          // border: Border.all(
          //   color: Colors.grey,
          // ),
          borderRadius: BorderRadius.all(Radius.circular(10)),
          color: Colors.grey[700],
        ),
        child: Container(
          child: Padding(
            padding: EdgeInsets.all(8.0),
            child: TextField(
              controller: searchController,
              onSubmitted: handleSearch,
              style: defaultDarkStyle,
              decoration: new InputDecoration(
                border: InputBorder.none,
                prefixIcon: Icon(Icons.search, color: Colors.grey),
                hintStyle: hintStyle,
                // enabledBorder: const UnderlineInputBorder(
                //   borderSide: const BorderSide(color: Colors.white),
                // ),
                hintText: "Search",
              ),
            ),
          ),
        ),
      ),
    );
  }

  handleSearch(String query) {
    if (query.isEmpty) return;
    print("Searching...");
    Future<QuerySnapshot> users =
        userRef.where("username", isGreaterThanOrEqualTo: query).get();
    setState(() {
      searchResultsFuture = users;
    });
  }

  buildSearch() {
    return FutureBuilder(
      future: searchResultsFuture,
      builder: (context, snapshot) {
        List<Text> searchRes = [];
        if (!snapshot.hasData || snapshot.hasError) {
          return SpinKitRipple(
            color: Colors.grey,
          );
        } else {
          List<DocumentSnapshot> docsUnfiltered = snapshot.data.docs;
          List<DocumentSnapshot> docs = [];
          docsUnfiltered.forEach((element) {
            String s = element.get("username");
            if (s.contains(searchController.text)) {
              docs.add(element);
            }
          });
          return SizedBox(
            height: 200,
            child: new ListView.builder(
              itemCount: docs.length,
              itemBuilder: (BuildContext ctxt, int index) {
                var docInstance = docs[index];
                return Container(
                  decoration: BoxDecoration(
                      // border: Border(bottom: BorderSide(),)
                      ),
                  child: new Card(
                    // shape: StadiumBorder(
                    //   // borderRadius: BorderRadius.circular(15),
                    //   side: BorderSide(
                    //     color: Colors.black,
                    //     width: 2.0
                    //   )
                    // ),
                    elevation: 20,

                    child: ListTile(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    UserProfilePage(userid: docInstance.id)));
                      },
                      leading: CircleAvatar(
                        backgroundImage:
                            NetworkImage(docInstance.get("photoUrl")),
                        radius: 25,
                      ),
                      title: Text(docInstance.get("first-name") +
                          " " +
                          docInstance.get("last-name")),
                      subtitle: Text(docInstance.get("username")),
                    ),
                  ),
                );
              },
            ),
          );
        }

        return Text("data");
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: buildTopNavBar(context),
      drawer: buildDrawer(context),
      body: Column(
        children: <Widget>[
          buildSearchBar(context),
          Expanded(
            child: searchResultsFuture == null
                ? Text("No results")
                : buildSearch(),
          ),
        ],
      ),
      // body: buildAnimSearchBar(),
      // bottomNavigationBar: BottomNavBar(),
    );
  }
}
