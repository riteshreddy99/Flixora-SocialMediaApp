# Software Engineering - 2020 to 2021 Group Project.

Outline :-

DONE DONE DONE DONE IT'S DONE DONE DONE 6 MONTHS INTO THE BAG WOOOOOOOOOOOOOOOOOOOOOOOOOOOOO

Important to understand the main obj. of the software needed to be made. Our client is looking for a very specific style app. It's a combination of a Instagram-esq app with an introduction to a game/award style twist.

It's important to understand that this is actually like how Instagram is in terms of keeping a comment section for feedback, as well as, the ability for a user to use the current location for others to find the same object/animal. We also have to introduce scores for other users to rate the image, either 0-10, 0-5 TBD.

As mentioned before, we need to stick to the style of Instagram, as well as, introduce some client specific requirements. Alongside that, the few potential Customers/Users for this app are Photographers, Collectors, Individuals who observe wildlife, the environment, historians and architects, and Game players but this will not be people who are interested mainly in games but the aforementioned roles who would like to see to a challenge.

Now what do we mean by challenges and game like aspects? The client is looking for a collection based game, as in, a set of photos of perhaps the same family of a particular animal, or animals that are commonly found in a specific area. Points being awarded to a highly-rated photo, as we mentioned before a scale of 0-10 or 0-5 would indicate the performance of an image, the best being awarded points for ??? not mentioned by client.

They would like for us to make different interfaces for different needs, i.e., platform managers, channel creators, and the daily users should be able to have different modes of viewing information in different ways, so a top down view of photos of a map in what I can only assume is like a snapchat friends map, where you see friends locations but replace that with pictures taken by users and where people can find said photo spot. A leader-board system for top-rated photos and users. Unsure by what fastest-moving channels means.

Our main goal is for us to create an end-to-end prototype that directly captures the clients vision and deliver it, this means presenting it and basically selling it to them. Our project should also be efficient and flexible, in the sense that we need to consider accessibility needs and diversity as well. We will need to build an app to perfect the mobile platforms, using a browser is possible but how efficient is it? Lets be honest you wouldn't go on Instagram everyday if the app required you to open chrome, search for the app, and go through the whole process of logging in. The app would just be ideal is what I'm saying. 

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Scope :-

We have already broken down the users in this project and the stakeholders. We are required to be flexible and work on the basis of accommodating for different users, this is due to each having a different reason of using the app. For the prototype, we would require multiple channels and would have to present different types of photographic content to fully show the possibilities of our application.

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


Requirements:-

- Create a system that enables photographs to be shared. ✓
- Create a system that enables users to tag, rate photos, provide feedback, and leave feedback. ✓
- The platform must include appropriate tools for platform managers and channel creators to moderate content. X
- Users must be able to quickly and easily interact with the platform and the relevant information. ✓
- Photos might include associated GPS information which can be used for identifying the location of the photographs. ✓
- Include features that enable key pieces of information to be displayed visually in a form that is appropriate, i.e., good UI/UX development. ✓
- Care should be taken for personal/sensitive data. Follow the GDPR requirements and security. ✓
- Should be responsive on Web Browsers, i.e., Chrome, Firefox, Safari, and Edge, as well as, on mobile devices both IOS and Android. 80%
- A recommendations system for users to find like minded individuals and photos. X
- The system should produce a summary report for managers in consideration to overall usage from all users. X
- A forum page enabling users to share achievements, glitches, hints and new or useful features that are not presently available in other platforms, while keeping in touch with   the app at hand. ✓
- Branding and system name TBD -> Flixora run on Flutter & Firebase.
- Open sourced, themes and a specific style guide. ✓
- Other open source projects that could be used and acknowledge copyright. ✓

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

| Group Members            | GitHub ID's        |
| -------------------------| -------------------|
| Arshad, Sumaiya F        | Sfa29              |
| Ashraf El Baesy, Yousuf  | Aymr07             |
| Balamurugan, Harini      | HariniBalamurugan  |
| Solanki, Marwanl         | marwansolanki      |
| Bandam, Ritesh R         | riteshreddy99      |
| Chachara, Pranav B       | PC-02              |
| Cyrus Monteiro, Brenden  | brendenmonteiro    |
| Harshal, Thachapully     | Harshal12355       |

